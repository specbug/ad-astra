#!/usr/bin/env python3
"""Exploratory SAP diagnostics on already opened overlap-field S1/S2 only."""
from pathlib import Path
import json
import numpy as np
from astropy.timeseries import LombScargle
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from adastra.archive import write_json,sha256_file,utc_now
from qlp_variability_followup import raw_columns,column_arrays,fit,design
LEADS=(201308024,355767420,281593180)
OUT=Path('runs/qlp-overlapfield-sap-followup')
PILOT=Path('runs/qlp-overlapfield-pilot/results.json')
def common_mode(t, controls, min_controls=2):
    """Exact cadence match after rounding 1e-6 d; no interpolation."""
    keys=np.round(t,6); rows=[]
    for ct,cy in controls:
        mapping=dict(zip(np.round(ct,6),cy))
        rows.append([mapping.get(k,np.nan) for k in keys])
    if not rows:return np.full(len(t),np.nan),np.zeros(len(t),int)
    matrix=np.asarray(rows); count=np.sum(np.isfinite(matrix),axis=0)
    with np.errstate(all='ignore'): mode=np.nanmedian(matrix,axis=0)
    mode[count<min_controls]=np.nan
    return mode,count

def residualize(t,y,p,mode):
    good=np.isfinite(mode); x=design(t[good],p)
    # Joint signal+nuisance fit preserves a target sinusoid unless collinear.
    scale=np.std(mode[good]); z=mode[good]/scale if scale else mode[good]
    xx=np.column_stack([x,z]); beta,_,rank,_=np.linalg.lstsq(xx,y[good],rcond=None)
    if rank<xx.shape[1]: raise ValueError('Common mode is rank deficient with sinusoid and segment terms')
    clean=y[good]-z*beta[-1]
    return good,clean,{'common_mode_coefficient':float(beta[-1]/scale) if scale else 0.,'rank':int(rank),'design_columns':xx.shape[1],'condition_number':float(np.linalg.cond(xx))}

def main():
    if OUT.exists():raise ValueError('Output exists; preserve previous attempt')
    pilot=json.loads(PILOT.read_text()); assert pilot['status']=='complete'
    declaration={'created_utc':utc_now(),'stage':'Postselection: visual SAP leads; both sectors already viewed','pilot_sha256':sha256_file(PILOT),'source_sha256':sha256_file(__file__),'leads':LEADS,'allowed_sectors':[1,2],'protected_holdouts_accessed':False,'methods':'SAP unweighted LS 0.5 to min(13, baseline/2) days; fixed S1 frequency for S2. Same camera/CCD leave-target-out median SAP, exact rounded cadence matches (1e-6d), at least 2 controls. Joint sinusoid + per-gap offsets/slopes + fixed common mode ordinary regression; robust Huber fit of residual sensitivity. No FAP or localization. All24 SAP evaluated at lead S1 frequencies.'}
    write_json(OUT/'declaration.json',declaration)
    data={}
    for target in pilot['results']:
        for row in target['sectors']:
            assert row['sector'] in (1,2)
            _,cols,cam,ccd=raw_columns(row,target['tic']); t,y,_,_=column_arrays(cols,'SAP_FLUX')
            data[(target['tic'],row['sector'])]=(t,y,cols,cam,ccd,row)
    periods={}; search={}
    for tic in LEADS:
        t,y,*_=data[tic,1]; ls=LombScargle(t,y); f,power=ls.autopower(minimum_frequency=1/min(13,(t[-1]-t[0])/2),maximum_frequency=2,samples_per_peak=10)
        k=np.argmax(power); periods[tic]=float(1/f[k]); search[tic]={'period_days':periods[tic],'power':float(power[k]),'period_at_search_upper_bound':bool(k==0)}
    write_json(OUT/'s1-selected-periods.json',search)
    results=[]; comparisons=[]
    for tic in LEADS:
        p=periods[tic]; fig,axs=plt.subplots(2,3,figsize=(15,7))
        for sector in (1,2):
            t,y,cols,cam,ccd,row=data[tic,sector]
            peers=[(pt,py) for (other,ss),(pt,py,pc,pca,pcc,pr) in data.items() if other!=tic and ss==sector and pca==cam and pcc==ccd]
            mode,count=common_mode(t,peers); result={'tic':tic,'sector':sector,'camera':cam,'ccd':ccd,'period_days':p,'input_sha256':row['input_sha256'],'same_detector_controls':len(peers),'minimum_required_controls':2,'cadence_coverage_fraction':float(np.mean(np.isfinite(mode))),'control_count_min':int(count.min()),'control_count_max':int(count.max()),'columns':{}}
            for name in ('SAP_FLUX','KSPSAP_FLUX','KSPSAP_FLUX_SML','KSPSAP_FLUX_LAG','SAP_BKG','SAP_X','SAP_Y'):
                try:
                    tt,yy,ee,units=column_arrays(cols,name); a,_=fit(tt,yy,p,ee); b,_=fit(tt,yy,p,ee,robust=True); result['columns'][name]={'units':units,'ordinary':a,'robust':b}
                except Exception as exc:result['columns'][name]={'error':str(exc)}
            ax=axs[sector-1]; ax[0].plot(t,y,'.',ms=2,label='SAP'); kt,ky,_,_=column_arrays(cols,'KSPSAP_FLUX'); ax[0].plot(kt,ky,'.',ms=2,label='KSP'); ax[0].legend(); ax[0].set_title(f'TIC {tic} S{sector} C{cam}/{ccd}')
            if np.sum(np.isfinite(mode))>=100:
                try:
                    good,clean,reg=residualize(t,y,p,mode); a,_=fit(t[good],clean,p); b,_=fit(t[good],clean,p,robust=True); result['common_mode_fit']={'regression':reg,'ordinary':a,'robust':b,'samples':int(good.sum())}
                    ax[1].plot(t,mode,'.',ms=2,label='detector median'); ax[1].plot(t[good],clean,'.',ms=2,label='SAP minus fitted common mode'); ax[1].legend()
                    ax[2].plot(((t[good]-1340)/p)%1,clean,'.',ms=2); ax[2].set_title('Residual at fixed S1 period')
                except Exception as exc:result['common_mode_fit']={'error':str(exc)}
            else:result['common_mode_fit']={'status':'insufficient exact-cadence controls'}
            results.append(result); write_json(OUT/'partial-results.json',{'leads':results})
        fig.tight_layout();fig.savefig(OUT/f'tic-{tic}.png',dpi=140);plt.close(fig)
        for (other,sector),(t,y,cols,cam,ccd,row) in data.items():
            a,_=fit(t,y,p); b,_=fit(t,y,p,robust=True);comparisons.append({'lead_tic':tic,'tic':other,'sector':sector,'camera':cam,'ccd':ccd,'period_days':p,'ordinary':a,'robust':b})
    write_json(OUT/'results.json',{'declaration':declaration,'completed_utc':utc_now(),'s1_periods':search,'leads':results,'all24_comparisons':comparisons})
if __name__=='__main__':main()
