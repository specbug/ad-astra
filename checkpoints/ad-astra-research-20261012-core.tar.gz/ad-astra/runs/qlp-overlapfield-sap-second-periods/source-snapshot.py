import sys,json
from pathlib import Path
sys.path.insert(0,'scripts')
from adastra.archive import write_json,sha256_file,utc_now
from qlp_variability_followup import raw_columns,column_arrays
from astropy.timeseries import LombScargle
out=Path('runs/qlp-overlapfield-sap-second-periods')
if out.exists():raise ValueError('Preserve existing results')
pilotpath=Path('runs/qlp-overlapfield-pilot/results.json');p=json.loads(pilotpath.read_text())
leads=[201308024,355767420,281593180]
write_json(out/'declaration.json',{'created_utc':utc_now(),'stage':'Additional postselection descriptive SAP sector-2 period search; rotation spots can evolve so fixed-phase failure alone does not establish instrument origin','pilot_sha256':sha256_file(pilotpath),'leads':leads,'period_range_days':[0.5,13],'weighted':False,'FAP_calibrated':False,'allowed_sectors':[1,2],'protected_holdouts_accessed':False,'fit_helper_sha256':sha256_file('scripts/qlp_variability_followup.py')})
results=[]
for r in p['results']:
 if r['tic'] not in leads:continue
 for s in r['sectors']:
  _,cols,cam,ccd=raw_columns(s,r['tic']);t,y,_,_=column_arrays(cols,'SAP_FLUX')
  ls=LombScargle(t,y);f,power=ls.autopower(minimum_frequency=1/min(13,(t[-1]-t[0])/2),maximum_frequency=2,samples_per_peak=10)
  k=power.argmax(); row={'tic':r['tic'],'sector':s['sector'],'period_days':float(1/f[k]),'power':float(power[k]),'at_upper_period_boundary':bool(k==0),'input_sha256':s['input_sha256']};results.append(row);print(row)
write_json(out/'results.json',{'completed_utc':utc_now(),'results':results})
