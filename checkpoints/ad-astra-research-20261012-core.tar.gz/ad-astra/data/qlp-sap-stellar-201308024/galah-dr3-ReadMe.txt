J/MNRAS/506/150         The GALAH+ Survey DR3                    (Buder+, 2021)
================================================================================
The GALAH+ Survey: Third Data Release.
    Buder S., Sharma S., Kos J., Amarsi A.M., Nordlander T., Lind K.,
    Martell S.L., Asplund M., Bland-Hawthorn J., Casey A.R., de Silva G.M.,
    D'Orazi V., Freeman K.C., Hayden M.R., Lewis G.F., Lin J.,
    Schlesinger K.J., Simpson J.D., Stello D., Zucker D.B., Zwitter T.,
    Beeson K.L., Buck T., Casagrande L., Clark J.T., Cotar K., da Costa G.S.,
    de Grijs R., Feuillet D., Horner J., Kafle P.R., Khanna S., Kobayashi C.,
    Liu F., Montet B.T., Nandakumar G., Nataf D.M., Ness M.K., Spina L.,
    Tepper-Garcia T., Ting Y.-S., Traven G., Vogrincic R., Wittenmyer R.A.,
    Wyse R.F.G., Zerjal M. (the Galah Collaboration)
    <Mon. Not. R. Astron. Soc. 506, 150 (2021)>
    =2021MNRAS.506..150B        (SIMBAD/NED BibCode)
================================================================================
ADC_Keywords: Surveys ; Milky Way ; Abundances ; Optical
Keywords: methods: data analysis - methods: observational - surveys -
          stars: abundances - stars: fundamental parameters

Abstract:
    The ensemble of chemical element abundance measurements for stars,
    along with precision distances and orbit properties, provides
    high-dimensional data to study the evolution of the MilkyWay.With this
    third data release of the Galactic Archaeology with HERMES (GALAH)
    survey, we publish 678 423 spectra for 588 571 mostly nearby stars
    (81.2 per cent of stars are within <2 kpc), observed with the HERMES
    spectrograph at the Anglo-Australian Telescope. This release
    (hereafter GALAH+ DR3) includes all observations from GALAH Phase 1
    (bright, main, and faint survey, 70 per cent), K2-HERMES (17 per
    cent), TESS-HERMES (5 per cent), and a subset of ancillary
    observations (8 per cent) including the bulge and >75 stellar
    clusters. We derive stellar parameters Teff, logg, [Fe/H], vmic,
    vbroad, and vrad using our modified version of the spectrum synthesis
    code Spectroscopy Made Easy (SME) and 1D MARCS model atmospheres. We
    break spectroscopic degeneracies in our spectrum analysis with
    astrometry from Gaia DR2 and photometry from 2MASS. We report
    abundance ratios [X/Fe] for 30 different elements (11 of which are
    based on non-LTE computations) covering five nucleosynthetic pathways.
    We describe validations for accuracy and precision, flagging of
    peculiar stars/measurements and recommendations for using our results.
    Our catalogue comprises 65 per cent dwarfs, 34 per cent giants, and 1
    per cent other/unclassified stars. Based on unflagged chemical
    composition and age, we find 62 per cent young low-alpha, 9 per cent
    young high-alpha, 27 per cent old high-alpha, and 2 per cent stars
    with [Fe/H]<=-1. Based on kinematics, 4 per cent are halo stars.
    Several Value-Added-Catalogues, including stellar ages and dynamics,
    updated after Gaia eDR3, accompany this release and allow
    chrono-chemodynamic analyses, as we showcase.

Description:
    This is the third data release of the GALAH survey. Data for the GALAH
    survey are taken with the HERMES spectrograph on the 3.9-metre
    Anglo-Australian Telescope (AAT) at Siding Spring Observatory. HERMES
    is a fibre-fed high-resolution (R=28000) spectrograph optimized to do
    Galactic archaeology from a 4m class telescope, with four discrete
    optical wavelength channels covering 4713-4903{AA}, 5648-5873{AA},
    6478-6737{AA}, 7585-7887{AA}.

File Summary:
--------------------------------------------------------------------------------
 FileName      Lrecl  Records   Explanations
--------------------------------------------------------------------------------
ReadMe            80        .   This file
stars.dat       1451   588571   GALAH DR3 main all stars
spect.dat       4116   678423   GALAH DR3 main all spectra
ages.dat         706   678423   GALAH DR3 VAC ages
dyn.dat         1318   678423   GALAH DR3 VAC dynamics
rv.dat           195   678423   GALAH DR3 VAC radial velocities
--------------------------------------------------------------------------------

See also:
    I/345 : Gaia DR2 (Gaia Collaboration, 2018)
    I/347 : Distances to 1.33 billion stars in Gaia DR2 (Bailer-Jones+, 2018)
    https://galah-survey.org/ : GALAH Home Page

Byte-by-byte Description of file: stars.dat
--------------------------------------------------------------------------------
     Bytes Format Units     Label       Explanations
--------------------------------------------------------------------------------
    1-  16  A16   ---       2MASS       2MASS identifier (star_id)
   18-  32  I15   ---       GALAH       GALAH identifier (sobject_id)
   34-  52  I19   ---       GaiaDR2     ?=- Gaia DR2 source_id (dr2_source_id)
   54-  72  I19   ---       GaiaEDR3    ?=- Gaia EDR3 source_id (dr3_source_id)
   74-  84  A11   ---       Survey      Name of survey as part of GALAH+DR3
                                         (survey_name)
   86-  89  I4    ---       Field       GALAH fco field (field_id)
        91  I1    ---       flagRepeat  Repeat observation flag, indicating if
                                         used for clean catalog (flag_repeat)
   93-  98  A6    ---       WG4Field    GALAH WG4 field (wg4_field)
  100- 103  A4    ---       WG4Pipeline SME pipeline version free/lbol/seis
                                         (wg4_pipeline)
  105- 108  I4    ---       Flagsp      Stellar parameter quality flag
                                         (flag_sp) (1)
  110- 116  F7.2  K         Teff        ?=- Spectroscopic effective temperature
                                         (used for fitting) (teff)
  118- 124  F7.2  K       e_Teff        ?=- Uncertainty teff (e_teff)
  126- 129  I4    K         Teffirfm    ?=- IRFM temperature
                                         (not used for synthesis) (irfm_teff)
  131- 138  F8.6  mag       E(B-V)irfm  ?=- E(B-V) used for IRFM teff estimation
                                         (irfm_ebv)
  140- 142  A3    ---     r_E(B-V)irfm  [bay rjc sfd] Reference irfm_ebv
                                         (irfm_ebv_ref)
  144- 152  F9.6  [cm/s2]   logg        ?=- Surface gravity (not fitted via
                                         spectra if wg4_pipeline not free)
                                         (logg)
  154- 161  F8.6  [cm/s2] e_logg        ?=- Uncertainty logg (e_logg)
  163- 171  F9.6  [-]       [Fe/H]      ?=- Fe atomic abundance from Fe lines
                                         (final, 1D-NLTE) (fe_h)
  173- 184  F12.6 [-]     e_[Fe/H]      ?=- Uncertainty fe_h (e_fe_h)
  186- 187  I2    ---     q_[Fe/H]      ?=- Quality flag fe_h (flag_fe_h)
  189- 197  F9.6  [-]       [Fe/H]atmo  ?=- sme.feh from stellar parameter run,
                                         fitted from H, Ti, Sc, Fe (fe_h_atmo)
  199- 206  F8.6  km/s      Vmic        ?=- Microturbulence velocity
                                         (from empirical relation) (vmic)
  208- 217  F10.6 km/s      Vbroad      ?=- Broadening velocity
                                         (fitted sme.vsini with sme.vmac=0)
                                         (vbroad)
  219- 230  F12.6 km/s    e_Vbroad      ?=- Uncertainty of vbroad (e_vbroad)
  232- 243  E12.6 ---       chi2sp      ?=- Chi2 value of stellar parameter
                                         fitting (chi2_sp)
  245- 253  F9.6  [-]       [alpha/Fe]  ?=- Combined, weighted alpha-process
                                         element abundance (alpha_fe)
  255- 263  F9.7  [-]     e_[alpha/Fe]  ?=- Uncertainty of alpha_fe (e_alpha_fe)
  265- 267  I3    ---     o_[alpha/Fe]  ?=- Bitmask of used measurements
                                         alpha_fe (nr_alpha_fe)
  269- 270  I2    ---     f_[alpha/Fe]  ?=- Quality flag of measurements for
                                         alpha_fe (flag_alpha_fe) (G1)
  272- 283  E12.6 [-]       FluxAFe     ?=- Normalised maximum absorption
                                         strength of in iron lines (flux_A_Fe)
  285- 296  E12.6 ---       chiAFe      ?=- Chi2 value of iron abundance fitting
                                         (chi_A_Fe)
  298- 306  F9.6  [-]       [Li/Fe]     ?=- Neutral Li atomic abundance
                                         (final, 1D-NLTE) (Li_fe)
  308- 316  F9.7  [-]     e_[Li/Fe]     ?=- Uncertainty Li_fe (e_Li_fe)
       318  I1    ---     o_[Li/Fe]     ?=- Bitmask of used measurements for Li
                                         (nr_Li_fe)
  320- 321  I2    ---     f_[Li/Fe]     ?=- Quality flag of Li_fe
                                         (flag_Li_fe) (G1)
  323- 331  F9.6  [-]       [C/Fe]      ?=- Neutral C atomic abundance
                                         (final, 1D-NLTE) (C_fe)
  333- 341  F9.7  [-]     e_[C/Fe]      ?=- Uncertainty C_fe (e_C_fe)
       343  I1    ---     o_[C/Fe]      ?=- Bitmask of used measurements for C
                                         (nr_C_fe)
  345- 346  I2    ---     f_[C/Fe]      ?=- Quality flag of C_fe
                                         (flag_C_fe) (G1)
  348- 356  F9.6  [-]       [O/Fe]      ?=- Neutral O atomic abundance
                                         (final, 1D-NLTE) (O_fe)
  358- 366  F9.7  [-]     e_[O/Fe]      ?=- Uncertainty O_fe (e_O_fe)
       368  I1    ---     o_[O/Fe]      ?=- Bitmask of used measurements for O
                                         (nr_O_fe)
  370- 371  I2    ---     f_[O/Fe]      ?=- Quality flag of O_fe
                                         (flag_O_fe) (G1)
  373- 381  F9.6  [-]       [Na/Fe]     ?=- Neutral Na atomic abundance
                                         (final, 1D-NLTE) (Na_fe)
  383- 391  F9.7  [-]     e_[Na/Fe]     ?=- Uncertainty Na_fe (e_Na_fe)
       393  I1    ---     o_[Na/Fe]     ?=- Bitmask of used measurements for Na
                                         (nr_Na_fe)
  395- 396  I2    ---     f_[Na/Fe]     ?=- Quality flag of Na_fe
                                         (flag_Na_fe) (G1)
  398- 406  F9.6  [-]       [Mg/Fe]     ?=- Neutral Mg atomic abundance
                                         (final, 1D-NLTE) (Mg_fe)
  408- 416  F9.7  [-]     e_[Mg/Fe]     ?=- Uncertainty Mg_fe (e_Mg_fe)
       418  I1    ---     o_[Mg/Fe]     ?=- Bitmask of used measurements for Mg
                                         (nr_Mg_fe)
  420- 421  I2    ---     f_[Mg/Fe]     ?=- Quality flag of Mg_fe
                                         (flag_Mg_fe) (G1)
  423- 431  F9.6  [-]       [Al/Fe]     ?=- Neutral Al atomic abundance
                                         (final, 1D-NLTE) (Al_fe)
  433- 441  F9.7  [-]     e_[Al/Fe]     ?=- Uncertainty Al_fe (e_Al_fe)
       443  I1    ---     o_[Al/Fe]     ?=- Bitmask of used measurements for Al
                                         (nr_Al_fe)
  445- 446  I2    ---     f_[Al/Fe]     ?=- Quality flag of Al_fe
                                         (flag_Al_fe) (G1)
  448- 456  F9.6  [-]       [Si/Fe]     ?=- Neutral Si atomic abundance
                                         (final, 1D-NLTE) (Si_fe)
  458- 466  F9.7  [-]     e_[Si/Fe]     ?=- Uncertainty Si_fe (e_Si_fe)
       468  I1    ---     o_[Si/Fe]     ?=- Bitmask of used measurements for Si
                                         (nr_Si_fe)
  470- 471  I2    ---     f_[Si/Fe]     ?=- Quality flag of Si_fe
                                         (flag_Si_fe) (G1)
  473- 481  F9.6  [-]       [K/Fe]      ?=- Neutral K atomic abundance
                                         (final, 1D-NLTE) (K_fe)
  483- 491  F9.7  [-]     e_[K/Fe]      ?=- Uncertainty K_fe (e_K_fe)
       493  I1    ---     o_[K/Fe]      ?=- Bitmask of used measurements for K
                                         (nr_K_fe)
  495- 496  I2    ---     f_[K/Fe]      ?=- Quality flag of K_fe
                                         (flag_K_fe) (G1)
  498- 506  F9.6  [-]       [Ca/Fe]     ?=- Neutral Ca atomic abundance
                                         (final, 1D-NLTE) (Ca_fe)
  508- 516  F9.7  [-]     e_[Ca/Fe]     ?=- Uncertainty Ca_fe (e_Ca_fe)
       518  I1    ---     o_[Ca/Fe]     ?=- Bitmask of used measurements for Ca
                                         (nr_Ca_fe)
  520- 521  I2    ---     f_[Ca/Fe]     ?=- Quality flag of Ca_fe
                                         (flag_Ca_fe) (G1)
  523- 531  F9.6  [-]       [Sc/Fe]     ?=- Neutral Sc atomic abundance
                                         (final, 1D-LTE) (Sc_fe)
  533- 541  F9.7  [-]     e_[Sc/Fe]     ?=- Uncertainty Sc_fe (e_Sc_fe)
       543  I1    ---     o_[Sc/Fe]     ?=- Bitmask of used measurements for Sc
                                         (nr_Sc_fe)
  545- 546  I2    ---     f_[Sc/Fe]     ?=- Quality flag of Sc_fe
                                         (flag_Sc_fe) (G1)
  548- 550  F3.1  [-]       [Sc2/Fe]    ?=- Single-ionised Sc2 atomic abundance
                                         (final, 1D-LTE) (Sc2_fe)
  552- 554  F3.1  [-]     e_[Sc2/Fe]    ?=- Uncertainty Sc2_fe (e_Sc2_fe)
       556  I1    ---     o_[Sc2/Fe]    ?=- Bitmask of used measurements for Sc2
                                         (nr_Sc2_fe)
       558  I1    ---     f_[Sc2/Fe]    ?=- Quality flag of Sc2_fe
                                         (flag_Sc2_fe) (G1)
  560- 568  F9.6  [-]       [Ti/Fe]     ?=- Neutral Ti atomic abundance
                                         (final, 1D-LTE) (Ti_fe)
  570- 578  F9.7  [-]     e_[Ti/Fe]     ?=- Uncertainty Ti_fe (e_Ti_fe)
  580- 581  I2    ---     o_[Ti/Fe]     ?=- Bitmask of used measurements for Ti
                                         (nr_Ti_fe)
  583- 584  I2    ---     f_[Ti/Fe]     ?=- Quality flag of Ti_fe
                                         (flag_Ti_fe) (G1)
  586- 594  F9.6  [-]       [Ti2/Fe]    ?=- Single-ionised Ti2 atomic abundance
                                         (final, 1D-LTE) (Ti2_fe)
  596- 604  F9.7  [-]     e_[Ti2/Fe]    ?=- Uncertainty Ti2_fe (e_Ti2_fe)
  606- 607  I2    ---     o_[Ti2/Fe]    ?=- Bitmask of used measurements for Ti2
                                         (nr_Ti2_fe)
  609- 610  I2    ---     f_[Ti2/Fe]    ?=- Quality flag of Ti2_fe
                                         (flag_Ti2_fe) (G1)
  612- 620  F9.6  [-]       [V/Fe]      ?=- Neutral V atomic abundance
                                         (final, 1D-LTE) (V_fe)
  622- 630  F9.7  [-]     e_[V/Fe]      ?=- Uncertainty V_fe (e_V_fe)
       632  I1    ---     o_[V/Fe]      ?=- Bitmask of used measurements for V
                                         (nr_V_fe)
  634- 635  I2    ---     f_[V/Fe]      ?=- Quality flag of V_fe
                                         (flag_V_fe) (G1)
  637- 645  F9.6  [-]       [Cr/Fe]     ?=- Neutral Cr atomic abundance
                                         (final, 1D-LTE) (Cr_fe)
  647- 655  F9.7  [-]     e_[Cr/Fe]     ?=- Uncertainty Cr_fe (e_Cr_fe)
       657  I1    ---     o_[Cr/Fe]     ?=- Bitmask of used measurements for Cr
                                         (nr_Cr_fe)
  659- 660  I2    ---     f_[Cr/Fe]     ?=- Quality flag of Cr_fe
                                         (flag_Cr_fe) (G1)
  662- 670  F9.6  [-]       [Cr2/Fe]    ?=- Single-ionised Cr2 atomic abundance
                                         (final, 1D-LTE) (Cr2_fe)
  672- 680  F9.7  [-]     e_[Cr2/Fe]    ?=- Uncertainty Cr2_fe (e_Cr2_fe)
       682  I1    ---     o_[Cr2/Fe]    ?=- Bitmask of used measurements for Cr2
                                         (nr_Cr2_fe)
       684  I1    ---     f_[Cr2/Fe]    ?=- Quality flag of Cr2_fe
                                         (flag_Cr2_fe) (G1)
  686- 694  F9.6  [-]       [Mn/Fe]     ?=- Neutral Mn atomic abundance
                                         (final, 1D-NLTE) (Mn_fe)
  696- 704  F9.7  [-]     e_[Mn/Fe]     ?=- Uncertainty Mn_fe (e_Mn_fe)
       706  I1    ---     o_[Mn/Fe]     ?=- Bitmask of used measurements for Mn
                                         (nr_Mn_fe)
  708- 709  I2    ---     f_[Mn/Fe]     ?=- Quality flag of Mn_fe
                                         (flag_Mn_fe) (G1)
  711- 719  F9.6  [-]       [Co/Fe]     ?=- Neutral Co atomic abundance
                                         (final, 1D-LTE) (Co_fe)
  721- 729  F9.7  [-]     e_[Co/Fe]     ?=- Uncertainty Co_fe (e_Co_fe)
  731- 732  I2    ---     o_[Co/Fe]     ?=- Bitmask of used measurements for Co
                                         (nr_Co_fe)
  734- 735  I2    ---     f_[Co/Fe]     ?=- Quality flag of Co_fe
                                         (flag_Co_fe) (G1)
  737- 745  F9.6  [-]       [Ni/Fe]     ?=- Neutral Ni atomic abundance
                                         (final, 1D-LTE) (Ni_fe)
  747- 755  F9.7  [-]     e_[Ni/Fe]     ?=- Uncertainty Ni_fe (e_Ni_fe)
       757  I1    ---     o_[Ni/Fe]     ?=- Bitmask of used measurements for Ni
                                         (nr_Ni_fe)
  759- 760  I2    ---     f_[Ni/Fe]     ?=- Quality flag of Ni_fe
                                         (flag_Ni_fe) (G1)
  762- 770  F9.6  [-]       [Cu/Fe]     ?=- Neutral Cu atomic abundance
                                         (final, 1D-LTE) (Cu_fe)
  772- 780  F9.7  [-]     e_[Cu/Fe]     ?=- Uncertainty Cu_fe (e_Cu_fe)
       782  I1    ---     o_[Cu/Fe]     ?=- Bitmask of used measurements for Cu
                                         (nr_Cu_fe)
  784- 785  I2    ---     f_[Cu/Fe]     ?=- Quality flag of Cu_fe
                                         (flag_Cu_fe) (G1)
  787- 795  F9.6  [-]       [Zn/Fe]     ?=- Neutral Zn atomic abundance
                                         (final, 1D-LTE) (Zn_fe)
  797- 805  F9.7  [-]     e_[Zn/Fe]     ?=- Uncertainty Zn_fe (e_Zn_fe)
       807  I1    ---     o_[Zn/Fe]     ?=- Bitmask of used measurements for Zn
                                         (nr_Zn_fe)
  809- 810  I2    ---     f_[Zn/Fe]     ?=- Quality flag of Zn_fe
                                         (flag_Zn_fe) (G1)
  812- 820  F9.6  [-]       [Rb/Fe]     ?=- Neutral Rb atomic abundance
                                         (final, 1D-LTE) (Rb_fe)
  822- 830  F9.7  [-]     e_[Rb/Fe]     ?=- Uncertainty Rb_fe (e_Rb_fe)
       832  I1    ---     o_[Rb/Fe]     ?=- Bitmask of used measurements for Rb
                                         (nr_Rb_fe)
  834- 835  I2    ---     f_[Rb/Fe]     ?=- Quality flag of Rb_fe
                                         (flag_Rb_fe) (G1)
  837- 845  F9.6  [-]       [Sr/Fe]     ?=- Neutral Sr atomic abundance
                                         (final, 1D-LTE) (Sr_fe)
  847- 855  F9.7  [-]     e_[Sr/Fe]     ?=- Uncertainty Sr_fe (e_Sr_fe)
       857  I1    ---     o_[Sr/Fe]     ?=- Bitmask of used measurements for Sr
                                         (nr_Sr_fe)
  859- 860  I2    ---     f_[Sr/Fe]     ?=- Quality flag of Sr_fe
                                         (flag_Sr_fe) (G1)
  862- 870  F9.6  [-]       [Y/Fe]      ?=- Neutral Y atomic abundance
                                         (final, 1D-LTE) (Y_fe)
  872- 880  F9.7  [-]     e_[Y/Fe]      ?=- Uncertainty Y_fe (e_Y_fe)
       882  I1    ---     o_[Y/Fe]      ?=- Bitmask of used measurements for Y
                                         (nr_Y_fe)
  884- 885  I2    ---     f_[Y/Fe]      ?=- Quality flag of Y_fe
                                         (flag_Y_fe) (G1)
  887- 895  F9.6  [-]       [Zr/Fe]     ?=- Neutral Zr atomic abundance
                                         (final, 1D-LTE) (Zr_fe)
  897- 905  F9.7  [-]     e_[Zr/Fe]     ?=- Uncertainty Zr_fe (e_Zr_fe)
  907- 908  I2    ---     o_[Zr/Fe]     ?=- Bitmask of used measurements for Zr
                                         (nr_Zr_fe)
  910- 911  I2    ---     f_[Zr/Fe]     ?=- Quality flag of Zr_fe
                                         (flag_Zr_fe) (G1)
  913- 921  F9.6  [-]       [Mo/Fe]     ?=- Neutral Mo atomic abundance
                                         (final, 1D-LTE) (Mo_fe)
  923- 931  F9.7  [-]     e_[Mo/Fe]     ?=- Uncertainty Mo_fe (e_Mo_fe)
       933  I1    ---     o_[Mo/Fe]     ?=- Bitmask of used measurements for Mo
                                         (nr_Mo_fe)
  935- 936  I2    ---     f_[Mo/Fe]     ?=- Quality flag of Mo_fe
                                         (flag_Mo_fe) (G1)
  938- 946  F9.6  [-]       [Ru/Fe]     ?=- Neutral Ru atomic abundance
                                         (final, 1D-LTE) (Ru_fe)
  948- 956  F9.7  [-]     e_[Ru/Fe]     ?=- Uncertainty Ru_fe (e_Ru_fe)
       958  I1    ---     o_[Ru/Fe]     ?=- Bitmask of used measurements for Ru
                                         (nr_Ru_fe)
  960- 961  I2    ---     f_[Ru/Fe]     ?=- Quality flag of Ru_fe
                                         (flag_Ru_fe) (G1)
  963- 971  F9.6  [-]       [Ba/Fe]     ?=- Single-ionised Ba atomic abundance
                                         (final, 1D-NLTE) (Ba_fe)
  973- 981  F9.7  [-]     e_[Ba/Fe]     ?=- Uncertainty Ba_fe (e_Ba_fe)
       983  I1    ---     o_[Ba/Fe]     ?=- Bitmask of used measurements for Ba
                                         (nr_Ba_fe)
  985- 986  I2    ---     f_[Ba/Fe]     ?=- Quality flag of Ba_fe
                                         (flag_Ba_fe) (G1)
  988- 996  F9.6  [-]       [La/Fe]     ?=- Single-ionised La atomic abundance
                                         (final, 1D-LTE) (La_fe)
  998-1006  F9.7  [-]     e_[La/Fe]     ?=- Uncertainty La_fe (e_La_fe)
      1008  I1    ---     o_[La/Fe]     ?=- Bitmask of used measurements for La
                                         (nr_La_fe)
 1010-1011  I2    ---     f_[La/Fe]     ?=- Quality flag of La_fe
                                        (flag_La_fe) (G1)
 1013-1021  F9.6  [-]       [Ce/Fe]     ?=- Single-ionised Ce atomic abundance
                                        (final, 1D-LTE) (Ce_fe)
 1023-1031  F9.7  [-]     e_[Ce/Fe]     ?=- Uncertainty Ce_fe (e_Ce_fe)
      1033  I1    ---     o_[Ce/Fe]     ?=- Bitmask of used measurements for Ce
                                         (nr_Ce_fe)
 1035-1036  I2    ---     f_[Ce/Fe]     ?=- Quality flag of Ce_fe
                                        (flag_Ce_fe) (G1)
 1038-1046  F9.6  [-]       [Nd/Fe]     ?=- Single-ionised Nd atomic abundance
                                        (final, 1D-LTE) (Nd_fe)
 1048-1056  F9.7  [-]     e_[Nd/Fe]     ?=- Uncertainty Nd_fe (e_Nd_fe)
      1058  I1    ---     o_[Nd/Fe]     ?=- Bitmask of used measurements for Nd
                                         (nr_Nd_fe)
 1060-1061  I2    ---     f_[Nd/Fe]     ?=- Quality flag of Nd_fe
                                         (flag_Nd_fe) (G1)
 1063-1071  F9.6  [-]       [Sm/Fe]     ?=- Single-ionised Sm atomic abundance
                                         (final, 1D-LTE) (Sm_fe)
 1073-1081  F9.7  [-]     e_[Sm/Fe]     ?=- Uncertainty Sm_fe (e_Sm_fe)
      1083  I1    ---     o_[Sm/Fe]     ?=- Bitmask of used measurements for Sm
                                         (nr_Sm_fe)
 1085-1086  I2    ---     f_[Sm/Fe]     ?=- Quality flag of Sm_fe
                                         (flag_Sm_fe) (G1)
 1088-1096  F9.6  [-]       [Eu/Fe]     ?=- Single-ionised Eu atomic abundance
                                         (final, 1D-LTE) (Eu_fe)
 1098-1106  F9.7  [-]     e_[Eu/Fe]     ?=- Uncertainty Eu_fe (e_Eu_fe)
      1108  I1    ---     o_[Eu/Fe]     ?=- Bitmask of used measurements for Eu
                                         (nr_Eu_fe)
 1110-1111  I2    ---     f_[Eu/Fe]     ?=- Quality flag of Eu_fe
                                         (flag_Eu_fe) (G1)
 1113-1127 F15.11 deg       RAdeg       Right Ascension Gaia DR2 (ICRS) at
                                         Ep=2015.5 (ra_dr2)
 1129-1143 F15.11 deg       DEdeg       Declination Gaia DR2 (ICRS) at
                                         Ep=2015.5 (dec_dr2)
 1145-1152  F8.4  mas       plx         ?=- Parallax propagated from Gaia DR2
                                         (parallax_dr2)
 1154-1159  F6.4  mas     e_plx         ?=- Parallax error propagated from
                                         Gaia DR2 (parallax_error_dr2)
 1161-1181 F21.15 pc        rest        ?=- Estimated distance propagated from
                                         Bailer-jones et al.,
                                         2018AJ....156...58B, Cat. I/347
                                         (r_est_dr2)
 1183-1203 F21.15 pc      b_rest        ?=- Lower bound on the confidence
                                         interval of the estimated distance
                                         propagated from Bailer-jones et al.,
                                         2018AJ....156...58B, Cat. I/347
                                         (r_lo_dr2)
 1205-1225 F21.15 pc      B_rest        ?=- Upper bound on the confidence
                                         interval of the estimated distance
                                         propagated from Bailer-jones et al.,
                                         2018AJ....156...58B, Cat. I/347
                                         (r_hi_dr2)
 1227-1243 F17.12 pc       rlen         ?=- Length scale used in the prior for
                                         the distance estimation propagated from
                                         Bailer-jones et al.,
                                         2018AJ....156...58B, Cat. I/347
                                         (r_len_dr2)
 1245-1255  F11.6 km/s     RVgalah      ?=- Best-method radial velocity from
                                         GALAH spectra (rv_galah)
 1257-1265  F9.6  km/s   e_RVgalah      ?=- Uncertainty of rv_galah (e_rv_galah)
 1267-1277  F11.6 km/s     RVGaiaDR2    ?=- Radial velocity propagated from
                                         Gaia DR2 (rv_gaia_dr2)
 1279-1287  F9.6  km/s   e_RVGaiaDR2    ?=- Radial velocity error propagated
                                         from Gaia DR2 (e_rv_gaia_dr2)
 1289-1290  I2    ---      redflag      Reduction pipeline quality flag
                                         (red_flag)
 1292-1298  F7.4  mag      E(B-V)       SFD extinction value (ebv)
 1300-1308  F9.4  ---      snrc1iraf    Average SNR/px CCD1 (snr_c1_iraf)
 1310-1318  F9.4  ---      snrc2iraf    Average SNR/px CCD2 (snr_c2_iraf)
 1320-1328  F9.4  ---      snrc3iraf    Average SNR/px CCD3 (snr_c3_iraf)
 1330-1339  F10.4 ---      snrc4iraf    ?=- Average SNR/px CCD4 (snr_c4_iraf)
      1341  I1    ---      flagGUESS    GUESS reduction pipeline quality flag
                                         (flag_guess)
 1343-1353  F11.6 mag      Vmag         ?=- V magnitude estimated from 2MASS
                                         J and Ks mag (v_jk)
 1355-1361  F7.3  mag      Jmag         ?=- J magnitude propagated from
                                         2MASS (j_m)
 1363-1367  F5.3  mag    e_Jmag         ?=- J magnitude error propagated from
                                         2MASS (j_msigcom)
 1369-1375  F7.3  mag      Hmag         ?=- H magnitude propagated from
                                         2MASS (h_m)
 1377-1381  F5.3  mag    e_Hmag         ?=- H magnitude error propagated from
                                         2MASS (h_msigcom)
 1383-1389  F7.3  mag      Ksmag        ?=- Ks magnitude propagated from
                                         2MASS (ks_m)
 1391-1395  F5.3  mag    e_Ksmag        ?=- Ks magnitude error propagated from
                                         2MASS (ks_msigcom)
 1397-1399  A3    ---      Qflg2MASS    [ABCDEFU ] Quality flag propagated from
                                         2MASS ph_qual (ph_qual_tmass)
 1401-1406  F6.3  mag      W2mag        ?=- W2 magnitude propagated from
                                         AllWISE (w2mpro)
 1408-1412  F5.3  mag    e_W2mag        ?=- W2 magnitude error propagated from
                                         AllWISE (w2mpro_error)
 1414-1417  A4    ---      QflgWISE     [ABCUXZ] Quality flag propagated from
                                         AllWISE ph_qual (ph_qual_wise)
 1419-1424  F6.3  mag      AKs          Used Ks band extinction (a_ks)
 1426-1431  F6.3  mag    e_AKs          ?=- Uncertainty of a_ks (e_a_ks)
 1433-1440  F8.6  mag      BCKs         ?=- Used Bolometric Correction for
                                         Ks band (bc_ks)
 1442-1451  F10.6 ---      RUWE         ?=- RUWE propagated from Gaia DR2
                                         (ruwe_dr2)
--------------------------------------------------------------------------------
Note (1): Stellar parameter quality flag as follows:
    1 = Gaia RUWE > 1.4
         (unreliable astrometric solution, see Lindegren 2018)
    2 = unreliable broadening
    4 = Low S/N (below 10 for CCD 2)
    8 = Reduction issues
         a) Wavelength solution (propagating of red_flag),
         b) t-SNE projected reduction issues,
         c) Negative/positive fluxes, spikes, etc.
   16 = t-SNE projected emission features
   32 = t-SNE projected binaries
   64 = Binary sequence/pre-main sequence flag
  128 = SNR-dependent high sme chi2 (bad fit)
  256 = Problems with Fe: line flux is not between 0.03 and 1.00,
        [Fe/H] unreliable, or blending suspected
  512 = Sme did not finish
         a) No convergence == non-finite stellar parameters
         b) Gaussian RV fit failed
 1024 = MARCS grid limit reached or outside of reasonable parameter range
--------------------------------------------------------------------------------

Byte-by-byte Description of file: spect.dat
--------------------------------------------------------------------------------
   Bytes   Format Units     Label                  Explanations
--------------------------------------------------------------------------------
    1-  16  A16   ---       2MASS                  2MASS identifier (star_id)
   18-  32  I15   ---       GALAH                  GALAH identifier (sobject_id)
   34-  52  I19   ---       GaiaDR2                ?=- Gaia DR2 source_id
                                                    (dr2_source_id)
   54-  72  I19   ---       GaiaEDR3               ?=- Gaia DR3 source_id
                                                    (dr3_source_id)
   74-  84  A11   ---       Survey                 Name of survey as part of
                                                    GALAH+DR3 (survey_name)
   86-  89  I4    ---       Field                  GALAH fco field (field_id)
        91  I1    ---       flagRepeat             Repeat observation flag,
                                                    indicating if used for clean
                                                    catalog (flag_repeat)
   93-  98  A6    ---       WG4Field               GALAH WG4 field (wg4_field)
  100- 103  A4    ---       WG4Pipeline            ?=- SME pipeline version
                                                    free/lbol/seis
                                                    (wg4_pipeline)
  105- 108  I4    ---       Flagsp                 Stellar parameter quality
                                                    flag (flag_sp)
  110- 118  F9.4  K         Teff                   ?=- Spectroscopic effective
                                                    temperature (used for
                                                    fitting) (teff)
  120- 128  F9.4  K       e_Teff                   ?=- Uncertainty teff (e_teff)
  130- 133  I4    K         Teffirfm               ?=- IRFM temperature
                                                    (not used for synthesis)
                                                    (irfm_teff)
  135- 139  F5.3  mag       E(B-V)irfm             ?=- E(B-V) used for IRFM teff
                                                    estimation (irfm_ebv)
  141- 143  A3    ---     r_E(B-V)irfm             Reference irfm_ebv
                                                    (irfm_ebv_ref)
  145- 154  F10.6 K         coveTeff               ?=- SME covariance fitting
                                                    uncertainty teff
                                                    (cov_e_teff)
  156- 161  F6.1  K         initTeff               ?=- SME initial teff
                                                    (init_teff)
  163- 171  F9.6  [cm/s2]   logg                   ?=- Surface gravity
                                                    (not fitted via spectra if
                                                    wg4_pipeline not free)
                                                    (logg)
  173- 181  F9.7  [cm/s2] e_logg                   ?=- Uncertainty logg (e_logg)
  183- 191  F9.7  [cm/s2]   covelogg               ?=- MonteCarlo uncertainty
                                                    logg (cov_e_logg)
  193- 203  F11.6 [cm/s2]   initlogg               ?=- SME initial logg
                                                    (init_logg)
  205- 213  F9.6  [-]       [Fe/H]                 ?=- Fe atomic abundance from
                                                    Fe lines (final, 1D-NLTE)
                                                    (fe_h)
  215- 226  F12.6 [-]     e_[Fe/H]                 ?=- Uncertainty fe_h (e_fe_h)
  228- 239  F12.6 [-]       cove[Fe/H]             ?=- SME covariance fitting
                                                    uncertainty fe_h
                                                    (cov_e_fe_h)
  241- 242  I2    ---     f_[Fe/H]                 ?=- Quality flag fe_h
                                                    (flag_fe_h) (G1)
  244- 252  F9.6  [-]       [Fe/H]atmo             ?=- sme.feh from stellar
                                                    parameter run, fitted from
                                                    H, Ti, Sc, Fe (fe_h_atmo)
  254- 262  F9.7  [-]     e_[Fe/H]atmo             ?=- Uncertainty fe_h_atmo
                                                    (e_fe_h_atmo)
  264- 272  F9.7  [-]       cove[Fe/H]atmo         ?=- SME covariance fitting
                                                    uncertainty sme.feh
                                                    (cov_e_fe_h_atmo)
  274- 284  F11.6 [-]       init[Fe/H]atmo         ?=- SME initial sme.feh
                                                    (init_fe_h_atmo)
  286- 293  F8.6  km/s      Vmic                   ?=- Microturbulence velocity
                                                    (from empirical relation)
                                                    (vmic)
  295- 304  F10.6 km/s      Vbroad                 ?=- Broadening velocity
                                                    (fitted sme.vsini with
                                                    sme.vmac=0) (vbroad)
  306- 320  F15.8 km/s    e_Vbroad                 ?=- Uncertainty of vbroad
                                                    (e_vbroad)
  322- 334  F13.6 km/s      coveVbroad             ?=- SME covariance fitting
                                                    uncertainty sme.vsini
                                                    (cov_e_vbroad)
  336- 338  F3.1  km/s      initVbroad             ?=- SME initial broadening
                                                    velocity (init_vbroad)
  340- 347  F8.6  Msun      Mass                   ?=- Stellar parameter fitting
                                                    product of stellar mass
                                                    (mass)
  349- 360  E12.6 Lsun      Lbol                   ?=- Stellar parameter fitting
                                                    product of bolometric
                                                    luminosity (lbol)
  362- 370  F9.6  Gyr       Age                    ?=- Stellar parameter fitting
                                                    product of stellar age (age)
  372- 383  E12.6 ---       chi2sp                 ?=- Chi2 value of stellar
                                                    parameter fitting (chi2_sp)
  385- 393  F9.6  [-]       [alpha/Fe]             ?=- Combined, weighted
                                                    alpha-process element
                                                    abundance (alpha_fe)
  395- 403  F9.7  [-]     e_[alpha/Fe]             ?=- Uncertainty of alpha_fe
                                                    (e_alpha_fe)
  405- 407  I3    ---     o_[alpha/Fe]             ?=- Bitmask of used
                                                    measurements for alpha_fe
                                                    (nr_alpha_fe)
  409- 410  I2    ---     f_[alpha/Fe]             ?=- Quality flag of
                                                    measurements for alpha_fe
                                                    (flag_alpha_fe) (G1)
  412- 423  E12.6 [-]       FluxAFe                ?=- Normalised maximum
                                                    absorption strength of in
                                                    iron lines (flux_A_Fe)
  425- 436  E12.6 [-]       chiAFe                 ?=- Chi2 value of iron
                                                    abundance fitting (chi_A_Fe)
  438- 447  F10.6 [-]       ind[Li6708/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Li6708 (ind_Li6708_fe)
  449- 459  F11.7 [-]       indcove[Li6708/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Li6708_fe
                                                    (ind_cov_e_Li6708)
  461- 462  I2    ---     f_ind[Li6708/Fe]         ?=- Quality flag fit for
                                                    ind_Li6708_fe
                                                    (ind_flag_Li6708) (G1)
  464- 466  F3.1  [-]       ind[Li6708/Fe]NoRV     ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Li6708_NoRV
                                                    (ind_Li6708_NoRV_fe)
       468  I1    [-]       indcove[Li6708/Fe]NoRV ?=- SME covariance fitting
                                                     uncertainty
                                                     ind_Li6708_NoRV_fe
                                                     (ind_cov_e_Li6708_NoRV)
  470- 471  I2    ---     f_ind[Li6708/Fe]NoRV     ?=- Quality flag fit for
                                                    ind_Li6708_NoRV_fe
                                                    (ind_flag_Li6708_NoRV) (G1)
  473- 483  F11.6 [-]       ind[C6588/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    C6588 (ind_C6588_fe)
  485- 493  F9.6  [-]       indcove[C6588/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_C6588_fe
                                                    (ind_cov_e_C6588)
  495- 496  I2    ---     f_ind[C6588/Fe]          ?=- Quality flag fit for
                                                    ind_C6588_fe
                                                    (ind_flag_C6588) (G1)
  498- 507  F10.6 [-]       ind[O/Fe]              ?=- Individual uncalibrated
                                                    measurement of line/combo O
                                                    (ind_O_fe)
  509- 521  F13.6 [-]       indcove[O/Fe]          ?=- SME covariance fitting
                                                    uncertainty ind_O_fe
                                                    (ind_cov_e_O)
  523- 524  I2    ---     f_ind[O/Fe]              ?=- Quality flag fit for
                                                    ind_O_fe (ind_flag_O) (G1)
  526- 536  F11.6 [-]       ind[Na/Fe]             ?=- Individual uncalibrated
                                                    measurement of line/combo Na
                                                    (ind_Na_fe)
  538- 546  F9.7  [-]       indcove[Na/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Na_fe
                                                    (ind_cov_e_Na)
  548- 549  I2    ---     f_ind[Na/Fe]             ?=- Quality flag fit for
                                                    ind_Na_fe (ind_flag_Na) (G1)
  551- 560  F10.6 [-]       ind[Mg5711/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Mg5711 (ind_Mg5711_fe)
  562- 575  F14.7 [-]       indcove[Mg5711/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Mg5711_fe
                                                    (ind_cov_e_Mg5711)
  577- 588  I12   ---     f_ind[Mg5711/Fe]         ?=- Quality flag fit for
                                                    ind_Mg5711_fe
                                                    (ind_flag_Mg5711) (G1)
  590- 599  F10.6 [-]       ind[Al/Fe]             ?=- Individual uncalibrated
                                                    measurement of line/combo Al
                                                    (ind_Al_fe)
  601- 609  F9.7  [-]       indcove[Al/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Al_fe
                                                    (ind_cov_e_Al)
  611- 612  I2    ---     f_ind[Al/Fe]             ?=- Quality flag fit for
                                                    ind_Al_fe (ind_flag_Al) (G1)
  614- 623  F10.6 [-]       ind[Si/Fe]             ?=- Individual uncalibrated
                                                    measurement of line/combo Si
                                                    (ind_Si_fe)
  625- 637  F13.7 [-]       indcove[Si/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Si_fe
                                                    (ind_cov_e_Si)
  639- 640  I2    ---     f_ind[Si/Fe]             ?=- Quality flag fit for
                                                    ind_Si_fe (ind_flag_Si) (G1)
  642- 651  F10.6 [-]       ind[K7699/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    K7699 (ind_K7699_fe)
  653- 662  F10.7 [-]       indcove[K7699/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_K7699_fe
                                                    (ind_cov_e_K7699)
  664- 665  I2    ---     f_ind[K7699/Fe]          ?=- Quality flag fit for
                                                    ind_K7699_fe
                                                    (ind_flag_K7699) (G1)
  667- 676  F10.6 [-]       ind[Ca/Fe]             ?=- Individual uncalibrated
                                                    measurement of line/combo Ca
                                                    (ind_Ca_fe)
  678- 686  F9.7  [-]       indcove[Ca/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Ca_fe
                                                    (ind_cov_e_Ca)
  688- 689  I2    ---     f_ind[Ca/Fe]             ?=- Quality flag fit for
                                                    ind_Ca_fe (ind_flag_Ca) (G1)
  691- 702  F12.6 [-]       ind[Sc/Fe]             ?=- Individual uncalibrated
                                                    measurement of line/combo Sc
                                                    (ind_Sc_fe)
  704- 712  F9.7  [-]       indcove[Sc/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Sc_fe
                                                    (ind_cov_e_Sc)
  714- 715  I2    ---     f_ind[Sc/Fe]             ?=- Quality flag fit for
                                                    ind_Sc_fe (ind_flag_Sc) (G1)
  717- 726  F10.6 [-]       ind[Ti4758/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4758 (ind_Ti4758_fe)
  728- 736  F9.7  [-]       indcove[Ti4758/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4758_fe
                                                    (ind_cov_e_Ti4758)
  738- 739  I2    ---     f_ind[Ti4758/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4758_fe
                                                    (ind_flag_Ti4758) (G1)
  741- 750  F10.6 [-]       ind[Ti4759/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4759 (ind_Ti4759_fe)
  752- 760  F9.7  [-]       indcove[Ti4759/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4759_fe
                                                    (ind_cov_e_Ti4759)
  762- 763  I2    ---     f_ind[Ti4759/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4759_fe
                                                    (ind_flag_Ti4759) (G1)
  765- 774  F10.6 [-]       ind[Ti4778/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4778 (ind_Ti4778_fe)
  776- 785  F10.7 [-]       indcove[Ti4778/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4778_fe
                                                    (ind_cov_e_Ti4778)
  787- 788  I2    ---     f_ind[Ti4778/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4778_fe
                                                    (ind_flag_Ti4778) (G1)
  790- 799  F10.6 [-]       ind[Ti4782/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4782 (ind_Ti4782_fe)
  801- 810  F10.7 [-]       indcove[Ti4782/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4782_fe
                                                    (ind_cov_e_Ti4782)
  812- 813  I2    ---     f_ind[Ti4782/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4782_fe
                                                    (ind_flag_Ti4782) (G1)
  815- 824  F10.6 [-]       ind[Ti4798/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4798 (ind_Ti4798_fe)
  826- 837  F12.8 [-]       indcove[Ti4798/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4798_fe
                                                    (ind_cov_e_Ti4798)
  839- 840  I2    ---     f_ind[Ti4798/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4798_fe
                                                    (ind_flag_Ti4798) (G1)
  842- 851  F10.6 [-]       ind[Ti4802/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4802 (ind_Ti4802_fe)
  853- 864  F12.7 [-]       indcove[Ti4802/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4802_fe
                                                    (ind_cov_e_Ti4802)
  866- 867  I2    ---     f_ind[Ti4802/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4802_fe
                                                    (ind_flag_Ti4802) (G1)
  869- 880  F12.6 [-]       ind[Ti4820/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4820 (ind_Ti4820_fe)
  882- 892  F11.7 [-]       indcove[Ti4820/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4820_fe
                                                    (ind_cov_e_Ti4820)
  894- 895  I2    ---     f_ind[Ti4820/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4820_fe
                                                    (ind_flag_Ti4820) (G1)
  897- 908  F12.6 [-]       ind[Ti5689/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti5689 (ind_Ti5689_fe)
  910- 919  F10.7 [-]       indcove[Ti5689/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti5689_fe
                                                    (ind_cov_e_Ti5689)
  921- 922  I2    ---     f_ind[Ti5689/Fe]         ?=- Quality flag fit for
                                                    ind_Ti5689_fe
                                                    (ind_flag_Ti5689) (G1)
  924- 933  F10.6 [-]       ind[Ti5716/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti5716 (ind_Ti5716_fe)
  935- 944  F10.7 [-]       indcove[Ti5716/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti5716_fe
                                                    (ind_cov_e_Ti5716)
  946- 947  I2    ---     f_ind[Ti5716/Fe]         ?=- Quality flag fit for
                                                    ind_Ti5716_fe
                                                    (ind_flag_Ti5716) (G1)
  949- 961  F13.6 [-]       ind[Ti5720/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti5720 (ind_Ti5720_fe)
  963- 972  F10.7 [-]       indcove[Ti5720/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti5720_fe
                                                    (ind_cov_e_Ti5720)
  974- 975  I2    ---     f_ind[Ti5720/Fe]         ?=- Quality flag fit for
                                                    ind_Ti5720_fe
                                                    (ind_flag_Ti5720) (G1)
  977- 986  F10.6 [-]       ind[Ti5739/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti5739 (ind_Ti5739_fe)
  988- 997  F10.7 [-]       indcove[Ti5739/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti5739_fe
                                                    (ind_cov_e_Ti5739)
  999-1000  I2    ---     f_ind[Ti5739/Fe]         ?=- Quality flag fit for
                                                    ind_Ti5739_fe
                                                    (ind_flag_Ti5739) (G1)
 1002-1011  F10.6 [-]       ind[Ti5866/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti5866 (ind_Ti5866_fe)
 1013-1022  F10.7 [-]       indcove[Ti5866/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti5866_fe
                                                    (ind_cov_e_Ti5866)
 1024-1025  I2    ---     f_ind[Ti5866/Fe]         ?=- Quality flag fit for
                                                    ind_Ti5866_fe
                                                    (ind_flag_Ti5866) (G1)
 1027-1029  F3.1  [-]       ind[Ti6599/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti6599 (ind_Ti6599_fe)
 1031-1033  F3.1  [-]       indcove[Ti6599/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti6599_fe
                                                    (ind_cov_e_Ti6599)
 1035-1036  I2    ---     f_ind[Ti6599/Fe]         ?=- Quality flag fit for
                                                    ind_Ti6599_fe
                                                    (ind_flag_Ti6599) (G1)
 1038-1047  F10.6 [-]       ind[Ti6717/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti6717 (ind_Ti6717_fe)
 1049-1060  E12.6 [-]       indcove[Ti6717/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti6717_fe
                                                    (ind_cov_e_Ti6717)
 1062-1063  I2    ---     f_ind[Ti6717/Fe]         ?=- Quality flag fit for
                                                    ind_Ti6717_fe
                                                    (ind_flag_Ti6717) (G1)
 1065-1074  F10.6 [-]       ind[Ti7853/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti7853 (ind_Ti7853_fe)
 1076-1088  F13.7 [-]       indcove[Ti7853/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti7853_fe
                                                    (ind_cov_e_Ti7853)
 1090-1091  I2    ---     f_ind[Ti7853/Fe]         ?=- Quality flag fit for
                                                    ind_Ti7853_fe
                                                    (ind_flag_Ti7853) (G1)
 1093-1102  F10.6 [-]       ind[Ti4720/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4720 (ind_Ti4720_fe)
 1104-1113  F10.7 [-]       indcove[Ti4720/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4720_fe
                                                    (ind_cov_e_Ti4720)
 1115-1116  I2    ---     f_ind[Ti4720/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4720_fe
                                                    (ind_flag_Ti4720) (G1)
 1118-1127  F10.6 [-]       ind[Ti4765/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4765 (ind_Ti4765_fe)
 1129-1138  F10.7 [-]       indcove[Ti4765/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4765_fe
                                                    (ind_cov_e_Ti4765)
 1140-1141  I2    ---     f_ind[Ti4765/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4765_fe
                                                    (ind_flag_Ti4765) (G1)
 1143-1152  F10.6 [-]       ind[Ti4799/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4799 (ind_Ti4799_fe)
 1154-1162  F9.7  [-]       indcove[Ti4799/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4799_fe
                                                    (ind_cov_e_Ti4799)
 1164-1165  I2    ---     f_ind[Ti4799/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4799_fe
                                                    (ind_flag_Ti4799) (G1)
 1167-1176  F10.6 [-]       ind[Ti4849/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4849 (ind_Ti4849_fe)
 1178-1187  F10.7 [-]       indcove[Ti4849/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4849_fe
                                                    (ind_cov_e_Ti4849)
 1189-1190  I2    ---     f_ind[Ti4849/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4849_fe
                                                    (ind_flag_Ti4849) (G1)
 1192-1201  F10.6 [-]       ind[Ti4866/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4866 (ind_Ti4866_fe)
 1203-1213  F11.7 [-]       indcove[Ti4866/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4866_fe
                                                    (ind_cov_e_Ti4866)
 1215-1216  I2    ---     f_ind[Ti4866/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4866_fe
                                                    (ind_flag_Ti4866) (G1)
 1218-1230  F13.6 [-]       ind[Ti4874/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ti4874 (ind_Ti4874_fe)
 1232-1243  E12.6 [-]       indcove[Ti4874/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ti4874_fe
                                                    (ind_cov_e_Ti4874)
 1245-1246  I2    ---     f_ind[Ti4874/Fe]         ?=- Quality flag fit for
                                                    ind_Ti4874_fe
                                                    (ind_flag_Ti4874) (G1)
 1248-1260  F13.6 [-]       ind[V4832/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    V4832 (ind_V4832_fe)
 1262-1274  F13.7 [-]       indcove[V4832/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_V4832_fe
                                                    (ind_cov_e_V4832)
 1276-1277  I2    ---     f_ind[V4832/Fe]          ?=- Quality flag fit for
                                                    ind_V4832_fe
                                                    (ind_flag_V4832) (G1)
 1279-1290  F12.6 [-]       ind[V4784/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    V4784 (ind_V4784_fe)
 1292-1303  E12.6 [-]       indcove[V4784/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_V4784_fe
                                                    (ind_cov_e_V4784)
 1305-1306  I2    ---     f_ind[V4784/Fe]          ?=- Quality flag fit for
                                                    ind_V4784_fe
                                                    (ind_flag_V4784) (G1)
 1308-1317  F10.6 [-]       ind[V4797/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    V4797 (ind_V4797_fe)
 1319-1332  F14.7 [-]       indcove[V4797/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_V4797_fe
                                                    (ind_cov_e_V4797)
 1334-1335  I2    ---     f_ind[V4797/Fe]          ?=- Quality flag fit for
                                                    ind_V4797_fe
                                                    (ind_flag_V4797) (G1)
 1337-1349  F13.6 [-]         ind[Cr/Fe]           ?=- Individual uncalibrated
                                                    measurement of line/combo Cr
                                                    (ind_Cr_fe)
 1351-1360  F10.7 [-]       indcove[Cr/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Cr_fe
                                                    (ind_cov_e_Cr)
 1362-1363  I2    ---     f_ind[Cr/Fe]             ?=- Quality flag fit for
                                                    ind_Cr_fe (ind_flag_Cr) (G1)
 1365-1374  F10.6 [-]       ind[Mn/Fe]             ?=- Individual uncalibrated
                                                    measurement of line/combo Mn
                                                    (ind_Mn_fe)
 1376-1387  F12.7 [-]       indcove[Mn/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Mn_fe
                                                    (ind_cov_e_Mn)
 1389-1390  I2    ---     f_ind[Mn/Fe]             ?=- Quality flag fit for
                                                    ind_Mn_fe (ind_flag_Mn) (G1)
 1392-1402  F11.6 [-]       ind[Co4781/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co4781 (ind_Co4781_fe)
 1404-1427 E24.17 [-]       indcove[Co4781/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co4781_fe
                                                    (ind_cov_e_Co4781)
 1429-1430  I2    ---     f_ind[Co4781/Fe]         ?=- Quality flag fit for
                                                    ind_Co4781_fe
                                                    (ind_flag_Co4781) (G1)
 1432-1445  F14.6 [-]       ind[Co4900/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co4900 (ind_Co4900_fe)
 1447-1458  E12.6 [-]       indcove[Co4900/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co4900_fe
                                                    (ind_cov_e_Co4900)
 1460-1461  I2    ---     f_ind[Co4900/Fe]         ?=- Quality flag fit for
                                                    ind_Co4900_fe
                                                    (ind_flag_Co4900) (G1)
 1463-1472  F10.6 [-]       ind[Co5647/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co5647 (ind_Co5647_fe)
 1474-1487  F14.7 [-]       indcove[Co5647/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co5647_fe
                                                    (ind_cov_e_Co5647)
 1489-1490  I2    ---     f_ind[Co5647/Fe]         ?=- Quality flag fit for
                                                    ind_Co5647_fe
                                                    (ind_flag_Co5647) (G1)
 1492-1501  F10.6 [-]       ind[Co6490/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co6490 (ind_Co6490_fe)
 1503-1512  F10.7 [-]       indcove[Co6490/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co6490_fe
                                                    (ind_cov_e_Co6490)
 1514-1515  I2    ---     f_ind[Co6490/Fe]         ?=- Quality flag fit for
                                                    ind_Co6490_fe
                                                    (ind_flag_Co6490) (G1)
 1517-1526  F10.6 [-]       ind[Co6551/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co6551 (ind_Co6551_fe)
 1528-1537  F10.7 [-]       indcove[Co6551/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co6551_fe
                                                    (ind_cov_e_Co6551)
 1539-1540  I2    ---     f_ind[Co6551/Fe]         ?=- Quality flag fit for
                                                    ind_Co6551_fe
                                                    (ind_flag_Co6551) (G1)
 1542-1551  F10.6 [-]       ind[Co6632/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co6632 (ind_Co6632_fe)
 1553-1563  F11.7 [-]       indcove[Co6632/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co6632_fe
                                                    (ind_cov_e_Co6632)
 1565-1566  I2    ---     f_ind[Co6632/Fe]         ?=- Quality flag fit for
                                                    ind_Co6632_fe
                                                    (ind_flag_Co6632) (G1)
 1568-1580  F13.6 [-]       ind[Co6679/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co6679 (ind_Co6679_fe)
 1582-1591  F10.7 [-]       indcove[Co6679/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co6679_fe
                                                    (ind_cov_e_Co6679)
 1593-1594  I2    ---     f_ind[Co6679/Fe]         ?=- Quality flag fit for
                                                    ind_Co6679_fe
                                                    (ind_flag_Co6679) (G1)
 1596-1607  F12.6 [-]       ind[Co7713/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co7713 (ind_Co7713_fe)
 1609-1620  E12.6 [-]       indcove[Co7713/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co7713_fe
                                                    (ind_cov_e_Co7713)
 1622-1623  I2    ---     f_ind[Co7713/Fe]         ?=- Quality flag fit for
                                                    ind_Co7713_fe
                                                    (ind_flag_Co7713) (G1)
 1625-1634  F10.6 [-]       ind[Co7838/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Co7838 (ind_Co7838_fe)
 1636-1649  F14.7 [-]       indcove[Co7838/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Co7838_fe
                                                    (ind_cov_e_Co7838)
 1651-1652  I2    ---     f_ind[Co7838/Fe]         ?=- Quality flag fit for
                                                    ind_Co7838_fe
                                                    (ind_flag_Co7838) (G1)
 1654-1666  F13.6 [-]       ind[Ni5847/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ni5847 (ind_Ni5847_fe)
 1668-1681  F14.7 [-]       indcove[Ni5847/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ni5847_fe
                                                    (ind_cov_e_Ni5847)
 1683-1684  I2    ---     f_ind[Ni5847/Fe]         ?=- Quality flag fit for
                                                    ind_Ni5847_fe
                                                    (ind_flag_Ni5847) (G1)
 1686-1698  F13.6 [-]       ind[Ni6586/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ni6586 (ind_Ni6586_fe)
 1700-1709  F10.7 [-]       indcove[Ni6586/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ni6586_fe
                                                    (ind_cov_e_Ni6586)
 1711-1712  I2    ---     f_ind[Ni6586/Fe]         ?=- Quality flag fit for
                                                    ind_Ni6586_fe
                                                    (ind_flag_Ni6586) (G1)
 1714-1723  F10.6 [-]       ind[Cu5700/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Cu5700 (ind_Cu5700_fe)
 1725-1734  F10.7 [-]       indcove[Cu5700/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Cu5700_fe
                                                    (ind_cov_e_Cu5700)
 1736-1737  I2    ---     f_ind[Cu5700/Fe]         ?=- Quality flag fit for
                                                    ind_Cu5700_fe
                                                    (ind_flag_Cu5700) (G1)
 1739-1748  F10.6 [-]       ind[Cu5782/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Cu5782 (ind_Cu5782_fe)
 1750-1758  F9.7  [-]       indcove[Cu5782/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Cu5782_fe
                                                    (ind_cov_e_Cu5782)
 1760-1761  I2    ---     f_ind[Cu5782/Fe]         ?=- Quality flag fit for
                                                    ind_Cu5782_fe
                                                    (ind_flag_Cu5782) (G1)
 1763-1773  F11.6 [-]       ind[Zn4722/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Zn4722 (ind_Zn4722_fe)
 1775-1786  E12.6 [-]       indcove[Zn4722/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Zn4722_fe
                                                    (ind_cov_e_Zn4722)
 1788-1789  I2    ---     f_ind[Zn4722/Fe]         ?=- Quality flag fit for
                                                    ind_Zn4722_fe
                                                    (ind_flag_Zn4722) (G1)
 1791-1801  F11.6 [-]       ind[Zn4811/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Zn4811 (ind_Zn4811_fe)
 1803-1811  F9.7  [-]       indcove[Zn4811/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Zn4811_fe
                                                    (ind_cov_e_Zn4811)
 1813-1814  I2    ---     f_ind[Zn4811/Fe]         ?=- Quality flag fit for
                                                    ind_Zn4811_fe
                                                    (ind_flag_Zn4811) (G1)
 1816-1828  F13.6 [-]       ind[Rb7800/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Rb7800 (ind_Rb7800_fe)
 1830-1839  F10.7 [-]       indcove[Rb7800/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Rb7800_fe
                                                    (ind_cov_e_Rb7800)
 1841-1842  I2    ---     f_ind[Rb7800/Fe]         ?=- Quality flag fit for
                                                    ind_Rb7800_fe
                                                    (ind_flag_Rb7800) (G1)
 1844-1858  F15.6 [-]       ind[Sr6550/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Sr6550 (ind_Sr6550_fe)
 1860-1869  F10.7 [-]       indcove[Sr6550/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Sr6550_fe
                                                    (ind_cov_e_Sr6550)
 1871-1872  I2    ---     f_ind[Sr6550/Fe]         ?=- Quality flag fit for
                                                    ind_Sr6550_fe
                                                    (ind_flag_Sr6550) (G1)
 1874-1887  F14.6 [-]       ind[Y/Fe]              ?=- Individual uncalibrated
                                                    measurement of line/combo Y
                                                    (ind_Y_fe)
 1889-1901  F13.7 [-]       indcove[Y/Fe]          ?=- SME covariance fitting
                                                    uncertainty ind_Y_fe
                                                    (ind_cov_e_Y)
 1903-1904  I2    ---     f_ind[Y/Fe]              ?=- Quality flag fit for
                                                    ind_Y_fe (ind_flag_Y) (G1)
 1906-1920  F15.6 [-]       ind[Y4820/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Y4820 (ind_Y4820_fe)
 1922-1933  E12.6 [-]       indcove[Y4820/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_Y4820_fe
                                                    (ind_cov_e_Y4820)
 1935-1936  I2    ---     f_ind[Y4820/Fe]          ?=- Quality flag fit for
                                                    ind_Y4820_fe
                                                    (ind_flag_Y4820) (G1)
 1938-1952  F15.6 [-]       ind[Y4855/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Y4855 (ind_Y4855_fe)
 1954-1963  F10.7 [-]       indcove[Y4855/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_Y4855_fe
                                                    (ind_cov_e_Y4855)
 1965-1966  I2    ---     f_ind[Y4855/Fe]          ?=- Quality flag fit for
                                                    ind_Y4855_fe
                                                    (ind_flag_Y4855) (G1)
 1968-1977  F10.6 [-]       ind[Y4884/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Y4884 (ind_Y4884_fe)
 1979-1991  F13.7 [-]       indcove[Y4884/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_Y4884_fe
                                                    (ind_cov_e_Y4884)
 1993-1994  I2    ---     f_ind[Y4884/Fe]          ?=- Quality flag fit for
                                                    ind_Y4884_fe
                                                    (ind_flag_Y4884) (G1)
 1996-2007  F12.6 [-]       ind[Y5663/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Y5663 (ind_Y5663_fe)
 2009-2019  F11.7 [-]       indcove[Y5663/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_Y5663_fe
                                                    (ind_cov_e_Y5663)
 2021-2022  I2    ---     f_ind[Y5663/Fe]          ?=- Quality flag fit for
                                                    ind_Y5663_fe
                                                    (ind_flag_Y5663) (G1)
 2024-2035  F12.6 [-]       ind[Y5729/Fe]          ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Y5729 (ind_Y5729_fe)
 2037-2048  E12.6 [-]       indcove[Y5729/Fe]      ?=- SME covariance fitting
                                                    uncertainty ind_Y5729_fe
                                                    (ind_cov_e_Y5729)
 2050-2051  I2    ---     f_ind[Y5729/Fe]          ?=- Quality flag fit for
                                                    ind_Y5729_fe
                                                    (ind_flag_Y5729) (G1)
 2053-2064  F12.6 [-]       ind[Zr4739/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Zr4739 (ind_Zr4739_fe)
 2066-2077  E12.6 [-]       indcove[Zr4739/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Zr4739_fe
                                                    (ind_cov_e_Zr4739)
 2079-2080  I2    ---     f_ind[Zr4739/Fe]         ?=- Quality flag fit for
                                                    ind_Zr4739_fe
                                                    (ind_flag_Zr4739) (G1)
 2082-2093  F12.6 [-]       ind[Zr4772/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Zr4772 (ind_Zr4772_fe)
 2095-2106  E12.6 [-]       indcove[Zr4772/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Zr4772_fe
                                                    (ind_cov_e_Zr4772)
 2108-2109  I2    ---     f_ind[Zr4772/Fe]         ?=- Quality flag fit for
                                                    ind_Zr4772_fe
                                                    (ind_flag_Zr4772) (G1)
 2111-2123  F13.6 [-]       ind[Zr4806/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Zr4806 (ind_Zr4806_fe)
 2125-2136  E12.6 [-]       indcove[Zr4806/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Zr4806_fe
                                                    (ind_cov_e_Zr4806)
 2138-2139  I2    ---     f_ind[Zr4806/Fe]         ?=- Quality flag fit for
                                                    ind_Zr4806_fe
                                                    (ind_flag_Zr4806) (G1)
 2141-2155  F15.6 [-]       ind[Zr4828/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Zr4828 (ind_Zr4828_fe)
 2157-2168  E12.6 [-]       indcove[Zr4828/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Zr4828_fe
                                                    (ind_cov_e_Zr4828)
 2170-2171  I2    ---     f_ind[Zr4828/Fe]         ?=- Quality flag fit for
                                                    ind_Zr4828_fe
                                                    (ind_flag_Zr4828) (G1)
 2173-2185  F13.6 [-]       ind[Zr5681/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Zr5681 (ind_Zr5681_fe)
 2187-2198  E12.6 [-]       indcove[Zr5681/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Zr5681_fe
                                                    (ind_cov_e_Zr5681)
 2200-2201  I2    ---     f_ind[Zr5681/Fe]         ?=- Quality flag fit for
                                                    ind_Zr5681_fe
                                                    (ind_flag_Zr5681) (G1)
 2203-2215  F13.6 [-]       ind[Mo5689/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Mo5689 (ind_Mo5689_fe)
 2217-2226  F10.7 [-]       indcove[Mo5689/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Mo5689_fe
                                                    (ind_cov_e_Mo5689)
 2228-2229  I2    ---     f_ind[Mo5689/Fe]         ?=- Quality flag fit for
                                                    ind_Mo5689_fe
                                                    (ind_flag_Mo5689) (G1)
 2231-2239  F9.6  [-]       ind[Mo5751/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Mo5751 (ind_Mo5751_fe)
 2241-2252  E12.6 [-]       indcove[Mo5751/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Mo5751_fe
                                                    (ind_cov_e_Mo5751)
 2254-2255  I2    ---     f_ind[Mo5751/Fe]         ?=- Quality flag fit for
                                                    ind_Mo5751_fe
                                                    (ind_flag_Mo5751) (G1)
 2257-2266  F10.6 [-]       ind[Mo5858/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Mo5858 (ind_Mo5858_fe)
 2268-2280  F13.7 [-]       indcove[Mo5858/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Mo5858_fe
                                                    (ind_cov_e_Mo5858)
 2282-2283  I2    ---     f_ind[Mo5858/Fe]         ?=- Quality flag fit for
                                                    ind_Mo5858_fe
                                                    (ind_flag_Mo5858) (G1)
 2285-2298  F14.6 [-]       ind[Mo6619/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Mo6619 (ind_Mo6619_fe)
 2300-2308  F9.7  [-]       indcove[Mo6619/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Mo6619_fe
                                                    (ind_cov_e_Mo6619)
 2310-2311  I2    ---     f_ind[Mo6619/Fe]         ?=- Quality flag fit for
                                                    ind_Mo6619_fe
                                                    (ind_flag_Mo6619) (G1)
 2313-2324  F12.6 [-]       ind[Ru4758/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ru4758 (ind_Ru4758_fe)
 2326-2337  E12.6 [-]       indcove[Ru4758/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ru4758_fe
                                                    (ind_cov_e_Ru4758)
 2339-2340  I2    ---     f_ind[Ru4758/Fe]         ?=- Quality flag fit for
                                                    ind_Ru4758_fe
                                                    (ind_flag_Ru4758) (G1)
 2342-2356  F15.6 [-]       ind[Ru4869/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ru4869 (ind_Ru4869_fe)
 2358-2369  E12.6 [-]       indcove[Ru4869/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ru4869_fe
                                                    (ind_cov_e_Ru4869)
 2371-2372  I2    ---     f_ind[Ru4869/Fe]         ?=- Quality flag fit for
                                                    ind_Ru4869_fe
                                                    (ind_flag_Ru4869) (G1)
 2374-2385  F12.6 [-]       ind[Ru5699/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ru5699 (ind_Ru5699_fe)
 2387-2396  F10.7 [-]       indcove[Ru5699/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ru5699_fe
                                                    (ind_cov_e_Ru5699)
 2398-2399  I2    ---     f_ind[Ru5699/Fe]         ?=- Quality flag fit for
                                                    ind_Ru5699_fe
                                                    (ind_flag_Ru5699) (G1)
 2401-2410  F10.6 [-]       ind[Ba/Fe]             ?=- Individual uncalibrated
                                                    measurement of line/combo Ba
                                                    (ind_Ba_fe)
 2412-2421  F10.7 [-]       indcove[Ba/Fe]         ?=- SME covariance fitting
                                                    uncertainty ind_Ba_fe
                                                    (ind_cov_e_Ba)
 2423-2424  I2    ---     f_ind[Ba/Fe]             ?=- Quality flag fit for
                                                    ind_Ba_fe (ind_flag_Ba) (G1)
 2426-2437  F12.6 [-]       ind[La4716/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    La4716 (ind_La4716_fe)
 2439-2450  E12.6 [-]       indcove[La4716/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_La4716_fe
                                                    (ind_cov_e_La4716)
 2452-2453  I2    ---     f_ind[La4716/Fe]         ?=- Quality flag fit for
                                                    ind_La4716_fe
                                                    (ind_flag_La4716) (G1)
 2455-2467  F13.6 [-]       ind[La4749/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    La4749 (ind_La4749_fe)
 2469-2480  E12.6 [-]       indcove[La4749/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_La4749_fe
                                                    (ind_cov_e_La4749)
 2482-2483  I2    ---     f_ind[La4749/Fe]         ?=- Quality flag fit for
                                                    ind_La4749_fe
                                                    (ind_flag_La4749) (G1)
 2485-2497  F13.6 [-]       ind[La4804/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    La4804 (ind_La4804_fe)
 2499-2510  E12.6 [-]       indcove[La4804/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_La4804_fe
                                                    (ind_cov_e_La4804)
 2512-2513  I2    ---     f_ind[La4804/Fe]         ?=- Quality flag fit for
                                                    ind_La4804_fe
                                                    (ind_flag_La4804) (G1)
 2515-2525  F11.6 [-]       ind[La5806/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    La5806 (ind_La5806_fe)
 2527-2538  E12.6 [-]       indcove[La5806/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_La5806_fe
                                                    (ind_cov_e_La5806)
 2540-2541  I2    ---     f_ind[La5806/Fe]         ?=- Quality flag fit for
                                                    ind_La5806_fe
                                                    (ind_flag_La5806) (G1)
 2543-2553  F11.6 [-]       ind[Ce4774/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Ce4774 (ind_Ce4774_fe)
 2555-2564  F10.7 [-]       indcove[Ce4774/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Ce4774_fe
                                                    (ind_cov_e_Ce4774)
 2566-2567  I2    ---     f_ind[Ce4774/Fe]         ?=- Quality flag fit for
                                                    ind_Ce4774_fe
                                                    (ind_flag_Ce4774) (G1)
 2569-2578  F10.6 [-]       ind[Nd4811/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Nd4811 (ind_Nd4811_fe)
 2580-2591  E12.6 [-]       indcove[Nd4811/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Nd4811_fe
                                                    (ind_cov_e_Nd4811)
 2593-2594  I2    ---     f_ind[Nd4811/Fe]         ?=- Quality flag fit for
                                                    ind_Nd4811_fe
                                                    (ind_flag_Nd4811) (G1)
 2596-2605  F10.6 [-]       ind[Nd5741/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Nd5741 (ind_Nd5741_fe)
 2607-2618  E12.6 [-]       indcove[Nd5741/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Nd5741_fe
                                                    (ind_cov_e_Nd5741)
 2620-2621  I2    ---     f_ind[Nd5741/Fe]         ?=- Quality flag fit for
                                                    ind_Nd5741_fe
                                                    (ind_flag_Nd5741) (G1)
 2623-2632  F10.6 [-]       ind[Nd5770/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Nd5770 (ind_Nd5770_fe)
 2634-2645  E12.6 [-]       indcove[Nd5770/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Nd5770_fe
                                                    (ind_cov_e_Nd5770)
 2647-2648  I2    ---     f_ind[Nd5770/Fe]         ?=- Quality flag fit for
                                                    ind_Nd5770_fe
                                                    (ind_flag_Nd5770) (G1)
 2650-2659  F10.6 [-]       ind[Nd5812/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Nd5812 (ind_Nd5812_fe)
 2661-2672  E12.6 [-]       indcove[Nd5812/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Nd5812_fe
                                                    (ind_cov_e_Nd5812)
 2674-2675  I2    ---     f_ind[Nd5812/Fe]         ?=- Quality flag fit for
                                                    ind_Nd5812_fe
                                                    (ind_flag_Nd5812) (G1)
 2677-2686  F10.6 [-]       ind[Nd5842/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Nd5842 (ind_Nd5842_fe)
 2688-2699  E12.6 [-]       indcove[Nd5842/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Nd5842_fe
                                                    (ind_cov_e_Nd5842)
 2701-2702  I2    ---     f_ind[Nd5842/Fe]         ?=- Quality flag fit for
                                                    ind_Nd5842_fe
                                                    (ind_flag_Nd5842) (G1)
 2704-2713  F10.6 [-]       ind[Sm4720/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Sm4720 (ind_Sm4720_fe)
 2715-2724  F10.7 [-]       indcove[Sm4720/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Sm4720_fe
                                                    (ind_cov_e_Sm4720)
 2726-2727  I2    ---     f_ind[Sm4720/Fe]         ?=- Quality flag fit for
                                                    ind_Sm4720_fe
                                                    (ind_flag_Sm4720) (G1)
 2729-2740  F12.6 [-]       ind[Sm4792/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Sm4792 (ind_Sm4792_fe)
 2742-2752  F11.7 [-]       indcove[Sm4792/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Sm4792_fe
                                                    (ind_cov_e_Sm4792)
 2754-2755  I2    ---     f_ind[Sm4792/Fe]         ?=- Quality flag fit for
                                                    ind_Sm4792_fe
                                                    (ind_flag_Sm4792) (G1)
 2757-2765  F9.6  [-]       ind[Sm4837/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Sm4837 (ind_Sm4837_fe)
 2767-2776  F10.7 [-]       indcove[Sm4837/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Sm4837_fe
                                                    (ind_cov_e_Sm4837)
 2778-2779  I2    ---     f_ind[Sm4837/Fe]         ?=- Quality flag fit for
                                                    ind_Sm4837_fe
                                                    (ind_flag_Sm4837) (G1)
 2781-2794  F14.6 [-]       ind[Sm4848/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Sm4848 (ind_Sm4848_fe)
 2796-2807  E12.6 [-]       indcove[Sm4848/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Sm4848_fe
                                                    (ind_cov_e_Sm4848)
 2809-2810  I2    ---     f_ind[Sm4848/Fe]         ?=- Quality flag fit for
                                                    ind_Sm4848_fe
                                                    (ind_flag_Sm4848) (G1)
 2812-2821  F10.6 [-]       ind[Sm4854/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Sm4854 (ind_Sm4854_fe)
 2823-2833  F11.7 [-]       indcove[Sm4854/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Sm4854_fe
                                                    (ind_cov_e_Sm4854)
 2835-2836  I2    ---     f_ind[Sm4854/Fe]         ?=- Quality flag fit for
                                                    ind_Sm4854_fe
                                                    (ind_flag_Sm4854) (G1)
 2838-2847  F10.6 [-]       ind[Eu5819/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Eu5819 (ind_Eu5819_fe)
 2849-2860  E12.6 [-]       indcove[Eu5819/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Eu5819_fe
                                                    (ind_cov_e_Eu5819)
 2862-2863  I2    ---     f_ind[Eu5819/Fe]         ?=- Quality flag fit for
                                                    ind_Eu5819_fe
                                                    (ind_flag_Eu5819) (G1)
 2865-2874  F10.6 [-]       ind[Eu6645/Fe]         ?=- Individual uncalibrated
                                                    measurement of line/combo
                                                    Eu6645 (ind_Eu6645_fe)
 2876-2884  F9.7  [-]       indcove[Eu6645/Fe]     ?=- SME covariance fitting
                                                    uncertainty ind_Eu6645_fe
                                                    (ind_cov_e_Eu6645)
 2886-2887  I2    ---     f_ind[Eu6645/Fe]         ?=- Quality flag fit for
                                                    ind_Eu6645_fe
                                                    (ind_flag_Eu6645) (G1)
 2889-2897  F9.6  [-]       [Li/Fe]                ?=- Neutral Li atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Li_fe)
 2899-2907  F9.7  [-]     e_[Li/Fe]                ?=- Uncertainty Li_fe
                                                    (e_Li_fe)
      2909  I1    ---     o_[Li/Fe]                ?=- Bitmask of used
                                                    measurements for Li
                                                    (nr_Li_fe)
 2911-2912  I2    ---     f_[Li/Fe]                ?=- Quality flag of Li_fe
                                                    (flag_Li_fe) (G1)
 2914-2922  F9.6  [-]       [C/Fe]                 ?=- Neutral C atomic
                                                    abundance (final, 1D-NLTE)
                                                    (C_fe)
 2924-2932  F9.7  [-]     e_[C/Fe]                 ?=- Uncertainty C_fe (e_C_fe)
      2934  I1    ---     o_[C/Fe]                 ?=- Bitmask of used
                                                    measurements for C (nr_C_fe)
 2936-2937  I2    ---     f_[C/Fe]                 ?=- Quality flag of C_fe
                                                    (flag_C_fe) (G1)
 2939-2947  F9.6  [-]       [O/Fe]                 ?=- Neutral O atomic
                                                    abundance (final, 1D-NLTE)
                                                    (O_fe)
 2949-2957  F9.7  [-]     e_[O/Fe]                 ?=- Uncertainty O_fe (e_O_fe)
      2959  I1    ---     o_[O/Fe]                 ?=- Bitmask of used
                                                    measurements for O (nr_O_fe)
 2961-2962  I2    ---     f_[O/Fe]                 ?=- Quality flag of O_fe
                                                    (flag_O_fe) (G1)
 2964-2972  F9.6  [-]       [Na/Fe]                ?=- Neutral Na atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Na_fe)
 2974-2982  F9.7  [-]     e_[Na/Fe]                ?=- Uncertainty Na_fe
                                                    (e_Na_fe)
      2984  I1    ---     o_[Na/Fe]                ?=- Bitmask of used
                                                    measurements for Na
                                                    (nr_Na_fe)
 2986-2987  I2    ---     f_[Na/Fe]                ?=- Quality flag of Na_fe
                                                    (flag_Na_fe) (G1)
 2989-2997  F9.6  [-]       [Mg/Fe]                ?=- Neutral Mg atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Mg_fe)
 2999-3007  F9.7  [-]     e_[Mg/Fe]                ?=- Uncertainty Mg_fe
                                                    (e_Mg_fe)
      3009  I1    ---     o_[Mg/Fe]                ?=- Bitmask of used
                                                    measurements for Mg
                                                    (nr_Mg_fe)
 3011-3012  I2    ---     f_[Mg/Fe]                ?=- Quality flag of Mg_fe
                                                    (flag_Mg_fe) (G1)
 3014-3022  F9.6  [-]       [Al/Fe]                ?=- Neutral Al atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Al_fe)
 3024-3032  F9.7  [-]     e_[Al/Fe]                ?=- Uncertainty Al_fe
                                                    (e_Al_fe)
      3034  I1    ---     o_[Al/Fe]                ?=- Bitmask of used
                                                    measurements for Al
                                                    (nr_Al_fe)
 3036-3037  I2    ---     f_[Al/Fe]                ?=- Quality flag of Al_fe
                                                    (flag_Al_fe) (G1)
 3039-3047  F9.6  [-]       [Si/Fe]                ?=- Neutral Si atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Si_fe)
 3049-3057  F9.7  [-]     e_[Si/Fe]                ?=- Uncertainty Si_fe
                                                    (e_Si_fe)
      3059  I1    ---     o_[Si/Fe]                ?=- Bitmask of used
                                                    measurements for Si
                                                    (nr_Si_fe)
 3061-3062  I2    ---     f_[Si/Fe]                ?=- Quality flag of Si_fe
                                                    (flag_Si_fe) (G1)
 3064-3072  F9.6  [-]       [K/Fe]                 ?=- Neutral K atomic
                                                    abundance (final, 1D-NLTE)
                                                    (K_fe)
 3074-3082  F9.7  [-]     e_[K/Fe]                 ?=- Uncertainty K_fe (e_K_fe)
      3084  I1    ---     o_[K/Fe]                 ?=- Bitmask of used
                                                    measurements for K (nr_K_fe)
 3086-3087  I2    ---     f_[K/Fe]                 ?=- Quality flag of K_fe
                                                    (flag_K_fe) (G1)
 3089-3097  F9.6  [-]       [Ca/Fe]                ?=- Neutral Ca atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Ca_fe)
 3099-3107  F9.7  [-]     e_[Ca/Fe]                ?=- Uncertainty Ca_fe
                                                    (e_Ca_fe)
      3109  I1    ---     o_[Ca/Fe]                ?=- Bitmask of used
                                                    measurements for Ca
                                                    (nr_Ca_fe)
 3111-3112  I2    ---     f_[Ca/Fe]                ?=- Quality flag of Ca_fe
                                                    (flag_Ca_fe) (G1)
 3114-3122  F9.6  [-]       [Sc/Fe]                ?=- Neutral Sc atomic
                                                    abundance (final, 1D-LTE)
                                                    (Sc_fe)
 3124-3132  F9.7  [-]     e_[Sc/Fe]                ?=- Uncertainty Sc_fe
                                                    (e_Sc_fe)
      3134  I1    ---     o_[Sc/Fe]                ?=- Bitmask of used
                                                    measurements for Sc
                                                    (nr_Sc_fe)
 3136-3137  I2    ---     f_[Sc/Fe]                ?=- Quality flag of Sc_fe
                                                    (flag_Sc_fe) (G1)
 3139-3141  F3.1  [-]       [Sc2/Fe]               ?=- Single-ionised Sc2 atomic
                                                    abundance (final, 1D-LTE)
                                                    (Sc2_fe)
 3143-3145  F3.1  [-]     e_[Sc2/Fe]               ?=- Uncertainty Sc2_fe
                                                    (e_Sc2_fe)
      3147  I1    ---     o_[Sc2/Fe]               ?=- Bitmask of used
                                                    measurements for Sc2
                                                    (nr_Sc2_fe)
      3149  I1    ---     f_[Sc2/Fe]               ?=- Quality flag of Sc2_fe
                                                    (flag_Sc2_fe) (G1)
 3151-3159  F9.6  [-]       [Ti/Fe]                ?=- Neutral Ti atomic
                                                    abundance (final, 1D-LTE)
                                                    (Ti_fe)
 3161-3169  F9.7  [-]     e_[Ti/Fe]                ?=- Uncertainty Ti_fe
                                                    (e_Ti_fe)
 3171-3172  I2    ---     o_[Ti/Fe]                ?=- Bitmask of used
                                                    measurements for Ti
                                                    (nr_Ti_fe)
 3174-3175  I2    ---     f_[Ti/Fe]                ?=- Quality flag of Ti_fe
                                                    (flag_Ti_fe) (G1)
 3177-3185  F9.6  [-]       [Ti2/Fe]               ?=- Single-ionised Ti2
                                                    atomic abundance
                                                    (final, 1D-LTE) (Ti2_fe)
 3187-3195  F9.7  [-]     e_[Ti2/Fe]               ?=- Uncertainty Ti2_fe
                                                    (e_Ti2_fe)
 3197-3198  I2    ---     o_[Ti2/Fe]               ?=- Bitmask of used
                                                    measurements for Ti2
                                                    (nr_Ti2_fe)
 3200-3201  I2    ---     f_[Ti2/Fe]               ?=- Quality flag of Ti2_fe
                                                    (flag_Ti2_fe) (G1)
 3203-3211  F9.6  [-]       [V/Fe]                 ?=- Neutral V atomic
                                                    abundance (final, 1D-LTE)
                                                    (V_fe)
 3213-3221  F9.7  [-]     e_[V/Fe]                 ?=- Uncertainty V_fe (e_V_fe)
      3223  I1    ---     o_[V/Fe]                 ?=- Bitmask of used
                                                    measurements for V (nr_V_fe)
 3225-3226  I2    ---     f_[V/Fe]                 ?=- Quality flag of V_fe
                                                    (flag_V_fe) (G1)
 3228-3236  F9.6  [-]       [Cr/Fe]                ?=- Neutral Cr atomic
                                                    abundance (final, 1D-LTE)
                                                    (Cr_fe)
 3238-3246  F9.7  [-]     e_[Cr/Fe]                ?=- Uncertainty Cr_fe
                                                    (e_Cr_fe)
      3248  I1    ---     o_[Cr/Fe]                ?=- Bitmask of used
                                                    measurements for Cr
                                                    (nr_Cr_fe)
 3250-3251  I2    ---     f_[Cr/Fe]                ?=- Quality flag of Cr_fe
                                                    (flag_Cr_fe) (G1)
 3253-3255  F3.1  [-]       [Cr2/Fe]               ?=- Single-ionised Cr2
                                                    atomic abundance (final,
                                                    1D-LTE) (Cr2_fe)
 3257-3259  F3.1  [-]     e_[Cr2/Fe]               ?=- Uncertainty Cr2_fe
                                                    (e_Cr2_fe)
      3261  I1    ---     o_[Cr2/Fe]               ?=- Bitmask of used
                                                    measurements for Cr2
                                                    (nr_Cr2_fe)
      3263  I1    ---     f_[Cr2/Fe]               ?=- Quality flag of Cr2_fe
                                                    (flag_Cr2_fe) (G1)
 3265-3273  F9.6  [-]       [Mn/Fe]                ?=- Neutral Mn atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Mn_fe)
 3275-3283  F9.7  [-]     e_[Mn/Fe]                ?=- Uncertainty Mn_fe
                                                    (e_Mn_fe)
      3285  I1    ---     o_[Mn/Fe]                ?=- Bitmask of used
                                                    measurements for Mn
                                                    (nr_Mn_fe)
 3287-3288  I2    ---     f_[Mn/Fe]                ?=- Quality flag of Mn_fe
                                                    (flag_Mn_fe) (G1)
 3290-3298  F9.6  [-]       [Co/Fe]                ?=- Neutral Co atomic
                                                    abundance (final, 1D-LTE)
                                                    (Co_fe)
 3300-3308  F9.7  [-]     e_[Co/Fe]                ?=- Uncertainty Co_fe
                                                    (e_Co_fe)
 3310-3311  I2    ---     o_[Co/Fe]                ?=- Bitmask of used
                                                    measurements for Co
                                                    (nr_Co_fe)
 3313-3314  I2    ---     f_[Co/Fe]                ?=- Quality flag of Co_fe
                                                    (flag_Co_fe) (G1)
 3316-3324  F9.6  [-]       [Ni/Fe]                ?=- Neutral Ni atomic
                                                    abundance (final, 1D-LTE)
                                                    (Ni_fe)
 3326-3334  F9.7  [-]     e_[Ni/Fe]                ?=- Uncertainty Ni_fe
                                                    (e_Ni_fe)
      3336  I1    ---     o_[Ni/Fe]                ?=- Bitmask of used
                                                    measurements for Ni
                                                    (nr_Ni_fe)
 3338-3339  I2    ---     f_[Ni/Fe]                ?=- Quality flag of Ni_fe
                                                    (flag_Ni_fe) (G1)
 3341-3349  F9.6  [-]       [Cu/Fe]                ?=- Neutral Cu atomic
                                                    abundance (final, 1D-LTE)
                                                    (Cu_fe)
 3351-3359  F9.7  [-]     e_[Cu/Fe]                ?=- Uncertainty Cu_fe
                                                    (e_Cu_fe)
      3361  I1    ---     o_[Cu/Fe]                ?=- Bitmask of used
                                                    measurements for Cu
                                                    (nr_Cu_fe)
 3363-3364  I2    ---     f_[Cu/Fe]                ?=- Quality flag of Cu_fe
                                                    (flag_Cu_fe) (G1)
 3366-3374  F9.6  [-]       [Zn/Fe]                ?=- Neutral Zn atomic
                                                    abundance (final, 1D-LTE)
                                                    (Zn_fe)
 3376-3384  F9.7  [-]     e_[Zn/Fe]                ?=- Uncertainty Zn_fe
                                                    (e_Zn_fe)
      3386  I1    ---     o_[Zn/Fe]                ?=- Bitmask of used
                                                    measurements for Zn
                                                    (nr_Zn_fe)
 3388-3389  I2    ---     f_[Zn/Fe]                ?=- Quality flag of Zn_fe
                                                    (flag_Zn_fe) (G1)
 3391-3399  F9.6  [-]       [Rb/Fe]                ?=- Neutral Rb atomic
                                                    abundance (final, 1D-LTE)
                                                    (Rb_fe)
 3401-3409  F9.7  [-]     e_[Rb/Fe]                ?=- Uncertainty Rb_fe
                                                    (e_Rb_fe)
      3411  I1    ---     o_[Rb/Fe]                ?=- Bitmask of used
                                                    measurements for Rb
                                                    (nr_Rb_fe)
 3413-3414  I2    ---     f_[Rb/Fe]                ?=- Quality flag of Rb_fe
                                                    (flag_Rb_fe) (G1)
 3416-3424  F9.6  [-]       [Sr/Fe]                ?=- Neutral Sr atomic
                                                    abundance (final, 1D-LTE)
                                                    (Sr_fe)
 3426-3434  F9.7  [-]     e_[Sr/Fe]                ?=- Uncertainty Sr_fe
                                                    (e_Sr_fe)
      3436  I1    ---     o_[Sr/Fe]                ?=- Bitmask of used
                                                    measurements for Sr
                                                    (nr_Sr_fe)
 3438-3439  I2    ---     f_[Sr/Fe]                ?=- Quality flag of Sr_fe
                                                    (flag_Sr_fe) (G1)
 3441-3449  F9.6  [-]       [Y/Fe]                 ?=- Neutral Y atomic
                                                    abundance (final, 1D-LTE)
                                                    (Y_fe)
 3451-3459  F9.7  [-]     e_[Y/Fe]                 ?=- Uncertainty Y_fe
                                                    (e_Y_fe)
      3461  I1    ---     o_[Y/Fe]                 ?=- Bitmask of used
                                                    measurements for Y
                                                    (nr_Y_fe)
 3463-3464  I2    ---     f_[Y/Fe]                 ?=- Quality flag of Y_fe
                                                    (flag_Y_fe) (G1)
 3466-3474  F9.6  [-]       [Zr/Fe]                ?=- Neutral Zr atomic
                                                    abundance (final, 1D-LTE)
                                                    (Zr_fe)
 3476-3484  F9.7  [-]     e_[Zr/Fe]                ?=- Uncertainty Zr_fe
                                                    (e_Zr_fe)
 3486-3487  I2    ---     o_[Zr/Fe]                ?=- Bitmask of used
                                                    measurements for Zr
                                                    (nr_Zr_fe)
 3489-3490  I2    ---     f_[Zr/Fe]                ?=- Quality flag of Zr_fe
                                                    (flag_Zr_fe) (G1)
 3492-3500  F9.6  [-]       [Mo/Fe]                ?=- Neutral Mo atomic
                                                    abundance (final, 1D-LTE)
                                                    (Mo_fe)
 3502-3510  F9.7  [-]     e_[Mo/Fe]                ?=- Uncertainty Mo_fe
                                                    (e_Mo_fe)
      3512  I1    ---     o_[Mo/Fe]                ?=- Bitmask of used
                                                    measurements for Mo
                                                    (nr_Mo_fe)
 3514-3515  I2    ---     f_[Mo/Fe]                ?=- Quality flag of Mo_fe
                                                    (flag_Mo_fe) (G1)
 3517-3525  F9.6  [-]       [Ru/Fe]                ?=- Neutral Ru atomic
                                                    abundance (final, 1D-LTE)
                                                    (Ru_fe)
 3527-3535  F9.7  [-]     e_[Ru/Fe]                ?=- Uncertainty Ru_fe
                                                    (e_Ru_fe)
      3537  I1    ---     o_[Ru/Fe]                ?=- Bitmask of used
                                                    measurements for Ru
                                                    (nr_Ru_fe)
 3539-3540  I2    ---     f_[Ru/Fe]                ?=- Quality flag of Ru_fe
                                                    (flag_Ru_fe) (G1)
 3542-3550  F9.6  [-]       [Ba/Fe]                ?=- Single-ionised Ba atomic
                                                    abundance (final, 1D-NLTE)
                                                    (Ba_fe)
 3552-3560  F9.7  [-]     e_[Ba/Fe]                ?=- Uncertainty Ba_fe
                                                    (e_Ba_fe)
      3562  I1    ---     o_[Ba/Fe]                ?=- Bitmask of used
                                                    measurements for Ba
                                                    (nr_Ba_fe)
 3564-3565  I2    ---     f_[Ba/Fe]                ?=- Quality flag of Ba_fe
                                                    (flag_Ba_fe) (G1)
 3567-3575  F9.6  [-]       [La/Fe]                ?=- Single-ionised La atomic
                                                    abundance (final, 1D-LTE)
                                                    (La_fe)
 3577-3585  F9.7  [-]     e_[La/Fe]                ?=- Uncertainty La_fe
                                                    (e_La_fe)
      3587  I1    ---     o_[La/Fe]                ?=- Bitmask of used
                                                    measurements for La
                                                    (nr_La_fe)
 3589-3590  I2    ---     f_[La/Fe]                ?=- Quality flag of La_fe
                                                    (flag_La_fe) (G1)
 3592-3600  F9.6  [-]       [Ce/Fe]                ?=- Single-ionised Ce atomic
                                                    abundance (final, 1D-LTE)
                                                    (Ce_fe)
 3602-3610  F9.7  [-]     e_[Ce/Fe]                ?=- Uncertainty Ce_fe
                                                    (e_Ce_fe)
      3612  I1    ---     o_[Ce/Fe]                ?=- Bitmask of used
                                                    measurements for Ce
                                                    (nr_Ce_fe)
 3614-3615  I2    ---     f_[Ce/Fe]                ?=- Quality flag of Ce_fe
                                                    (flag_Ce_fe) (G1)
 3617-3625  F9.6  [-]       [Nd/Fe]                ?=- Single-ionised Nd atomic
                                                    abundance (final, 1D-LTE)
                                                    (Nd_fe)
 3627-3635  F9.7  [-]     e_[Nd/Fe]                ?=- Uncertainty Nd_fe
                                                    (e_Nd_fe)
      3637  I1    ---     o_[Nd/Fe]                ?=- Bitmask of used
                                                    measurements for Nd
                                                    (nr_Nd_fe)
 3639-3640  I2    ---     f_[Nd/Fe]                ?=- Quality flag of Nd_fe
                                                    (flag_Nd_fe) (G1)
 3642-3650  F9.6  [-]       [Sm/Fe]                ?=- Single-ionised Sm atomic
                                                    abundance (final, 1D-LTE)
                                                    (Sm_fe)
 3652-3660  F9.7  [-]     e_[Sm/Fe]                ?=- Uncertainty Sm_fe
                                                    (e_Sm_fe)
      3662  I1    ---     o_[Sm/Fe]                ?=- Bitmask of used
                                                    measurements for Sm
                                                    (nr_Sm_fe)
 3664-3665  I2    ---     f_[Sm/Fe]                ?=- Quality flag of Sm_fe
                                                    (flag_Sm_fe) (G1)
 3667-3675  F9.6  [-]       [Eu/Fe]                ?=- Single-ionised Eu atomic
                                                    abundance (final, 1D-LTE)
                                                    (Eu_fe)
 3677-3685  F9.7  [-]     e_[Eu/Fe]                ?=- Uncertainty Eu_fe
                                                    (e_Eu_fe)
      3687  I1    ---     o_[Eu/Fe]                ?=- Bitmask of used
                                                    measurements for Eu
                                                    (nr_Eu_fe)
 3689-3690  I2    ---     f_[Eu/Fe]                ?=- Quality flag of Eu_fe
                                                    (flag_Eu_fe) (G1)
 3692-3706 F15.11 deg       RAdeg                  Right Ascension Gaia DR2
                                                    (ICRS) at Ep=2015.5 (ra_dr2)
 3708-3722 F15.11 deg       DEdeg                  Declination Gaia DR2 (ICRS)
                                                    at Ep=2015.5 (dec_dr2)
 3724-3731  F8.4  mas       plx                    ?=- Parallax propagated from
                                                    Gaia DR2 (parallax_dr2)
 3733-3738  F6.4  mas     e_plx                    ?=- Parallax error propagated
                                                    from Gaia DR2
                                                    (parallax_error_dr2)
 3740-3760 F21.15 pc        rest                   ?=- Estimated distance
                                                    propagated from Bailer-jones
                                                    et al., 2018AJ....156...58B,
                                                    Cat. I/347 (r_est_dr2)
 3762-3782 F21.15 pc      b_rest                   ?=- Lower bound on the
                                                    confidence interval of the
                                                    estimated distance
                                                    propagated from Bailer-jones
                                                    et al., 2018AJ....156...58B,
                                                    Cat. I/347 (r_lo_dr2)
 3784-3804 F21.15 pc      B_rest                   ?=- Upper bound on the
                                                    confidence interval of the
                                                    estimated distance
                                                    propagated from Bailer-jones
                                                    et al., 2018AJ....156...58B,
                                                    Cat. I/347 (r_hi_dr2)
 3806-3822 F17.12 pc        rlen                   ?=- Length scale used in the
                                                    prior for the distance
                                                    estimation propagated from
                                                    Bailer-jones et al.,
                                                    2018AJ....156...58B,
                                                    Cat. I/347 (r_len_dr2)
 3824-3834  F11.6 km/s      RVgalah                ?=- Best-method radial
                                                    velocity from GALAH spectra
                                                    (rv_galah)
 3836-3844  F9.6  km/s    e_RVgalah                ?=- Uncertainty of rv_galah
                                                    (e_rv_galah)
 3846-3856  F11.6 km/s      RVGaiaDR2              ?=- Radial velocity
                                                    propagated from Gaia DR2
                                                    (rv_gaia_dr2)
 3858-3866  F9.6  km/s    e_RVGaiaDR2              ?=- Radial velocity error
                                                    propagated from Gaia DR2
                                                    (e_rv_gaia_dr2)
 3868-3869  I2    ---       redflag                Reduction pipeline quality
                                                    flag (red_flag)
 3871-3877  F7.4  mag       E(B-V)                 SFD extinction value (ebv)
 3879-3887  F9.4  ---       snrc1iraf              Average SNR/px CCD1
                                                    (snr_c1_iraf)
 3889-3897  F9.4  ---       snrc2iraf              Average SNR/px CCD2
                                                    (snr_c2_iraf)
 3899-3907  F9.4  ---       snrc3iraf              Average SNR/px CCD3
                                                    (snr_c3_iraf)
 3909-3918  F10.4 ---       snrc4iraf              ?=- Average SNR/px CCD4
                                                    (snr_c4_iraf)
      3920  I1    ---       flagGUESS              GUESS reduction pipeline
                                                    quality flag (flag_guess)
 3922-3933  F12.6 km/s      RVGUESS                ?=- Reduction pipeline best
                                                    radial velocity (rv_guess)
 3935-3946  E12.6 km/s    e_RVGUESS                []?=- Reduction pipeline
                                                    uncertainty radial velocity
                                                    (e_rv_guess)
 3948-3958  F11.3 K         TeffGUESS              ?=- Reduction pipeline best
                                                    teff (teff_guess)
 3960-3968  F9.3  [cm/s2]   loggGUESS              ?=- Reduction pipeline best
                                                    logg (logg_guess)
 3970-3978  F9.3  [-]       [Fe/H]GUESS            ?=- Reduction pipeline best
                                                    [Fe/H] (feh_guess)
 3980-3982  F3.1  km/s      RV5854                 ?=- Local best fit to RV when
                                                    fitting A(Ba5854) (rv_5854)
 3984-3996  F13.6 km/s      RV6708                 ?=- Local best fit to RV when
                                                    fitting A(Li6708) (rv_6708)
 3998-4006  F9.6  km/s      RV6722                 ?=- Local best fit to RV when
                                                    fitting A(Si6722) (rv_6722)
 4008-4018  F11.6 mag       Vmag                   ?=- V magnitude estimated
                                                    from 2MASS J and Ks mag
                                                    (v_jk)
 4020-4026  F7.3  mag       Jmag                   ?=- J magnitude propagated
                                                    from 2MASS (j_m)
 4028-4032  F5.3  mag     e_Jmag                   ?=- J magnitude error
                                                    propagated from 2MASS
                                                    (j_msigcom)
 4034-4040  F7.3  mag       Hmag                   ?=- H magnitude propagated
                                                    from 2MASS (h_m)
 4042-4046  F5.3  mag     e_Hmag                   ?=- H magnitude error
                                                    propagated from 2MASS
                                                    (h_msigcom)
 4048-4054  F7.3  mag       Ksmag                  ?=- Ks magnitude propagated
                                                    from 2MASS (ks_m)
 4056-4060  F5.3  mag     e_Ksmag                  ?=- Ks magnitude error
                                                    propagated from 2MASS
                                                    (ks_msigcom)
 4062-4064  A3    ---       Qflg2MASS              [ABCDEFU ] Quality flag
                                                    propagated from 2MASS
                                                    ph_qual (ph_qual_tmass)
 4066-4071  F6.3  mag       W2mag                  ?=- W2 magnitude propagated
                                                    from AllWISE (w2mpro)
 4073-4077  F5.3  mag     e_W2mag                  ?=- W2 magnitude propagated
                                                    from AllWISE (w2mpro_error)
 4079-4082  A4    ---       QflgWISE               [ABCUXZ] Quality flag
                                                    propagated from AllWISE
                                                    ph_qual (ph_qual_wise)
 4084-4089  F6.3  mag       AKs                    Used Ks band extinction
                                                    (a_ks)
 4091-4096  F6.3  mag     e_AKs                    ?=- Uncertainty of a_ks
                                                    (e_a_ks)
 4098-4105  F8.6  mag       BCKs                   ?=- Used Bolometric
                                                    Correction for Ks band
                                                    (bc_ks)
 4107-4116  F10.6 ---       RUWE                   ?=- RUWE propagated from
                                                    Gaia DR2 (ruwe_dr2)
--------------------------------------------------------------------------------

Byte-by-byte Description of file: ages.dat
--------------------------------------------------------------------------------
   Bytes Format Units     Label        Explanations
--------------------------------------------------------------------------------
   1- 15  I15   ---       GALAH        GALAH identifier (sobject_id)
  17- 25  F9.6  Gyr       Age          ?=- Age estimate BSTEP-Mod. (age_bstep)
  27- 34  F8.6  Gyr     e_Age          ?=- 1-sigma uncertainty of age_bstep
                                        (e_age_bstep)
  36- 44  F9.6  Gyr       Age16        ?=- 16 percentile value for age_bstep
                                        (e16_age_bstep)
  46- 54  F9.6  Gyr       Age50        ?=- 50 percentile value for age_bstep
                                        (e50_age_bstep)
  56- 64  F9.6  Gyr       Age84        ?=- 84 percentile value for age_bstep
                                        (e84_age_bstep)
  66- 74  F9.6  Msun      Mact         ?=- Actual stellar mass after mass loss
                                        BSTEP-Mod. (m_act_bstep)
  76- 83  F8.6  Msun    e_Mact         ?=- 1-sigma uncertainty of m_act_bstep
                                        (e_m_act_bstep)
  85- 93  F9.6  Msun      Mact16       ?=- 16 percentile value for m_act_bstep
                                        (e16_m_act_bstep)
  95-103  F9.6  Msun      Mact50       ?=- 50 percentile value for m_act_bstep
                                        (e50_m_act_bstep)
 105-113  F9.6  Msun      Mact84       ?=- 84 percentile value for m_act_bstep
                                        (e84_m_act_bstep)
 115-123  F9.6  Msun      Mini         ?=- Initial stellar mass BSTEP-Mod.
                                        (m_ini_bstep)
 125-132  F8.6  Msun    e_Mini         ?=- 1-sigma uncertainty of m_ini_bstep
                                        (e_m_ini_bstep)
 134-142  F9.6  Msun      Mini16       ?=- 16 percentile value for m_ini_bstep
                                        (e16_m_ini_bstep)
 144-152  F9.6  Msun      Mini50       ?=- 50 percentile value for m_ini_bstep
                                        (e50_m_ini_bstep)
 154-162  F9.6  Msun      Mini84       ?=- 84 percentile value for m_ini_bstep
                                        (e84_m_ini_bstep)
 164-173  F10.6 Rsun      Rad          ?=- Stellar Radius BSTEP-Mod.
                                        (radius_bstep)
 175-184  F10.6 Rsun    e_Rad          ?=- 1-sigma uncertainty of radius_bstep
                                        (e_radius_bstep)
 186-195  F10.6 Rsun      Rad16        ?=- 16 percentile value for radius_bstep
                                        (e16_radius_bstep)
 197-206  F10.6 Rsun      Rad50        ?=- 50 percentile value for radius_bstep
                                        (e50_radius_bstep)
 208-217  F10.6 Rsun      Rad84        ?=- 84 percentile value for radius_bstep
                                        (e84_radius_bstep)
 219-222  F4.2  ---       isredclump   [0/1]?=- Probability to be a red clump
                                        star (1.0) or not (0.0) BSTEP-Mod.
                                        (is_redclump_bstep)
 224-227  F4.2  ---     e_isredclump   [0/0.5]?=- 1-sigma uncertainty of
                                        is_redclump_bstep (e_is_redclump_bstep)
 229-233  F5.2  ---       isredclump16 ?=- 16 percentile value for
                                        is_redclump_bstep
                                        (e16_is_redclump_bstep)
 235-238  F4.2  ---       isredclump50 ?=- 50 percentile value for
                                        is_redclump_bstep
                                        (e50_is_redclump_bstep)
 240-243  F4.2  ---       isredclump84 ?=- 84 percentile value for
                                        is_redclump_bstep
                                        (e84_is_redclump_bstep)
 245-254  F10.6 kpc       Dist         ?=- Distance BSTEP-Mod.
                                        (distance_bstep)
 256-265  F10.6 kpc     e_Dist         ?=- 1-sigma uncertainty of
                                        distance_bstep (e_distance_bstep)
 267-276  F10.6 kpc       Dist16       ?=- 16 percentile value for
                                        distance_bstep (e16_distance_bstep)
 278-287  F10.6 kpc       Dist50       ?=- 50 percentile value for
                                        distance_bstep (e50_distance_bstep)
 289-298  F10.6 kpc       Dist84       ?=- 84 percentile value for
                                        distance_bstep (e84_distance_bstep)
 300-308  F9.6  mag       E(B-V)       ?=- Extinction E(B-V) BSTEP-Mod.
                                        (ebv_bstep)
 310-317  F8.6  mag     e_E(B-V)       ?=- 1-sigma uncertainty of ebv_bstep
                                        (e_ebv_bstep)
 319-327  F9.6  mag       E(B-V)16     ?=- 16 percentile value for ebv_bstep
                                        (e16_ebv_bstep)
 329-337  F9.6  mag       E(B-V)50     ?=- 50 percentile value for ebv_bstep
                                        (e50_ebv_bstep)
 339-347  F9.6  mag       E(B-V)84     ?=- 84 percentile value for ebv_bstep
                                        (e84_ebv_bstep)
 349-359  F11.6 K         Teff         ?=- Effective Temperature BSTEP-Mod.
                                        (teff_bstep)
 361-370  F10.6 K       e_Teff         ?=- 1-sigma uncertainty of teff_bstep
                                        (e_teff_bstep)
 372-382  F11.6 K         Teff16       ?=- 16 percentile value for teff_bstep
                                        (e16_teff_bstep)
 384-394  F11.6 K         Teff50       ?=- 50 percentile value for teff_bstep
                                        (e50_teff_bstep)
 396-406  F11.6 K         Teff84       ?=- 84 percentile value for teff_bstep
                                        (e84_teff_bstep)
 408-416  F9.6  [cm/s2]   logg         ?=- Surface gravity BSTEP-Mod.
                                        (logg_bstep)
 418-425  F8.6  [cm/s2] e_logg         ?=- 1-sigma uncertainty of logg_bstep
                                        (e_logg_bstep)
 427-435  F9.6  [cm/s2]   logg16       ?=- 16 percentile value for logg_bstep
                                        (e16_logg_bstep)
 437-445  F9.6  [cm/s2]   logg50       ?=- 50 percentile value for logg_bstep
                                        (e50_logg_bstep)
 447-455  F9.6  [cm/s2]   logg84       ?=- 84 percentile value for logg_bstep
                                        (e84_logg_bstep)
 457-465  F9.6  [-]       [M/H]        ?=- Surface effective [M/H] BSTEP-Mod.
                                        (meh_act_bstep)
 467-474  F8.6  [-]     e_[M/H]        ?=- 1-sigma uncertainty of meh_act_bstep
                                        (e_meh_act_bstep)
 476-484  F9.6  [-]       [M/H]16      ?=- 16 percentile value for meh_act_bstep
                                        (e16_meh_act_bstep)
 486-494  F9.6  [-]       [M/H]50      ?=- 50 percentile value for meh_act_bstep
                                        (e50_meh_act_bstep)
 496-504  F9.6  [-]       [M/H]84      ?=- 84 percentile value for meh_act_bstep
                                        (e84_meh_act_bstep)
 506-514  F9.6  [-]       [M/H]ini     ?=- Intial effective metallicity [M/H]
                                        from isochrones BSTEP-Mod.
                                        (meh_ini_bstep)
 516-523  F8.6  [-]     e_[M/H]ini     ?=- 1-sigma uncertainty of meh_ini_bstep
                                        (e_meh_ini_bstep)
 525-533  F9.6  [-]       [M/H]ini16   ?=- 16 percentile value for meh_ini_bstep
                                        (e16_meh_ini_bstep)
 535-543  F9.6  [-]       [M/H]ini50   ?=- 50 percentile value for meh_ini_bstep
                                        (e50_meh_ini_bstep)
 545-553  F9.6  [-]       [M/H]ini84   ?=- 84 percentile value for meh_ini_bstep
                                        (e84_meh_ini_bstep)
 555-563  F9.6  [Lsun]    logL         ?=- log(Luminosity L/L_sun)
                                        (log_lum_bstep)
 565-572  F8.6  [Lsun]  e_logL         ?=- 1-sigma uncertainty oflogL_bstep
                                        (e_log_lum_bstep)
 574-582  F9.6  [Lsun]    logL16       ?=- 16 percentile value for log_lum_bstep
                                        (e16_log_lum_bstep)
 584-592  F9.6  [Lsun]    logL50       ?=- 50 percentile value for log_lum_bstep
                                        (e50_log_lum_bstep)
 594-602  F9.6  [Lsun]    logL84       ?=- 84 percentile value for log_lum_bstep
                                        (e84_log_lum_bstep)
 604-612  F9.6  mag       JMAG         ?=- Absolute Magnitude 2MASS J
                                        (abs_j_bstep)
 614-621  F8.6  mag     e_JMAG         ?=- 1-sigma uncertainty of abs_j_bstep
                                        (e_abs_j_bstep)
 623-632  F10.6 mag       JMAG16       ?=- 16 percentile value for abs_j_bstep
                                        (e16_abs_j_bstep)
 634-642  F9.6  mag       JMAG50       ?=- 50 percentile value for abs_j_bstep
                                        (e50_abs_j_bstep)
 644-652  F9.6  mag       JMAG84       ?=- 84 percentile value for abs_j_bstep
                                        (e84_abs_j_bstep)
 654-663  F10.6 mag       KsMAG        ?=- Absolute Magnitude 2MASS Ks
                                        (abs_ks_bstep)
 665-673  F9.6  mag     e_KsMAG        ?=- 1-sigma uncertainty of KsMAG_bstep
                                        (e_abs_ks_bstep)
 675-684  F10.6 mag       KsMAG16      ?=- 16 percentile value for abs_ks_bstep
                                        (e16_abs_ks_bstep)
 686-695  F10.6 mag       KsMAG50      ?=- 50 percentile value for abs_ks_bstep
                                        (e50_abs_ks_bstep)
 697-706  F10.6 mag       KsMAG84      ?=- 84 percentile value for abs_ks_bstep
                                        (e84_abs_ks_bstep)
--------------------------------------------------------------------------------

Byte-by-byte Description of file: dyn.dat
--------------------------------------------------------------------------------
   Bytes   Format Units    Label       Explanations
--------------------------------------------------------------------------------
    1-  15  I15   ---      GALAH       GALAH identifier (sobject_id)
        17  I1    ---      usedistflag Distance used (use_dist_flag) (1)
        19  I1    ---      uservflag   RV flag (use_rv_flag) (2)
   21-  30  F10.6 kpc      XXYZ        ?=- Best-value heliocentric Galactic
                                        rectangular x-coordinate (X_XYZ)
   32-  42  F11.6 kpc      YXYZ        ?=- Best-value heliocentric Galactic
                                        rectangular y-coordinate (Y_XYZ)
   44-  53  F10.6 kpc      ZXYZ        ?=- Best-value heliocentric Galactic
                                        rectangular z-coordinate (Z_XYZ)
   55-  66  F12.6 km/s     UUVW        ?=- Best-value heliocentric Galactic
                                        rectangular x-velocity (U_UVW)
   68-  80  F13.6 km/s     VUVW        ?=- Best-value heliocentric Galactic
                                        rectangular y-velocity (V_UVW)
   82-  94  F13.6 km/s     WUVW        ?=- Best-value heliocentric Galactic
                                        rectangular z-velocity (W_UVW)
   96- 105  F10.6 kpc      RRzphi      ?=- Best-value Galactocentric Radius
                                        (R_Rzphi)
  107- 115  F9.6  rad      phiRzphi    ?=- Best-value Galactocentric azimuth
                                        (phi_Rzphi)
  117- 126  F10.6 kpc      zRzphi      ?=- Best-value Galactocentric height
                                        (z_Rzphi)
  128- 139  F12.6 km/s     vRRzphi     ?=- Best-value Galactocentric radial
                                        velocity (vR_Rzphi)
  141- 153  F13.6 km/s     vTRzphi     ?=- Best-value Galactocentric
                                        tangential velocity (vT_Rzphi)
  155- 166  F12.6 km/s     vzRzphi     ?=- Best-value Galactocentric vertical
                                        velocity (vz_Rzphi)
  168- 179  E12.6 kpc.km/s JR          ?=- Best-value radial action (J_R)
  181- 192  E12.6 kpc.km/s LZ          ?=- Best-value azimuthal action/angular
                                        momentum (L_Z)
  194- 205  E12.6 kpc.km/s JZ          ?=- Best-value vertical action (J_Z)
  207- 218  E12.6 Gyr-1    omegaR      ?=- Best-value radial orbit frequency
                                        (omega_R)
  220- 231  E12.6 ---      omegaphi    ?=- Best-value azimuthal orbit
                                        frequency (omega_phi)
  233- 244  E12.6 ---      omegaz      ?=- Best-value vertical orbit frequency
                                        (omega_z)
  246- 257  E12.6 rad      angleR      ?=- Best-value radial orbit angle
                                        (angle_R)
  259- 270  E12.6 rad      anglephi    ?=- Best-value azimuthal orbit angle
                                        (angle_phi)
  272- 283  E12.6 rad      anglez      ?=- Best-value vertical orbit angle
                                        (angle_z)
  285- 296  E12.6 ---      ecc         ?=- Best-value orbit eccentricity (ecc)
  298- 309  E12.6 kpc      zmax        ?=- Best-value maximum Galactocentric
                                        height (zmax)
  311- 322  E12.6 kpc      Rperi       ?=- Best-value Galactocentric
                                        pericenter radius (R_peri)
  324- 335  E12.6 kpc      Rap         ?=- Best-value Galactocentric apocenter
                                        radius (R_ap)
  337- 348  E12.6 km2/s2   Energy      ?=- Best-value orbit energy (Energy)
  350- 359  F10.6 kpc      XXYZ5       ?=- 5th Percentile MC heliocentric
                                        Galactic rectangular x-coordinate
                                        (X_XYZ_5)
  361- 370  F10.6 kpc      XXYZ50      ?=- 50th Percentile MC heliocentric
                                        Galactic rectangular x-coordinate
                                        (X_XYZ_50)
  372- 381  F10.6 kpc      XXYZ95      ?=- 95th Percentile MC heliocentric
                                        Galactic rectangular x-coordinate
                                        (X_XYZ_95)
  383- 393  F11.6 kpc      YXYZ5       ?=- 5th Percentile MC heliocentric
                                        Galactic rectangular y-coordinate
                                        (Y_XYZ_5)
  395- 405  F11.6 kpc      YXYZ50      ?=- 50th Percentile MC heliocentric
                                        Galactic rectangular y-coordinate
                                        (Y_XYZ_50)
  407- 417  F11.6 kpc      YXYZ95      ?=- 95th Percentile MC heliocentric
                                        Galactic rectangular y-coordinate
                                        (Y_XYZ_95)
  419- 429  F11.6 kpc      ZXYZ5       ?=- 5th Percentile MC heliocentric
                                        Galactic rectangular z-coordinate
                                        (Z_XYZ_5)
  431- 440  F10.6 kpc      ZXYZ50      ?=- 50th Percentile MC heliocentric
                                        Galactic rectangular z-coordinate
                                        (Z_XYZ_50)
  442- 451  F10.6 kpc      ZXYZ95      ?=- 95th Percentile MC heliocentric
                                        Galactic rectangular z-coordinate
                                        (Z_XYZ_95)
  453- 464  F12.6 km/s     UUVW5       ?=- 5th Percentile MC heliocentric
                                        Galactic rectangular x-velocity
                                        (U_UVW_5)
  466- 477  F12.6 km/s     UUVW50      ?=- 50th Percentile MC heliocentric
                                        Galactic rectangular x-velocity
                                        (U_UVW_50)
  479- 490  F12.6 km/s     UUVW95      ?=- 95th Percentile MC heliocentric
                                        Galactic rectangular x-velocity
                                        (U_UVW_95)
  492- 504  F13.6 km/s     VUVW5       ?=- 5th Percentile MC heliocentric
                                        Galactic rectangular y-velocity
                                        (V_UVW_5)
  506- 518  F13.6 km/s     VUVW50      ?=- 50th Percentile MC heliocentric
                                        Galactic rectangular y-velocity
                                        (V_UVW_50)
  520- 532  F13.6 km/s     VUVW95      ?=- 95th Percentile MC heliocentric
                                        Galactic rectangular y-velocity
                                        (V_UVW_95)
  534- 545  F12.6 km/s     WUVW5       ?=- 5th Percentile MC heliocentric
                                        Galactic rectangular z-velocity
                                        (W_UVW_5)
  547- 558  F12.6 km/s     WUVW50      ?=- 50th Percentile MC heliocentric
                                        Galactic rectangular z-velocity
                                       (W_UVW_50)
  560- 571  F12.6 km/s     WUVW95      ?=- 95th Percentile MC heliocentric
                                        Galactic rectangular z-velocity
                                        (W_UVW_95)
  573- 582  F10.6 kpc      RRzphi5     ?=- 5th Percentile MC Galactocentric
                                        Radius (R_Rzphi_5)
  584- 593  F10.6 kpc      RRzphi50    ?=- 50th Percentile MC Galactocentric
                                        Radius (R_Rzphi_50)
  595- 604  F10.6 kpc      RRzphi95    ?=- 95th Percentile MC Galactocentric
                                        Radius (R_Rzphi_95)
  606- 614  F9.6  rad      phiRzphi5   ?=- 5th Percentile MC Galactocentric
                                        azimuth (phi_Rzphi_5)
  616- 624  F9.6  rad      phiRzphi50  ?=- 50th Percentile MC Galactocentric
                                        azimuth (phi_Rzphi_50)
  626- 634  F9.6  rad      phiRzphi95  ?=- 95th Percentile MC Galactocentric
                                        azimuth (phi_Rzphi_95)
  636- 646  F11.6 kpc      ZRzphi5     ?=- 5th Percentile MC Galactocentric
                                        height (z_Rzphi_5)
  648- 657  F10.6 kpc      ZRzphi50    ?=- 50th Percentile MC Galactocentric
                                        height (z_Rzphi_50)
  659- 668  F10.6 kpc      ZRzphi95    ?=- 95th Percentile MC Galactocentric
                                        height (z_Rzphi_95)
  670- 681  F12.6 km/s     vRRzphi5    ?=- 5th Percentile MC Galactocentric
                                        radial velocity (vR_Rzphi_5)
  683- 694  F12.6 km/s     vRRzphi50   ?=- 50th Percentile MC Galactocentric
                                        radial velocity (vR_Rzphi_50)
  696- 707  F12.6 km/s     vRRzphi95   ?=- 95th Percentile MC Galactocentric
                                        radial velocity (vR_Rzphi_95)
  709- 721  F13.6 km/s     vTRzphi5    ?=- 5th Percentile MC Galactocentric
                                        tangential velocity (vT_Rzphi_5)
  723- 735  F13.6 km/s     vTRzphi50   ?=- 50th Percentile MC Galactocentric
                                        tangential velocity (vT_Rzphi_50)
  737- 748  F12.6 km/s     vTRzphi95   ?=- 95th Percentile MC Galactocentric
                                        tangential velocity (vT_Rzphi_95)
  750- 761  F12.6 km/s     vzRzphi5    ?=- 5th Percentile MC Galactocentric
                                        vertical velocity (vz_Rzphi_5)
  763- 774  F12.6 km/s     vzRzphi50   ?=- 50th Percentile MC Galactocentric
                                        vertical velocity (vz_Rzphi_50)
  776- 787  F12.6 km/s     vzRzphi95   ?=- 95th Percentile MC Galactocentric
                                        vertical velocity (vz_Rzphi_95)
  789- 800  E12.6 kpc.km/s JR5         ?=- 5th Percentile MC radial action
                                        (J_R_5)
  802- 813  E12.6 kpc.km/s JR50        ?=- 50th Percentile MC radial action
                                        (J_R_50)
  815- 826  E12.6 kpc.km/s JR95        ?=- 95th Percentile MC radial action
                                        (J_R_95)
  828- 839  E12.6 kpc.km/s LZ5         ?=- 5th Percentile MC azimuthal
                                        action/angular momentum (L_Z_5)
  841- 852  E12.6 kpc.km/s LZ50        ?=- 50th Percentile MC azimuthal
                                        action/angular momentum (L_Z_50)
  854- 865  E12.6 kpc.km/s LZ95        ?=- 95th Percentile MC azimuthal
                                        action/angular momentum (L_Z_95)
  867- 878  E12.6 kpc.km/s JZ5         ?=- 5th Percentile MC vertical action
                                        (J_Z_5)
  880- 891  E12.6 kpc.km/s JZ50        ?=- 50th Percentile MC vertical action
                                        (J_Z_50)
  893- 904  E12.6 kpc.km/s JZ95        ?=- 95th Percentile MC vertical action
                                        (J_Z_95)
  906- 917  E12.6 Gyr-1    omegaR5     ?=- 5th Percentile MC radial orbit
                                        frequency (omega_R_5)
  919- 930  E12.6 Gyr-1    omegaR50    ?=- 50th Percentile MC radial orbit
                                        frequency (omega_R_50)
  932- 943  E12.6 Gyr-1    omegaR95    ?=- 95th Percentile MC radial orbit
                                        frequency (omega_R_95)
  945- 956  E12.6 Gyr-1    omegaphi5   ?=- 5th Percentile MC azimuthal orbit
                                        frequency (omega_phi_5)
  958- 969  E12.6 Gyr-1    omegaphi50  ?=- 50th Percentile MC azimuthal orbit
                                        frequency (omega_phi_50)
  971- 982  E12.6 Gyr-1    omegaphi95  ?=- 95th Percentile MC azimuthal orbit
                                        frequency (omega_phi_95)
  984- 995  E12.6 Gyr-1    omegaz5     ?=- 5th Percentile MC vertical orbit
                                        frequency (omega_z_5)
  997-1008  E12.6 Gyr-1    omegaz50    ?=- 50th Percentile MC vertical orbit
                                        frequency (omega_z_50)
 1010-1021  E12.6 Gyr-1    omegaz95    ?=- 95th Percentile MC vertical orbit
                                        frequency (omega_z_95)
 1023-1034  E12.6 rad      angleR5     ?=- 5th Percentile MC radial orbit angle
                                        (angle_R_5)
 1036-1047  E12.6 rad      angleR50    ?=- 50th Percentile MC radial orbit angle
                                        (angle_R_50)
 1049-1060  E12.6 rad      angleR95    ?=- 95th Percentile MC radial orbit angle
                                        (angle_R_95)
 1062-1073  E12.6 rad      anglephi5   ?=- 5th Percentile MC azimuthal orbit
                                        angle (angle_phi_5)
 1075-1086  E12.6 rad      anglephi50  ?=- 50th Percentile MC azimuthal orbit
                                        angle (angle_phi_50)
 1088-1099  E12.6 rad      anglephi95  ?=- 95th Percentile MC azimuthal orbit
                                        angle (angle_phi_95)
 1101-1112  E12.6 rad      anglez5     ?=- 5th Percentile MC vertical orbit
                                        angle (angle_z_5)
 1114-1125  E12.6 rad      anglez50    ?=- 50th Percentile MC vertical orbit
                                        angle (angle_z_50)
 1127-1138  E12.6 rad      anglez95    ?=- 95th Percentile MC vertical orbit
                                        angle (angle_z_95)
 1140-1151  E12.6 ---      ecc5        ?=- 5th Percentile MC orbit eccentricity
                                        (ecc_5)
 1153-1164  E12.6 ---      ecc50       ?=- 50th Percentile MC orbit eccentricity
                                        (ecc_50)
 1166-1177  E12.6 ---      ecc95       ?=- 95th Percentile MC orbit eccentricity
                                        (ecc_95)
 1179-1190  E12.6 kpc      zmax5       ?=- 5th Percentile MC maximum
                                        Galactocentric height (zmax_5)
 1192-1203  E12.6 kpc      zmax50      ?=- 50th Percentile MC maximum
                                        Galactocentric height (zmax_50)
 1205-1216  E12.6 kpc      zmax95      ?=- 95th Percentile MC maximum
                                        Galactocentric height (zmax_95)
 1218-1226  F9.6  kpc      Rperi5      ?=- 5th Percentile MC
                                        Galactocentric pericenter radius
                                        (R_peri_5)
 1228-1236  F9.6  kpc      Rperi50     ?=- 50th Percentile MC Galactocentric
                                        pericenter radius (R_peri_50)
 1238-1246  F9.6  kpc      Rperi95     ?=- 95th Percentile MC Galactocentric
                                        pericenter radius (R_peri_95)
 1248-1257  F10.6 kpc      Rap5        ?=- 5th Percentile MC Galactocentric
                                        apocenter radius (R_ap_5)
 1259-1268  F10.6 kpc      Rap50       ?=- 50th Percentile MC Galactocentric
                                        apocenter radius (R_ap_50)
 1270-1279  F10.6 kpc      Rap95       ?=- 95th Percentile MC Galactocentric
                                        apocenter radius (R_ap_95)
 1281-1292  E12.6 km2/s2   Energy5     ?=- 5th Percentile MC orbit energy
                                        (Energy_5)
 1294-1305  E12.6 km2/s2   Energy50    ?=- 50th Percentile MC orbit energy
                                        (Energy_50)
 1307-1318  E12.6 km2/s2   Energy95    ?=- 95th Percentile MC orbit energy
                                        (Energy_95)
--------------------------------------------------------------------------------
Note (1): Distance used as follows:
           0 = BSTEP
           1 = Photogeom.
           2 = Geom.
           4 = Plx
           8 = n.a.
Note (2): RV flag as follows:
           0 = rv_obst
           1 = rv_sme_v2
           2 = Gaia DR2
           4 = n.a.
--------------------------------------------------------------------------------

Byte-by-byte Description of file: rv.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label      Explanations
--------------------------------------------------------------------------------
   1- 15  I15   ---     GALAH      GALAH identifier (sobject_id)
  17- 27  F11.6 km/s    RVgalah    ?=- Best-method radial velocity from GALAH
                                   spectra (rv_galah)
  29- 37  F9.6  km/s  e_RVgalah    ?=- Uncertainty of rv_galah (e_rv_galah)
      39  I1    ---   f_RVgalah    [0/4] RV flag (use_rv_flag) (1)
  41- 51  F11.6 km/s    RVsmev2    ?=- SME fitted radial velocity from GALAH
                                    spectra with correct vbary correction
                                    (rv_sme_v2)
  53- 63  F11.6 km/s    RVsmev1    ?=- SME fitted radial velocity from GALAH
                                    spectra with wrong vbary correction
                                    (rv_sme_v1)
  65- 73  F9.6  km/s  e_RVsmev2    ?=- Uncertainty of RVsmev2 (e_rv_sme)
  75- 83  F9.6  km/s    coveRVsme  ?=- SME covariance fitting uncertainty
                                    sme.vrad (cov_e_rv_sme)
  85- 97  F13.5 d       HJD        ?=- Heliocentric Julian Date (heliocentricJD)
  99-108  F10.6 km/s    Vbaryv1    ?=- Wrong barycentric correction used for v1
                                    (vbary_v1)
 110-119  F10.6 km/s    Vbaryv2    ?=- Correct barycentric correction used for
                                    v2 (vbary_v2)
 121-131  F11.6 km/s    RVobst     ?=- Radial Velocity with grav. redshift
                                    correction (rv_obst)
 133-140  F8.6  km/s  e_RVobst     ?=- Uncertainty of rv_obst (e_rv_obst)
 142-152  F11.6 km/s    RVnogrobst ?=- Radial Velocity without grav.
                                    redshift correction (rv_nogr_obst)
 154-161  F8.6  km/s  e_RVnogrobst ?=- Uncertainty of rv_nogr_obst
                                    (e_rv_nogr_obst)
 163-173  F11.5 d       MJDlocal   ?=- Modified Julian Date, Middle of Exposure
                                    (MJD_local)
 175-185  F11.6 km/s    RVdr2      ?=- Radial velocity from Gaia DR2
                                    (dr2_radial_velocity)
 187-195  F9.6  km/s  e_RVdr2      ?=- Radial velocity error from Gaia DR2
                                    (dr2_radial_velocity_error)
--------------------------------------------------------------------------------
Note (1): RV flag as follows:
           0 = rv_obst
           1 = rv_sme_v2
           2 = Gaia DR2
           4 = n.a.
--------------------------------------------------------------------------------

Global notes:
Note (G1): Flag as follows: as follows:
    1 = Upper Limit
    2 = Bad fit / large {chi}^2^
    4 = Uncertain measurement / saturation
    8 = Bad wavelength solution / rv for Li6708
   16 = Bad stellar parameter flag (>=128)
   32 = No reliable measurement reported
--------------------------------------------------------------------------------

Acknowledgements:
    Sven Buder, sven.buder(at)anu.edu.au

================================================================================
(End)                                      Patricia Vannier [CDS]    03-Sep-2021
