import sys
from pathlib import Path
sys.path.insert(0,'scripts')
import qlp_stellar_metadata as b
from adastra.archive import write_json,utc_now,sha256_file
out=Path('data/qlp-sap-stellar-201308024')
q='SELECT * FROM gaiadr3.nss_two_body_orbit WHERE source_id=4906011953900670976'
write_json(out/'nss-primary-amendment.json',{'created_utc':utc_now(),'query':q,'source_sha256':sha256_file(Path(__file__)),'purpose':'Explicit exact-primary orbit nonmatch check; primary published NSSflag0'})
r=b.tap(b.GAIA,q,out/'nss-primary-two-body.json');write_json(out/'nss-primary-result.json',{'rows':r})
print(r)
