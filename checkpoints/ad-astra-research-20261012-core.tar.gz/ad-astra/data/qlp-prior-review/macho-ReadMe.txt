J/AJ/136/1242       LMC long-period variables from MACHO     (Fraser+, 2008)
================================================================================
The properties of long-period variables in the Large Magellanic Cloud from
MACHO.
    Fraser O.J., Hawley S.L., Cook K.H.
   <Astron. J., 136, 1242-1258 (2008)>
   =2008AJ....136.1242F
================================================================================
ADC_Keywords: Magellanic Clouds ; Stars, variable ; Photometry, Cousins
Keywords: galaxies: individual (LMC) - stars: AGB and post-AGB -
          stars: variables: other

Abstract:
    We present a new analysis of the long-period variables in the Large
    Magellanic Cloud (LMC) from the MACHO Variable Star Catalog.
    Three-quarters of our sample of evolved, variable stars have periodic
    light curves. We characterize the stars in our sample using the
    multiple periods found in their frequency spectra. Additionally, we
    use single-epoch Two Micron All Sky Survey measurements to construct
    the average infrared light curves for different groups of these stars.

File Summary:
--------------------------------------------------------------------------------
 FileName   Lrecl  Records   Explanations
--------------------------------------------------------------------------------
ReadMe         80        .   This file
table1.dat    156    56453   The SuperSmoother and CLEANest analyses of the
                              LPV sample in the LMC
--------------------------------------------------------------------------------

See also:
   II/247 : Variable Stars in the Large Magellanic Clouds (MACHO, 2001)

Byte-by-byte Description of file: table1.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label     Explanations
--------------------------------------------------------------------------------
   1- 14  A14   ---     MACHO     MACHO field.tile.sequence identifier
  16- 23  F8.5  deg     RAdeg     Right Ascension in decimal degrees (J2000)
  25- 33  F9.5  deg     DEdeg     Declination in decimal degrees (J2000)
  35- 41  F7.2  d       Rper      Red period from SuperSmoother analysis (1)
  43- 49  F7.2  d       Bper      Blue period from SuperSmoother analysis (1)
  51- 56  F6.2  mag     RSmag     Red magnitude from SuperSmoother analysis
  58- 63  F6.2  mag     BSmag     Blue magnitude from SuperSmoother analysis
  65- 71  F7.3  mag     Ramp      ?=-99. Red amplitude from
                                         SuperSmoother analysis (1)
  73- 79  F7.3  mag     Bamp      ?=-99. Blue amplitude from
                                         SuperSmoother analysis (1)
  81- 87  F7.2  d       Per0      ?=-99. Primary Fourier period in
                                         Blue light curve (1)
  89- 95  F7.3  mag     Bamp0     ?=-99. Primary Fourier amplitude in
                                         Blue light curve (1)
  97-103  F7.2  d       Per1      ?=-99. Secondary Fourier period in
                                         Blue light curve (1)
 105-111  F7.3  mag     Bamp1     ?=-99. Secondary Fourier amplitude in
                                         Blue light curve (1)
 113-117  F5.2  mag     Vmag      MACHO V (Cousins) band magnitude
 119-123  F5.2  mag     Rmag      MACHO R (Cousins) band magnitude
 125-130  F6.2  mag     Wmag      MACHO "W" reddening-free magnitude (2)
 132-137  F6.2  mag     Jmag      ?=-99.00 2MASS J band magnitude (1)
 139-144  F6.2  mag     Hmag      ?=-99.00 2MASS H band magnitude (1)
 146-151  F6.2  mag     Ksmag     ?=-99.00 2MASS Ks band magnitude (1)
 153-156  I4    ---     Type      ?=-99 Source variability type (3)
--------------------------------------------------------------------------------
Note (1): A "-99.0" indicates no data.
Note (2): Where the reddening-free W magnitude is defined as: W=R-4(V-R).
Note (3): Classification on the Fourier period-luminosity diagram 
     as described in the paper:
     1-4 = the object lies on Sequences 1-4,
      -1 = indicates Sequence E,
      -2 = indicates Sequence D,
       9 = indicates that the star is identified with the One-Year Artifact,
       0 = is a star outside the boundaries of any period-luminosity
           classification, 
     -99 = we were unable to classify this star, most likely due 
           to the lack of a Red light curve or a Ks magnitude.
--------------------------------------------------------------------------------

History:
    From electronic version of the journal

References:
     Fraser, Paper I   2005AJ....129..768F

================================================================================
(End)                  Greg Schwarz [AAS], Patricia Vannier [CDS]    06-Apr-2011
