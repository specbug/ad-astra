J/ApJ/930/7  Rot. distributions from TESS-APOGEE-Kepler-Gaia  (Avallone+, 2022)
================================================================================
Rotation distributions around the Kraft break with TESS and Kepler: the
influences of age, metallicity, and binarity.
    Avallone E.A., Tayar J.N., van Saders J.L., Berger T.A., Claytor Z.R.,
    Beaton R.L., Teske J., Godoy-Rivera D., Pan K.
   <Astrophys. J., 930, 7 (2022)>
   =2022ApJ...930....7A
================================================================================
ADC_Keywords: Rotational velocities; Abundances; Stars, diameters;
              Stars, masses; Photometry; Optical; Binaries, spectroscopic;
              Infrared sources
Keywords: Low mass stars ; Stellar rotation ; Binary stars ;
          Spectroscopic binary stars ; Astrometric binary stars ;
          Wide binary stars ; Close binary stars ; Stellar evolution ;
          Stellar evolutionary models

Abstract:
    Stellar rotation is a complex function of mass, metallicity, and age
    and can be altered by binarity. To understand the importance of these
    parameters in main-sequence stars, we have assembled a sample of
    observations that spans a range of these parameters using a
    combination of observations from The Transiting Exoplanet Survey
    Satellite (TESS) and the Kepler Space Telescope. We find that while we
    can measure rotation periods and identify other classes of stellar
    variability (e.g., pulsations) from TESS light curves, instrument
    systematics prevent the detection of rotation signals longer than the
    TESS orbital period of 13.7 days. Due to this detection limit, we also
    use rotation periods constrained using rotational velocities measured
    by the APOGEE spectroscopic survey and radii estimated using the Gaia
    mission for both TESS and Kepler stars. From these rotation periods,
    we (1) find we can track rotational evolution along discrete mass
    tracks as a function of stellar age, (2) find we are unable to recover
    trends between rotation and metallicity that were observed by previous
    studies, and (3) note that our sample reveals that wide binary
    companions do not affect rotation, while close binary companions cause
    stars to exhibit more rapid rotation than single stars.

Description:
    We use Cycle 1 data from the Transiting Exoplanet Survey Satellite
    (TESS) southern continuous viewing zone (SCVZ) and spectroscopic
    parameters from an APOGEE External Program through Carnegie
    Observatories.

    APOGEE data are collected with the 2.5m Sloan Digital Sky Survey
    (SDSS) telescope at Apache Point Observatory and with the 2.5m du Pont
    telescope at Las Campanas Observatory using near-twin H-band
    spectrographs as part of the fourth campaign of SDSS (SDSS-IV).
    APOGEE DR16 plus includes observations up to 2020 March (MJD=58932),
    and APOGEE DR16 (III/284) includes observations up to August 2018
    (MJD=58358).

    We augment our TESS-APOGEE SCVZ sample with stars observed by APOGEE
    and the Kepler Space Telescope.

    We finally use stellar parallaxes from Gaia data release 2 (I/345),
    K-band magnitudes from 2MASS (II/246), and Teff and [Fe/H] from APOGEE
    to improve our estimates of the radii of stars in our final sample.
    See Section 2.

File Summary:
--------------------------------------------------------------------------------
 FileName   Lrecl  Records  Explanations
--------------------------------------------------------------------------------
ReadMe         80        .  This file
table1.dat    137     4216  Properties of stars with recovered rotation periods,
                             potential binaries, pulsating stars, and stars with
                             no detected variability in our TESS and Kepker
                             samples
table2.dat    101      169  Rotation periods for our TESS sample
--------------------------------------------------------------------------------

See also:
 II/246  : 2MASS All-Sky Catalog of Point Sources (Cutri+ 2003)
 V/133   : Kepler Input Catalog (Kepler Mission Team, 2009)
 I/345   : Gaia DR2 (Gaia Collaboration, 2018)
 IV/38   : TESS Input Catalog - v8.0 (TIC-8) (Stassun+, 2019)
 III/284 : APOGEE-2 data from DR16 (Johnsson+, 2020)
 V/154   : Sloan Digital Sky Surveys (SDSS), Release 16 (DR16) (Ahumada+, 2020)
 IV/39   : TESS Input Catalog version 8.2 (TIC v8.2) (Paegert+, 2021)
 I/355   : Gaia DR3 Part 1. Main source (Gaia Collaboration, 2022)
 J/ApJ/687/1264   : Age estimation for solar-type dwarfs (Mamajek+, 2008)
 J/ApJ/695/679    : Stellar rotation in M35 (Meibom+, 2009)
 J/ApJ/733/L9     : Stellar rotation for 71 NGC 6811 members (Meibom+, 2011)
 J/A+A/537/A146   : Stellar models with rot. 0.8<M<120, Z=0.014 (Ekstrom+, 2012)
 J/MNRAS/432/1203 : Rotation periods of M-dwarf stars (McQuillan+, 2013)
 J/ApJ/775/L11    : Stellar rotation periods for KOIs (McQuillan+, 2013)
 J/A+A/557/L10    : Rotation periods of 12000 Kepler stars (Nielsen+, 2013)
 J/A+A/560/A4     : Rotation periods of active Kepler stars (Reinhold+, 2013)
 J/ApJ/776/67     : Rotational tracks (van Saders+, 2013)
 J/ApJ/780/159    : Rot-mass-age relationship of old stars (Epstein+, 2014)
 J/A+A/572/A34    : Pulsating solar-like stars in Kepler (Garcia+, 2014)
 J/ApJS/211/24    : Rotation periods of Kepler MS stars (McQuillan+, 2014)
 J/A+A/583/A65    : Active Kepler stars differential rotation (Reinhold+, 2015)
 J/ApJS/221/24    : SDSS-III APOGEE H-band spectral line lists (Shetrone+, 2015)
 J/ApJ/807/82     : Rotational velocities of APOKASC red giants (Tayar+, 2015)
 J/AJ/151/144     : ASPCAP weights for APOGEE chemical elements (Garcia+, 2016)
 J/A+A/605/A111   : Surface rotation of Kepler red giant stars (Ceillier+, 2017)
 J/ApJ/842/83     : Praesepe members rot. periods from K2 LCs (Douglas+, 2017)
 J/ApJ/835/75     : Common proper motion stars in the Kepler field (Janes, 2017)
 J/AJ/154/250     : Kepler EB classifications & rotation periods (Lurie+, 2017)
 J/ApJ/839/92     : Praesepe members with K2 light curve data (Rebull+, 2017)
 J/ApJ/866/99     : Radii of KIC stars & planets with Gaia DR2 (Berger+, 2018)
 J/ApJ/860/43     : BANYAN. XII. New members from Gaia-Tycho data (Gagne+, 2018)
 J/MNRAS/490/4040 : {delta} Scuti & {gamma} Dor stars in TESS (Antoci+, 2019)
 J/ApJ/879/49     : Rot. periods for Gaia members of NGC 6811 (Curtis+, 2019)
 J/MNRAS/485/2380 : Gaia-derived luminosities of Kepler stars (Murphy+, 2019)
 J/ApJ/872/L9     : TESS obs. of massive O and B stars (Pedersen+, 2019)
 J/ApJS/244/21    : Surface rot. & activity of Kepler stars. I. (Santos+, 2019)
 J/ApJ/871/174    : Kepler rapid rotators and Ks-band excesses (Simonian+, 2019)
 J/MNRAS/499/3481 : Metallicity and rotation in the Kepler field (Amard+, 2020)
 J/AJ/159/280     : Gaia-Kepler stellar properties cat. I. KIC (Berger+, 2020)
 J/A+A/640/A36    : OB stars TESS phot. & high-resolution sp. (Bowman+, 2020)
 J/ApJ/888/43     : APOGEE-Kepler Cool Dwarf star ages (Claytor+, 2020)
 J/ApJ/904/140    : R147 members & rot. data for 5 other cl. (Curtis+, 2020)
 J/A+A/641/A51    : NGC 2516 membership list (Fritzewski+, 2020)
 J/ApJS/250/20    : Rot. periods in TESS objects of interest (Canto+, 2020)
 J/ApJ/898/76     : Rot. vel. of APOGEE stars in Kepler field (Simonian+, 2020)
 J/ApJS/257/46    : Membership and rot. data for clusters (Godoy-Rivera+, 2021)
 J/other/NatAs/5.707 : Dwarf stars asteroseismic rotation rates (Hall+, 2021)
 J/AJ/161/189     : Gyro-kinematic ages for ~30000 Kepler stars (Lu+, 2021)
 J/A+A/649/A147   : Spectroscopic parameters for 313 M dwarfs (Sarmento+, 2021)

Byte-by-byte Description of file: table1.dat
--------------------------------------------------------------------------------
   Bytes Format Units     Label    Explanations
--------------------------------------------------------------------------------
  1-   4 I4     ---       Seq      [0/4215] Internal index number
  6-  11 A6     ---       Mission  Mission identifier (TESS: 2115 sources or
                                    Kepler: 2101 sources)
 13-  21 I9     ---       ID       [1025494/453102522] TIC or KIC identifier
 23-  28 F6.1   K         Teff     [5600/7990] Effective temperature
 30-  34 F5.1   K       e_Teff     [107/299] Uncertainty in Teff
 36-  39 F4.2   [cm/s2]   logg     [3.1/5] Log surface gravity
 41-  44 F4.2   [cm/s2] e_logg     [0.06/0.2] Uncertainty in logg
 46-  50 F5.2   km/s      vsini    [1.5/87.8]? Projected rotational velocity
 52-  59 F8.2   [Sun]     [Fe/H]   [-1.6/0.5]?=-9999.99 Metallicity
 61-  67 F7.2   [Sun]   e_[Fe/H]   [0.01/0.1]?=-999.99 Uncertainty in [Fe/H]
 69-  76 F8.2   [Sun]     [a/Fe]   [-0.55/0.52]?=-9999.99 Log {alpha}/Fe
                                    abundance ratio
 78-  84 F7.2   [Sun]   e_[a/Fe]   [0/0.06]?=-999.99 Uncertainty in [a/Fe]
 86-  89 F4.2   Rsun      Rad      [0/6.01]? Radius (1)
 91-  94 F4.2   Rsun    E_Rad      [0/1.4]? Upper uncertainty in Rad
 96-  99 F4.2   Rsun    e_Rad      [0/1]? Lower uncertainty in Rad
101- 104 F4.2   Msun      Mass     [0.69/2.6]? Mass (1)
106- 109 F4.2   Msun    E_Mass     [0/0.4]? Upper uncertainty in Mass
111- 114 F4.2   Msun    e_Mass     [0/0.4]? Lower uncertainty in Mass
116- 137 A22    ---       Class    Classification flag (2)
--------------------------------------------------------------------------------
Note (1): Estimated using isoclassify (Berger+ 2020, J/AJ/159/280).
Note (2): Classification flag as follows:
   McQuillan Nondetection = McQuillan+ (2014, J/ApJS/211/24) nondetections
                             (1080 occurrences)
   Pulsator               = See Section 3.1 (27 occurrences)
   RUWE Binary            = Gaia RUWE>1.2, potential binary; see Section 3.2
                             (803 occurrences)
   Rotator                = 819 occurrences
   Spectroscopic Binary   = See Section 3.2 (56 occurrences)
   Suspect Detection      = stars with inconsistent Prot and Prot/sini;
                             see Section 3.3 (1431 occurrences)
--------------------------------------------------------------------------------

Byte-by-byte Description of file: table2.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label    Explanations
--------------------------------------------------------------------------------
   1-  3 I3     ---     Seq      [0/168] Internal index number
   5-  8 A4     ---     Mission  Mission identifier (always "TESS")
  10- 18 I9     ---     ID       [25080230/391903064] TIC identifier
  20- 39 A20    ---     Bin      Binary flag ("Single Star": 166 sources vs
                                  "Spectroscopic Binary": 3 occurrences)
  41- 45 F5.2   d       PLS      [0.4/12.2] Period from Lomb-Scargle periodogram
  47- 50 F4.2   d     e_PLS      [0/1.3] Uncertainty in PLS
  52- 56 F5.2   d       PWave    [0.8/11.7] Period from Wavelet analysis
  58- 61 F4.2   d     e_PWave    [0.09/6.3] Uncertainty in Pwave
  63- 67 F5.2   d       PAcf     [0.8/19.5] Period from autocorrelation
                                  function analysis
  69- 72 F4.2   d     e_PAcf     [0.09/7.6] Uncertainty in Pacf
  74- 78 F5.2   d       PRot     [0.9/10.5] Mean photometric rotational
                                  period (1)
  80- 83 F4.2   d     e_PRot     [0.1/0.8] Uncertainty in PRot
  85- 89 F5.2   d       PRotc    [1/44.2]? Rotational period divided by sini (1)
  91- 95 F5.2   d     E_PRotc    [0.06/71]? Upper uncertainty in PRotc
  97-101 F5.2   d     e_PRotc    [0.06/27.1]? Lower uncertainty in PRotc
--------------------------------------------------------------------------------
Note (1): Derived from APOGEE spectra and Gaia radii.
--------------------------------------------------------------------------------

History:
    From electronic version of the journal

================================================================================
(End)                    Prepared by [AAS], Emmanuelle Perret [CDS]  12-Mar-2024
