J/ApJS/240/17 Exoplanets in the Antarctic sky. II. 116 candidates (Zhang+, 2019)
================================================================================
Exoplanets in the Antarctic sky.
II. 116 transiting exoplanet candidates found by AST3-II (CHESPA) within the
southern CVZ of TESS.
    Zhang H., Yu Z., Liang E., Yang M., Ashley M.C.B., Cui X., Du F., Fu J.,
    Gong X., Gu B., Hu Yi, Jiang P., Liu H., Lawrence J., Liu Q., Li X., Li Z.,
    Ma B., Mould J., Shang Z., Suntzeff N.B., Tao C., Tian Q., Tinney C.G.,
    Uddin S.A., Wang L., Wang S., Wang X., Wei P., Wright D., Wu X.,
    Wittenmyer R.A., Xu L., Yang S.-H., Yu Ce, Yuan X., Zheng J., Zhou H.,
    Zhou J.-L., Zhu Z.
   <Astrophys. J. Suppl. Ser., 240, 17 (2019)>
   =2019ApJS..240...17Z
================================================================================
ADC_Keywords: Exoplanets; Photometry, SDSS; Surveys; Stars, double and multiple;
              Stars, diameters
Keywords: binaries: eclipsing ; catalogs ; planets and satellites: detection ;
          stars: variables: general ; surveys ; techniques: photometric

Abstract:
    We report first results from the CHinese Exoplanet Searching Program
    from Antarctica (CHESPA)--a wide-field high-resolution photometric
    survey for transiting exoplanets carried out using telescopes of the
    AST3 (Antarctic Survey Telescopes times 3) project. There are now
    three telescopes (AST3-I, AST3-II, and CSTAR-II) operating at Dome A
    --the highest point on the Antarctic Plateau-- in a fully automatic
    and remote mode to exploit the superb observing conditions of the
    site, and its long and uninterrupted polar nights. The search for
    transiting exoplanets is one of the key projects for AST3. During the
    austral winters of 2016 and 2017 we used the AST3-II telescope to
    survey a set of target fields near the southern ecliptic pole, falling
    within the continuous viewing zone of the TESS mission. The first data
    release of the 2016 data, including images, catalogs, and light curves
    of 26578 bright stars (7.5<=m_i_<=15), was presented in Zhang+ (2018,
    J/ApJS/240/16). The best precision, as measured by the rms of the
    light curves at the optimum magnitude of the survey (m_i_=10), is
    around 2mmag. We detect 222 objects with plausible transit signals
    from these data, 116 of which are plausible transiting exoplanet
    candidates according to their stellar properties as given by the TESS
    Input Catalog, Gaia DR2, and TESS-HERMES spectroscopy. With the first
    data release from TESS expected in late 2018, this candidate list will
    be timely for improving the rejection of potential false-positives.

Description:
    The CHinese Exoplanet Searching Program from Antarctica (CHESPA)
    --described in Paper I; Zhang+, 2018, J/ApJS/240/16 -- has been
    running since 2012 using the CSTAR and AST3 (Antarctic Survey
    Telescopes times 3) telescopes.
    To maximize collaboration with TESS and enhance the scientific
    importance of our searching program, we selected 48 target fields
    close to the South Ecliptic Pole (RAJ2000=06:00:00,DEJ2000=-66:33:00)
    and within the TESS' Southern continuous viewing zone (CVZ).

File Summary:
--------------------------------------------------------------------------------
 FileName    Lrecl  Records  Explanations
--------------------------------------------------------------------------------
ReadMe          80        .  This file
table2.dat      92      222  Fitted parameters of exoplanet candidates
                              from AST3-II observations in 2016
table3.dat     110      222  Stellar properties of exoplanet candidates
                              from AST3-II observations in 2016
--------------------------------------------------------------------------------

See also:
 II/278           : Transits observed in OGLE 2001-2003 (Udalski+, 2002-2004)
 I/345            : Gaia DR2 (Gaia Collaboration, 2018)
 J/MNRAS/372/1117 : SuperWASP exoplanetary transit survey (Christian+, 2006)
 J/MNRAS/381/851  : SuperWASP-North extrasolar planet cand. (Clarkson+, 2007)
 J/MNRAS/379/647  : SuperWASP-North extrasolar planet candidates (Lister+, 2007)
 J/MNRAS/379/816  : SuperWASP-North extrasolar planet candidates (Street+, 2007)
 J/MNRAS/384/1097 : SuperWASP-North extrasolar planet candidates (Kane+, 2008)
 J/PASP/122/347   : Chinese Small Telescope ARray (CSTAR) (Zhou+, 2010)
 J/AJ/142/155     : Variable stars photometry from Dome A (Wang+, 2011)
 J/AJ/151/166     : Flares & variables from 2009-2010 CSTAR (Oelkers+, 2016)
 J/AJ/153/104     : Variables observed in Galactic disk by AST3-1 (Wang+, 2017)
 J/ApJS/240/16    : Exoplanets in Antarctic sky. I. AST3-II DR1 (Zhang+, 2019)
 http://www.physics.usyd.edu.au/tess-hermes/ : TESS-HERMES home page

Byte-by-byte Description of file: table2.dat
--------------------------------------------------------------------------------
   Bytes Format Units Label Explanations
--------------------------------------------------------------------------------
   1-  6 A6     ---   ---   [AST3II]
   7- 14 F8.4   deg   RAdeg Target right ascension (J2000)
  15- 22 F8.4   deg   DEdeg Target declination (J2000)
  24- 28 F5.2   mag   imag  [7.5/15.4] APASS/Sloan i-band AB magnitude
  30- 40 F11.6  d     Epoch [1477.6/1530.3] Epoch; JD-2456000
  42- 47 F6.4   d     Per   [0.2/6] Observed period of transit signal
  49- 53 F5.3   mag   dmag  [0.002/0.07] Transit depth in Sloan i-band magnitude
  55- 59 F5.3   h     Tdur  [0.3/6.3] Observed transit duration
  61- 64 F4.1   ---   SRN   [5/22.1] Signal-to-Red-Noise-Ratio of the
                             transit event
  66- 70 F5.3   ---   Rp/R* [0.03/0.3] Ratio, planet fitted radius to host star
                             radius (1)
  72- 77 F6.3   ---   a/R*  [1.5/27.6] Ratio, planet fitted semi-major axis
                             to host star radius
  79- 83 F5.2   deg   Inc   [86.9/93.1] Fitted inclination
  85- 88 F4.2   ---   eta   [0.4/1.8] Ratio, observed transit duration to
                             the theoretical duration: {eta}=T_dur_/T_theory_
  90- 92 A3     ---   Label Label(s) (G1)
--------------------------------------------------------------------------------
Note (1): The fit is based the model given
           by Mandel & Agol (2002ApJ...580L.171M).
--------------------------------------------------------------------------------

Byte-by-byte Description of file: table3.dat
--------------------------------------------------------------------------------
   Bytes Format Units Label  Explanations
--------------------------------------------------------------------------------
   1-  8 F8.4   deg   RAdeg  Target right ascension (J2000)
   9- 16 F8.4   deg   DEdeg  Target declination (J2000)
  18- 26 I9     ---   TIC    [41087772/453098052]? TESS Input Catalog ID (1)
  28- 28 I1     ---   Flag   [0/1] CTL flag (1= also present in the Candidate
                              Target List of TESS) (1)
  30- 48 I19    ---   Gaia   ? Gaia DR2 identifier (2)
  50- 54 F5.2   mag   imag   [7.5/15.4] APASS/Sloan i-band AB magnitude
  56- 60 F5.2   mag   Tmag   [6.5/14]? TESS magnitude (1)
  62- 66 F5.2   mag   rpmag  [6.5/14.1]? Gaia RP magnitude (2)
  68- 72 F5.2   Rsun  R*tic  [0.1/23.1]? Stellar radii, TESS input catalog (1)
  74- 79 F6.2   Rsun  R*gaia [0.5/105]? Stellar radius, Gaia DR2 (2)
  81- 86 F6.2   Rsun  R*her  [0.4/100.5]? Stellar radius, TESS-HERMES survey (3)
  88- 93 F6.4   Msun  M*tic  [0.1/2.4]? Stellar mass, TESS Input Catalog (1)
  95-100 F6.4   d     Per    [0.2/6] Observed period of transit signal
 102-106 F5.3   ---   Rp/R*  [0.03/0.3] Ratio, planet radius to host star radius
 108-110 A3     ---   Label  Label(s) (G1)
--------------------------------------------------------------------------------
Note (1): TESS Input Catalog (TIC): Stassun+, 2018, J/AJ/156/102
Note (2): Gaia DR2: Gaia Collaboration, 2018, I/345 ;
            <<Gaia DR2 NNNNNNNNNNNNNNNNNNN> in Simbad.
Note (3): TESS-HERMES survey: Sharma+ 2018MNRAS.473.2004S
--------------------------------------------------------------------------------

Global notes:
Note (G1): Labels from AST3-II observation as follows:
     TC  = Transit Candidate (72 occurrences);
     TC? = Transit Candidate but needs further inspection (44 occurrences);
     LB  = Low-depth Binary (106 occurrences).
--------------------------------------------------------------------------------

Nomenclature Notes:
    Sources are named <[ZYL2019] AST3II JDDD.dddd+DD.dddd> in Simbad.

History:
    From electronic version of the journal

References:
    Zhang et al.   Paper I.     2019ApJS..240...16Z   Cat. J/ApJS/240/16
    Zhang et al.   Paper II.    2019ApJS..240...17Z   This catalog
    Liang et al.   Paper III.   2020AJ....159..201L
    Zhu et al.     Paper IV.    2020AJ....159..172Z
    Zhao et al.    Paper V.     2025ApJS..278...47Z   Cat. J/ApJS/278/47

================================================================================
(End)                     Prepared by [AAS], Emmanuelle Perret [CDS] 14-May-2019
