J/ApJ/962/47     TESS stellar rotation in the Southern CVZ     (Claytor+, 2024)
================================================================================
TESS stellar rotation up to 80 days in the Southern Continuous Viewing Zone.
    Claytor Z.R., van Saders J.L., Cao L., Pinsonneault M.H., Teske J.,
    Beaton R.L.
   <Astrophys. J., 962, 47 (2024)>
   =2024ApJ...962...47C
================================================================================
ADC_Keywords: Photometry; Optical; Stars, ages; Stars, masses; Stars, diameters;
              Abundances; Effective temperatures; Surveys; Spectra, infrared
Keywords: Stellar populations ; Computational astronomy ; Stellar evolution ;
          Stellar physics ; Starspots ; Light curves ;
          Convolutional neural networks ; Stellar activity ; Stellar rotation ;
          Stellar properties

Abstract:
    The Transiting Exoplanet Survey Satellite (TESS) mission delivers
    time-series photometry for millions of stars across the sky, offering
    a probe into stellar astrophysics, including rotation, on a population
    scale. However, light-curve systematics related to the satellite's
    13.7 day orbit have prevented stellar rotation searches for periods
    longer than 13 days, putting the majority of stars beyond reach.
    Machine-learning methods have the ability to identify systematics and
    recover robust signals, enabling us to recover rotation periods up to
    35 days for GK dwarfs and 80 days for M dwarfs. We present a catalog
    of 7245 rotation periods for cool dwarfs in the Southern Continuous
    Viewing Zone, estimated using convolutional neural networks. We find
    evidence for structure in the period distribution consistent with
    prior Kepler and K2 results, including a gap in 10-20 day cool-star
    periods thought to arise from a change in stellar spin-down or
    activity. Using a combination of spectroscopic and gyrochronologic
    constraints, we fit stellar evolution models to estimate masses and
    ages for stars with rotation periods. We find strong correlations
    between the detectability of rotation in TESS and the effective
    temperature, age, and metallicity of the stars. Finally, we
    investigate the relationships between rotation and newly obtained spot
    filling fractions estimated from Apache Point Observatory Galactic
    Evolution Experiment spectra. Field starspot filling fractions are
    elevated in the same temperature and period regime where open
    clusters' magnetic braking stalls, lending support to an internal
    shear mechanism that can produce both phenomena.

Description:
    We selected relatively bright, cool dwarf and subgiant stars in the
    TESS Southern Continuous Viewing Zone (SCVZ), a 450deg^2^ field
    centered around the southern ecliptic pole. TESS observed the SCVZ
    continuously for 350d in its first year, taking full-frame images
    (FFIs) every 30min.

    We supplement TESS photometric rotation periods with spectroscopic
    parameters from the Apache Point Observatory Galactic Evolution
    Experiment (APOGEE; R~22500 in 1.51-1.70um). We cross-matched the TIC
    SCVZ cool dwarfs with APOGEE Data Release 17 (see III/286). We also
    supplemented our sample with data from Gaia Data Release 3 (see I/355).

    See Section 2 for further explanations.

File Summary:
--------------------------------------------------------------------------------
 FileName    Lrecl  Records  Explanations
--------------------------------------------------------------------------------
ReadMe          80        .  This file
table5.dat     200     7245  Properties of 7,245 rotationally detected TESS
                              Southern Continuous Viewing Zone (SCVZ) stars, 
			      MCMC input & fit parameters
table6.dat     121    35664  Properties of 35,664 rotationally nondetected TESS
                              SCVZ stars
--------------------------------------------------------------------------------

See also:
 IV/34   : K2 Ecliptic Plane Input Catalog (EPIC) (Huber+, 2017)
 IV/38   : TESS Input Catalog - v8.0 (TIC-8) (Stassun+, 2019)
 IV/39   : TESS Input Catalog version 8.2 (TIC v8.2) (Paegert+, 2021)
 III/286 : APOGEE-2 DR17 final allStar catalog (Abdurro'uf+, 2022)
 I/355   : Gaia DR3 Part 1. Main source (Gaia Collaboration, 2022)
 I/357   : Gaia DR3 Part 3. Non-single stars (Gaia Collaboration, 2022)
 J/ApJ/732/39     : Rotational velocities of K giant stars (Carlberg+, 2011)
 J/ApJ/743/48     : Rotation periods & X-ray luminosities (Wright+, 2011)
 J/PASP/124/1279  : Q3 Kepler's combined photometry (Christiansen+, 2012)
 J/MNRAS/432/1203 : Rotation periods of M-dwarf stars (McQuillan+, 2013)
 J/A+A/562/A71    : Abundances of solar neighbourhood dwarfs (Bensby+, 2014)
 J/ApJS/211/24    : Rotation periods of Kepler MS stars (McQuillan+, 2014)
 J/AJ/149/68      : A-F type variable stars from Kepler (Bradley+, 2015)
 J/AJ/151/144     : ASPCAP weights for APOGEE chemical elements (Garcia+, 2016)
 J/ApJS/224/2     : K2 EPIC stellar properties for 138600 targets (Huber+, 2016)
 J/MNRAS/456/3655 : Masses and ages of red giants (Martig+, 2016)
 J/ApJ/821/93     : Rot. & Galactic kinematics of mid M dwarfs (Newton+, 2016)
 J/AJ/152/113     : Pleiades members with K2 light curves. I. (Rebull+, 2016)
 J/A+A/605/A111   : Surface rotation of Kepler red giant stars (Ceillier+, 2017)
 J/ApJ/842/83     : Praesepe members rot. periods from K2 LCs (Douglas+, 2017)
 J/ApJS/233/23    : APOKASC cat. of KIC dwarfs and subgiants (Serenelli+, 2017)
 J/ApJ/866/99     : Revised radii of KIC stars & planets (Berger+, 2018)
 J/AJ/156/217     : Properties for M dwarfs in MEarth-South (Newton+, 2018)
 J/MNRAS/475/5487 : Stellar properties of KIC stars (Silva Aguirre+, 2018)
 J/A+A/624/A19    : GALAH survey, chemodynamical analysis (Buder+, 2019)
 J/ApJ/879/49     : Rot. periods for Gaia members of NGC 6811 (Curtis+, 2019)
 J/ApJ/879/100    : Rot. periods for Hyades & Praesepe members (Douglas+, 2019)
 J/MNRAS/485/2380 : Gaia-derived luminosities of Kepler stars (Murphy+, 2019)
 J/A+A/621/A21    : Activity of Kepler stars (Reinhold+, 2019)
 J/ApJS/244/21    : Surface rot. & activity of Kepler stars. I. (Santos+, 2019)
 J/ApJ/871/174    : Kepler rapid rotators and Ks-band excesses (Simonian+, 2019)
 J/MNRAS/499/3481 : Metallicity and rotation in the Kepler field (Amard+, 2020)
 J/AJ/159/280     : Gaia-Kepler stellar properties catalog.I. (Berger+, 2020)
 J/ApJ/892/31     : Teff & metallicities of M dwarfs in APOGEE (Birky+, 2020)
 J/ApJS/250/20    : Rot. periods in TESS objects of interest (Canto+, 2020)
 J/ApJ/888/43     : APOGEE-Kepler Cool Dwarf star ages (Claytor+, 2020)
 J/ApJ/904/140    : Rotational data for clusters (Curtis+, 2020)
 J/MNRAS/498/1726 : Transiting planets around stars in TESS (Montalto+, 2020)
 J/A+A/635/A43    : Rot. periods from K2 Campaigns 0-18 (Reinhold+, 2020)
 J/ApJ/889/L34    : Oscillations in red giants from TESS data (Silva+, 2020)
 J/other/NatAs/5.707 : Dwarf stars asteroseismic rotation rates (Hall+, 2021)
 J/ApJ/919/131    : Oscillating red giants from the TESS QLP (Hon+, 2021)
 J/AJ/161/189     : Gyro-kinematic ages for ~30000 Kepler stars (Lu+, 2021)
 J/MNRAS/502/1947 : Giant stars in TESS cont. viewing zones (Mackereth+, 2021)
 J/ApJS/255/17    : Surface rot. & activity for Kepler stars II. (Santos+, 2021)
 J/A+A/649/A147   : Spectroscopic parameters for 313 M dwarfs (Sarmento+, 2021)
 J/AJ/161/231     : A list of ~330000 stars Kepler missed (Wolniewicz+, 2021)
 J/ApJ/930/7      : Rot. data from TESS-APOGEE-Kepler-Gaia (Avallone+, 2022)
 J/MNRAS/517/2165 : Star-spots properties of Pleiades and M67 stars (Cao+, 2022)
 J/ApJ/938/118    : CFHT monitoring of M67 & members from Gaia (Dungee+, 2022)
 J/AJ/164/135     : Red giants fundamental asteroseismic parameters (Hon+, 2022)
 J/AJ/164/137     : Untangling the Galaxy. IV. TESS data (Kounkel+, 2022)
 J/AJ/164/251     : ZTF measured rot. period of 40553 M- or G-dwarfs (Lu+, 2022)
 J/MNRAS/510/5623 : Study of Kepler's FGKM stars (Masuda+, 2022)
 J/ApJS/268/4     : Stellar var. with TESS 2min cadence phot. (Fetherolf+, 2023)
 J/ApJ/952/131    : Magnetic activity of solar-like stars. I. (Mathur+, 2023)

Byte-by-byte Description of file: table5.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label  Explanations
--------------------------------------------------------------------------------
  1-   9 I9     ---     TIC    [25063215/737535216] TESS Input Catalog
                                identifier
 11-  14 I4     ---     TOI    [119/6690]? TESS Object of Interest identifier
 16-  19 F4.1   d       Prot   [2.3/80] CNN-inferred rotation period
 21-  24 F4.1   d     e_Prot   [0.7/27.5] Uncertainty in Prot
 26-  34 A9     ---   n_Prot   Period provenance: TESS-SPOC or TASOC (prov) (G1)
      36 I1     ---     Spur?  [0/1] Flag denoting likely spurious period 
                                (spurious)
 38-  42 I5     ppm     Rper   [742/65620] Photometric activity range R_per_
 44-  49 I6     ppm     Sph    [290/249700] Photometric activity index S_ph_
 51-  55 I5     ppm     cdpp   [54/10130] Combined differential photometric
                                precision
 57-  60 I4     K       TeffT  [2906/6000] TIC effective temperature (Teff_TIC)
 62-  67 F6.3   mag     Tmag   [3.1/15] TESS magnitude
 69-  74 F6.3   ---     cont   [0/11.8]? TIC flux contamination ratio
                                (contratio)
 76-  82 F7.3   mas     plx    [-0.9/114]? Gaia DR3 parallax (parallax)
 84-  89 F6.3   ---     ruwe   [0.6/64]? Gaia DR3 renormalized unit weight error
 91-  96 F6.3   mag     Gmag   [4.17/16.51]? Gaia DR3 apparent G band magnitude
                                (phot_g_mean_mag)
 98- 102 F5.3   mag     Bp-Rp  [0.6/3.7]? Gaia DR3 G_BP_-G_RP_ color index
                                (bp_rp)
104- 107 I4     K       Teff   [3595/6279]? APOGEE DR17 effective temperature
                                (teff)
109- 111 I3     K     e_Teff   [50/669]? Uncertainty in Teff (teff_err)
113- 117 F5.2   [Sun]   [M/H]  [-1.76/0.41]? APOGEE DR17 metallicity (m_h)
119- 122 F4.2   [Sun] e_[M/H]  [0.05/0.23]? Uncertainty in [M/H] (m_h_err)
124- 128 F5.2   [Sun]   [a/M]  [-0.61/0.34]? APOGEE DR17 {alpha} enhancement
                                (alpha_m)
130- 133 F4.2   [Sun] e_[a/M]  [0.03/1.84]? Uncertainty in [a/M] (alpha_m_err)
     135 I1     ---     Bad    [0/1]? APOGEE DR17 spectral signal-to-noise flag
                                (snr_bad) (1)
137- 144 F8.3   ---     fspot  [0/0.81]? Spot filling fraction
146- 150 F5.2   Gyr     Age    [0.26/21.8]? MCMC gyrochronological age
152- 156 F5.2   Gyr   E_Age    [0.07/22.3]? The 1sigma upper credible limit in
                                Age (e_age+)
158- 162 F5.2   Gyr   e_Age    [0.06/11.2]? The 1sigma lower credible limit in
                                Age (e_age-)
164- 167 F4.2   Msun    Mass   [0.38/1.3]? MCMC-inferred stellar mass
169- 172 F4.2   Msun  E_Mass   [0.01/0.6]? The 1sigma upper credible limit in
                                Mass (e_mass+)
174- 177 F4.2   Msun  e_Mass   [0.01/0.2]? The 1sigma lower credible limit in
                                Mass (e_mass-)
179- 182 F4.2   Rsun    Rad    [0.37/1.66]? MCMC-inferred stellar radius (rad)
184- 187 F4.2   Rsun  E_Rad    [0.01/2.1]? The 1sigma upper credible limit in
                                Rad (e_rad+)
189- 192 F4.2   Rsun  e_Rad    [0.01/0.8]? The 1sigma lower credible limit in
                                Rad (e_rad-)
194- 198 F5.2   ---     Ro     [0.14/18.13]? MCMC-inferred Rossby number
     200 I1     ---     fconv  [0/1]? MCMC convergence flag
--------------------------------------------------------------------------------
Note (1): The snr-bad flag represents the APOGEE spectral signal-to-noise
          flag and is set for only 21 stars.
--------------------------------------------------------------------------------

Byte-by-byte Description of file: table6.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label  Explanations
--------------------------------------------------------------------------------
  1-   9 I9     ---     TIC    [25063123/765147717] TESS Input Catalog
                                identifier
 11-  14 I4     ---     TOI    [114/6725]? TESS Object of Interest identifier
 16-  24 A9     ---     Prov   Period provenance: TESS-SPOC or TASOC (G1)
 26-  32 I7     ppm     Rvar   [756/1431000] Photometric activity range R_var_
 34-  38 I5     ppm     cdpp   [28/62190] Combined differential photometric
                                precision
 40-  43 I4     K       TeffT  [2809/6000] TIC effective temperature (Teff_TIC)
 45-  50 F6.3   mag     Tmag   [2.5/15] TESS magnitude
 52-  56 F5.3   ---     cont   [0/9.15]? TIC flux contamination ratio
                                (contratio)
 58-  64 F7.3   mas     plx    [-1.41/113.2]? Gaia DR3 parallax (parallax)
 66-  71 F6.3   ---     ruwe   [0.59/58.72]? Gaia DR3 renormalized unit weight
                                error
 73-  78 F6.3   mag     Gmag   [4.64/16.66]? Gaia DR3 apparent G band magnitude
                                (phot_g_mean_mag)
 80-  84 F5.3   mag     Bp-Rp  [0.36/4.43]? Gaia DR3 G_BP_-G_RP_ color index
                                (bp_rp)
 86-  90 I5     K       Teff   [3124/13399]? APOGEE DR17 effective temperature
 92-  95 I4     K     e_Teff   [4/5961]? Uncertainty in Teff (teff_err)
 97- 101 F5.2   [Sun]   [M/H]  [-2.24/0.55]? APOGEE DR17 metallicity (m_h)
103- 106 F4.2   [Sun] e_[M/H]  [0/0.12]? Uncertainty in [M/H] (m_h_err)
108- 112 F5.2   [Sun]   [a/M]  [-0.37/0.74]? APOGEE DR17 {alpha} enhancement
                                [alpha/M] (alpha_m)
114- 117 F4.2   [Sun] e_[a/M]  [0/1.1]? Uncertainty in [a/M] (alpha_m_err)
     119 I1     ---     Edge   [0/1]? APOGEE DR17 stellar parameter fit flag
                                (star_bad) (1)
     121 I1     ---     Bad    [0/1]? APOGEE DR17 spectral signal-to-noise flag
                                (snr_bad) (2)
--------------------------------------------------------------------------------
Note (1): The star-bad flag represents the APOGEE stellar parameter fit flag,
          set when a best-fit model is close to a grid edge. It is set
          for 343 stars.
Note (2): The snr-bad flag represents the APOGEE spectral signal-to-noise
          flag and is set for only 119 stars.
--------------------------------------------------------------------------------

Global notes:
Note (G1): There are several publicly available light-curve sets, pipelines,
    and tools designed and optimized for TESS data. Due to data
    availability and lightweight data products, we determined the
    apertures from the TESS-SPOC (Jenkins+ 2016SPIE.9913E..3EJ;
    Caldwell+ 2020RNAAS...4..201C; doi:10.17909/T9-WPZ1-8S54) and TASOC
    (Handberg+ 2021AJ....162..170H; doi: 10.17909/T9-4SMN-DX89;
    Lund+ 2021ApJS..257...53L) to be the best available for a rotation
    search at the time of writing.

    See Section 2.3 for further explanations.
--------------------------------------------------------------------------------

History:
    From electronic version of the journal

License: CC-BY-4.0

================================================================================
(End)                     Prepared by [AAS], Emmanuelle Perret [CDS] 30-Apr-2026
