import sys,json,concurrent.futures
from pathlib import Path
sys.path.insert(0,'scripts')
from select_qlp_pilot import mast_pages
from adastra.archive import write_json,utc_now
out=Path('data/archive-expansion')
positions=[('149392671',84.265499658,-62.449194742,.1),('150104580',92.366756329,-64.315822575,.1),('overlapfield',7.1992341073908435,-59.95377502446895,3.)]
missions=['GALEX','HST','Kepler','K2','SWIFT','XMM','IUE','FUSE']
def audit(item):
 name,ra,dec,radius=item
 query={'service':'Mast.Caom.Filtered.Position','params':{'columns':'*','position':f'{ra}, {dec}, {radius}','filters':[{'paramName':'obs_collection','values':missions}]}}
 try:
  rows=mast_pages(query,out/('mast-v3-'+name),page_size=1000,max_rows=20000)
  groups={}
  for r in rows:groups[r.get('obs_collection','unknown')]=groups.get(r.get('obs_collection','unknown'),0)+1
  result={'utc':utc_now(),'center_ra_deg':ra,'center_dec_deg':dec,'radius_deg':radius,'rows':len(rows),'collections':groups,'observations':[{k:r.get(k) for k in ['obsid','obs_id','obs_collection','instrument_name','target_name','s_ra','s_dec','t_min','t_max','t_exptime','filters','dataproduct_type','dataRights','distance']} for r in rows]}
  write_json(out/('mast-v3-'+name+'-summary.json'),result)
  return name,{'rows':len(rows),'collections':groups}
 except Exception as e:
  result={'query':query,'error':str(e),'utc':utc_now()};write_json(out/('mast-v3-'+name+'-failure.json'),result);return name,result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: print(json.dumps(dict(pool.map(audit,positions)),indent=2))
