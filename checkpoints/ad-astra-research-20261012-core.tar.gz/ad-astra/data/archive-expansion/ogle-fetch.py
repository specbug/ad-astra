import sys,urllib.parse,json
from pathlib import Path
sys.path.insert(0,'scripts')
from select_qlp_pilot import retrieve
from adastra.archive import write_json,utc_now
out=Path('data/archive-expansion')
for name,ra,dec in [('149392671',84.265499658,-62.449194742),('150104580',92.366756329,-64.315822575)]:
 params={'-source':'J/AcA/66/131','-c':f'{ra} {dec}','-c.rs':90,'-out.all':'1','-out.max':100}
 url='https://vizier.cds.unistra.fr/viz-bin/votable?'+urllib.parse.urlencode(params)
 try:
  body=retrieve(url,out/('ogle-'+name+'.xml')); print(name,len(body))
 except Exception as e:write_json(out/('ogle-'+name+'-failure.json'),{'error':str(e),'url':url,'utc':utc_now()})
