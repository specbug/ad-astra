import sys,json,concurrent.futures
from pathlib import Path
sys.path.insert(0,'scripts')
import requests
from qlp_stellar_metadata import tap,GAIA
from adastra.archive import utc_now,write_json,sha256_file
out=Path('data/archive-expansion')
urls={
'gaia-epoch-doc':'https://www.cosmos.esa.int/web/gaia/dr3-epoch-photometry',
'gaia-data':'https://www.cosmos.esa.int/web/gaia/data-release-3',
'cheops-archive':'https://www.cosmos.esa.int/web/cheops-guest-observers-programme/archive',
'corot-archive':'https://www.cosmos.esa.int/web/corot',
'ztf-overview':'https://irsa.ipac.caltech.edu/Missions/ztf.html',
'asassn-portal':'https://asas-sn.osu.edu/',
'ogle-collection':'https://ogle.astrouw.edu.pl/',
'astrosat-archive':'https://astrobrowse.issdc.gov.in/astro_archive/archive/Home.jsp',
'plato-mission':'https://www.esa.int/Science_Exploration/Space_Science/Plato',
'kepler-fields':'https://archive.stsci.edu/missions-and-data/kepler',
'galex-overview':'https://archive.stsci.edu/missions-and-data/galex',
}
def fetch(item):
 key,url=item
 try:
  r=requests.get(url,timeout=45); path=out/(key+'.html');path.write_bytes(r.content)
  return key,dict(url=url,resolved_url=r.url,status=r.status_code,retrieved_utc=utc_now(),path=str(path),sha256=sha256_file(path),bytes=len(r.content))
 except Exception as e:return key,dict(url=url,error=str(e),retrieved_utc=utc_now())
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:results=dict(pool.map(fetch,urls.items()))
write_json(out/'official-reference-provenance.json',results)
ids='4757558780144090368,5476797645662534144,4757558810204649856,5476797641361944064'
q=f'SELECT source_id,ra,dec,phot_g_mean_mag,phot_variable_flag,has_epoch_photometry,has_epoch_rv,non_single_star FROM gaiadr3.gaia_source WHERE source_id IN ({ids})'
try:rows=tap(GAIA,q,out/'gaia-epoch-availability.json');write_json(out/'gaia-epoch-availability-parsed.json',rows);print(json.dumps(rows,indent=2))
except Exception as e:write_json(out/'gaia-epoch-failure.json',{'query':q,'error':str(e),'utc':utc_now()})
print(json.dumps(results,indent=2))
