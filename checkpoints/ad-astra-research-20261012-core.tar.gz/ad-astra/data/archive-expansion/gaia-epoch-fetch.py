import requests,json
from pathlib import Path
from adastra.archive import utc_now,write_json,sha256_file
out=Path('data/archive-expansion')
url='https://gea.esac.esa.int/data-server/data'
for sid in [4757558810204649856,5476797641361944064]:
 params={'ID':str(sid),'RETRIEVAL_TYPE':'EPOCH_PHOTOMETRY','FORMAT':'votable','DATA_STRUCTURE':'INDIVIDUAL','RELEASE':'Gaia DR3'}
 result={'source_id':sid,'endpoint':url,'parameters':params,'retrieved_utc':utc_now()}
 try:
  r=requests.get(url,params=params,timeout=120); result.update(status=r.status_code,resolved_url=r.url,content_type=r.headers.get('Content-Type'),bytes=len(r.content))
  suffix='.zip' if r.content.startswith(b'PK') else '.xml'
  path=out/(f'gaia-epoch-{sid}'+suffix);path.write_bytes(r.content);result.update(path=str(path),sha256=sha256_file(path));r.raise_for_status()
 except Exception as e:result['error']=str(e)
 write_json(out/f'gaia-epoch-{sid}-provenance.json',result)
 print(json.dumps(result,indent=2))
