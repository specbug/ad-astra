J/A+A/658/A22       Kinematic properties of white dwarfs          (Raddi+, 2022)
================================================================================
Kinematic properties of white dwarfs.
Galactic orbital parameters and age-velocity dispersion relation.
    Raddi R., Torres S., Rebassa-Mansergas A., Maldonado J., Camisassa M. E.,
    Koester D., Gentile Fusillo N. P., Tremblay P.-E., Dimpel M., Heber U.,
    Cunningham T., Ren J.-J.
    <Astron. Astrophys. 658, A22 (2022)>
    =2022A&A...658A..22R        (SIMBAD/NED BibCode)
================================================================================
ADC_Keywords: Stars, double and multiple ; Stars, white dwarf ; Proper motions ;
              Radial velocities ; Photometry ; Abundances ; Stars, distances ;
              Stars, masses ; Stars, ages ; Optical
Keywords: white dwarfs - binaries: general - Galaxy: kinematics and dynamics

Abstract:
    Kinematic and chemical tagging of stellar populations have both
    revealed much information on the past and recent history of the Milky
    Way, including its formation history, merger events, and mixing of
    populations across the Galactic disk and halo. We present the first
    detailed 3D kinematic analysis of a sample of 3133 white dwarfs that
    used Gaia astrometry plus radial velocities, which were measured
    either by Gaia or by ground-based spectroscopic observations. The
    sample includes either isolated white dwarfs that have direct radial
    velocity measurements, or white dwarfs that belong to common proper
    motion pairs that contain nondegenerate companions with available
    radial velocities. A subset of common proper motion pairs also have
    metal abundances that have been measured by large-scale spectroscopic
    surveys or by our own follow-up observations. We used the white dwarfs
    as astrophysical clocks by determining their masses and total ages
    through interpolation with dedicated evolutionary models. We also used
    the nondegenerate companions in common proper motions to chemically
    tag the population. Combining accurate radial velocities with Gaia
    astrometry and proper motions, we derived the velocity components of
    our sample in the Galactic rest frame and their Galactic orbital
    parameters. The sample is mostly located within ~300 pc from the Sun.
    It predominantly contains (90-95%) thin-disk stars with almost
    circular Galactic orbits, while the remaining 5-10% of stars have more
    eccentric trajectories and belong to the thick disk. We identified
    seven isolated white dwarfs and two common proper motion pairs as halo
    members. We determined the age - velocity dispersion relation for the
    thin-disk members, which agrees with previous results that were
    achieved from different white dwarf samples without published radial
    velocities. The age - velocity dispersion relation shows signatures of
    dynamical heating and saturation after 4-6 Gyr. We observed a mild
    anticorrelation between [Fe/H] and the radial component of the average
    velocity dispersion, showing that dynamical mixing of populations
    takes place in the Galactic disk, as was detected through the analysis
    of other samples of FGK stars. We have shown that a white dwarf sample
    with accurate 3D kinematics and well-measured chemical compositions
    enables a wider understanding of their population in the solar
    neighborhood and its connection with the Galactic chemodynamics. The
    legacy of existing spectroscopic surveys will be boosted by the
    availability of upcoming larger samples of white dwarfs and common
    proper motion pairs with more uniform high-quality data.

Description:
    The catalog includes isolated white dwarfs and common proper motion
    pairs, which contain a white dwarf and a nondegenerate companion. The
    listed data include Gaia EDR3 photometry, geometric distances, white
    dwarf radial velocities, abundances and radial velocities of the
    nondegenerate stars. We estimated the white dwarf physical parameters
    (effective temperature, surface gravity, mass, radius, cooling age,
    progenitor mass, and progenitor age) and their Galatic orbital
    parameters.

File Summary:
--------------------------------------------------------------------------------
 FileName      Lrecl  Records   Explanations
--------------------------------------------------------------------------------
ReadMe            80        .   This file
table2.dat        89     3151   Catalog of isolated white dwarfs and common
                                 proper motion pairs
table4.dat        58     1108   Radial velocities and abundances of companions
                                 in common proper motion pairs; updated version
table5.dat       206     3128  *Physical parameters of white dwarfs, inferred
                                 from H-rich evolutionary models
table6.dat       188      869  *Physical parameters of white dwarfs,
                                 inferred from He-rich evolutionary models
table7.dat       177     3175  *Galactic orbital parameters of white dwarfs
--------------------------------------------------------------------------------
Note on table5.dat, table6.dat: The evolutionary models were presented in:
  Althaus et al. (2013A&A...557A..19A, Cat. J/A+A/557/A19),
  Camisassa et al. (2016ApJ...823..158C), Camisassa et al. (2017ApJ...839...11C)
  and Camisassa et al. (2019A&A...625A..87C, Cat. J/A+A/625/A87).
Note on table7.dat: The orbital parameters of white dwarfs are computed using
  the galpy library for galactic dynamics (Bovy, 2015ApJS..216...29B)
--------------------------------------------------------------------------------

See also:
    I/350 : Gaia EDR3 (Gaia Collaboration, 2020)
    I/352 : Distances to 1.47 billion stars in Gaia EDR3 (Bailer-Jones+, 2021)

Byte-by-byte Description of file: table2.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label     Explanations
--------------------------------------------------------------------------------
   1-  4  I4    ---     System    [1/3151] Star system identifier
   6- 24  I19   ---     SourceID1 Gaia EDR3 source ID of white dwarf
  26- 30  F5.2  mag     Gmag1     Gaia EDR3 G magnitude of white dwarf
  32- 36  F5.2  mag     BPmag1    Gaia EDR3 BP magnitude of white dwarf
  38- 42  F5.2  mag     RPmag1    Gaia EDR3 RP magnitude of white dwarf
  44- 47  I4    pc      Dist1     Geometric distance of white dwarf (1)
  49- 67  I19   ---     SourceID2 ? Gaia EDR3 source ID of companion
  69- 73  F5.2  mag     Gmag2     ? G magnitude of wide companion
  75- 79  F5.2  mag     BPmag2    ? Gaia EDR3 BP magnitude of wide companion
  81- 85  F5.2  mag     RPmag2    ? Gaia EDR3 RP magnitude of wide companion
  87- 89  I3    pc      Dist2     ? Geometric distance of wide companion (1)
--------------------------------------------------------------------------------
Note (1): Obtained from Bailer-Jones et al. (2021AJ....161..147B, Cat. I/352).
--------------------------------------------------------------------------------

Byte-by-byte Description of file: table4.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label       Explanations
--------------------------------------------------------------------------------
   1-  4  I4    ---     System      [11/3148] Star system identifier
   6- 12  A7    ---     Survey      Spectroscopic survey (1)
  14- 18  F5.2  [-]     [Fe/H]      ? [Fe/H] of nondegenerate companion
  20- 23  F4.2  [-]   e_[Fe/H]      ? Error on [Fe/H]
  25- 29  F5.2  [-]     [alpha/Fe]  ? [alpha/Fe] of nondegenerate companion
  31- 34  F4.2  [-]   e_[alpha/Fe]  ? Error on [alpha/Fe]
  36- 41  F6.1  km/s    RV1         ? Radial velocity measured by survey
  43- 46  F4.1  km/s  e_RV1         ? Error on RV1
  48- 53  F6.1  km/s    RV2         ? Gaia DR2 radial velocity
  55- 58  F4.1  km/s  e_RV2         ? Error on RV2
--------------------------------------------------------------------------------
Note (1): The spectroscopic surveys from which the parameters were obtained are:
     RAVE (Kunder et al. 2017AJ....153...75K)
     LAMOST (Luo et al. 2019yCat.5164....0L; Xiang et al. 2019ApJS..245...34X )
     APOGEE (Jonsson et al. 2020AJ....160..120J )
     GALAH+ (Buder et al. 2021MNRAS.506..150B)
     RM+2000 (Rebassa-Mansergas et al. 2021MNRAS.505.3165R)
     CPMP (Gaia Collaboration et al. 2018A&A...616A...1G)
--------------------------------------------------------------------------------

Byte-by-byte Description of file: table5.dat
--------------------------------------------------------------------------------
   Bytes Format Units     Label       Explanations
--------------------------------------------------------------------------------
   1-  4  I4    ---       System      [1/3151] Star system identifier
   6- 10  F5.3  [K]       logTeff     White dwarf effective temperature
  12- 16  F5.3  [K]     e_logTeff     Error on logTeff
  18- 21  F4.2  [cm/s2]   logg        White dwarf surface gravity
  23- 26  F4.2  [cm/s2] e_logg        ? Error on logg
  28- 31  F4.2  Msun      Mass        White dwarf mass
  33- 36  F4.2  Msun    e_Mass        ? Error on Mass
  38- 42  F5.3  Rsun      Radius      White dwarf radius
  44- 48  F5.3  Gyr       taucool     White dwarf cooling age
  50- 55  F6.3  Gyr     E_taucool     Upper error on tau_cool
  57- 62  F6.3  Gyr     e_taucool     [] Lower error on tau_cool
      64  A1    ---     l_MprogC08    ? Progenitor mass upper limit flag (1)
  66- 69  F4.2  Msun      MprogC08    ? Progenitor mass (2)
  71- 75  F5.2  Msun    E_MprogC08    ? Upper error on MprogC08
  77- 81  F5.2  Msun    e_MprogC08    []? Lower error on MprogC08
      83  A1    ---     l_tauprogC08  ? Lower limit flag on progenitor age (1)
  85- 90  F6.3  Gyr       tauprogC08  ? Progenitor age (2)
  92- 98  F7.3  Gyr     E_tauprogC08  ? Upper error on progenitor age
 100-105  F6.3  Gyr     e_tauprogC08  []? Lower error on progenitor age
     107  A1    ---     l_MprogC18    ? Progenitor mass upper limit flag
 109-112  F4.2  Msun      MprogC18    ? Progenitor mass (3)
 114-118  F5.2  Msun    E_MprogC18    ? Upper error on MprogC08
 120-124  F5.2  Msun    e_MprogC18    []? Lower error on MprogC08
     126  A1    ---     l_tauprogC18  ? Lower limit on progenitor age
 128-133  F6.3  Gyr       tauprogC18  ? Progenitor age (3)
 135-141  F7.3  Gyr     E_tauprogC18  ? Upper error on progenitor age
 143-148  F6.3  Gyr     e_tauprogC18  []? Lower error on progenitor age
 150-173  A24   ---       Name        White dwarf other name
 175-179  A5    ---       SpType      Spectral type (5)
 181-187  F7.2  km/s      RV          ? White dwarf radial velocity (4)
 189-193  F5.2  km/s    e_RV          ? Error on RV
 195-206  A12   ---       Sample      Sample of appartenence (6)
--------------------------------------------------------------------------------
Note (1): "<" or ">" whether the quantity is an upper or lower limit.
Note (2): Progenitor masses inferred from the initial-to-final-mass relation by
  Catalan et al. (2008MNRAS.387.1693C). Progenitor ages are derived from the
  BaSTI isochrones (Hidalgo et al., 2018ApJ...856..125H;
  Pietrinferni et al., 2021ApJ...908..102P).
Note (3): Progenitor masses inferred from the initial-to-final-mass relation by
  Cummings et al. (2018ApJ...866...21C). Progenitor ages are derived from the
  BaSTI isochrones (Hidalgo et al. 2018ApJ...856..125H;
  Pietrinferni et al., 2021ApJ...908..102P).
Note (4): White dwarf radial velocities are corrected for the effect of the
  gravitational redshift. The SDSS (Anguiano et al., 2017MNRAS.469.2102A,
  Cat. J/MNRAS/469/2102) sample is also corrected for a systematic offset with
  respect to the SPY (Napiwotzki et al., 2020A&A...638A.131N,
  Cat. J/A+A/638/A131) sample.
Note (5): White dwarf spectral type as listed in the Montreal White Dwarf
  Database (Dufour et al., 2017ASPC..509....3D).
Note (6): The appartenence of white dwarfs to spectroscopic samples or to common
  proper motion pairs.
--------------------------------------------------------------------------------

Byte-by-byte Description of file: table6.dat
--------------------------------------------------------------------------------
   Bytes Format Units     Label       Explanations
--------------------------------------------------------------------------------
   1-  4  I4    ---       System      [11/3148] Star system identifier
   6- 10  F5.3  [K]       logTeff     White dwarf effective temperature
  12- 16  F5.3  [K]     e_logTeff     Error on log_teff
  18- 21  F4.2  [cm/s2]   logg        White dwarf surface gravity
  23- 26  F4.2  [cm/s2] e_logg        ? Error on logg
  28- 31  F4.2  Msun      Mass        White dwarf mass
  33- 36  F4.2  Msun    e_Mass        ? Error on Mass
  38- 42  F5.3  Rsun      Radius      White dwarf radius
  44- 48  F5.3  Gyr       taucool     White dwarf cooling age
  50- 55  F6.3  Gyr     E_taucool     Upper error on taucool
  57- 62  F6.3  Gyr     e_taucool     [] Lower error on taucool
      64  A1    ---     l_MprogC08    Progenitor mass upper limit flag (1)
  66- 69  F4.2  Msun      MprogC08    ? Progenitor mass (2)
  71- 75  F5.2  Msun    E_MprogC08    ? Upper error on MprogC08
  77- 81  F5.2  Msun    e_MprogC08    []? Lower error on MprogC08
      83  A1    ---     l_tauprogC08  Lower limit flag on progenitor age (1)
  85- 90  F6.3  Gyr       tauprogC08  ? Progenitor age (2)
  92- 98  F7.3  Gyr     E_tauprogC08  ? Upper error on progenitor age
 100-105  F6.3  Gyr     e_tauprogC08  []? Lower error on progenitor age
     107  A1    ---     l_MprogC18    Progenitor mass upper limit flag (1)
 109-112  F4.2  Msun      MprogC18    ? Progenitor mass (3)
 114-118  F5.2  Msun    E_MprogC18    ? Upper error on MprogC08
 120-124  F5.2  Msun    e_MprogC18    []? Lower error on MprogC08
     126  A1    ---     l_tauprogC18  Lower limit flag on progenitor age (1)
 128-133  F6.3  Gyr       tauprogC18  ? Progenitor age (3)
 135-141  F7.3  Gyr     E_tauprogC18  ? Upper error on progenitor age
 143-149  F7.3  Gyr     e_tauprogC18  []? Lower error on progenitor age
 151-174  A24   ---       Name        White dwarf other name
 176-180  A5    ---       SpType      Spectral type (4)
 182-188  A7    ---       Sample      Sample of appartenence (5)
--------------------------------------------------------------------------------
Note (1): "<" or ">" whether the quantity is an upper or lower limit.
Note (2): Progenitor masses inferred from the initial-to-final-mass relation by
  Catalan et al. (2008MNRAS.387.1693C). Progenitor ages are derived from the
  BaSTI isochrones (Hidalgo et al., 2018ApJ...856..125H;
  Pietrinferni et al., 2021ApJ...908..102P).
Note (3): Progenitor masses inferred from the initial-to-final-mass relation by
  Cummings et al. (2018ApJ...866...21C). Progenitor ages are derived from the
  BaSTI isochrones (Hidalgo et al., 2018ApJ...856..125H;
  Pietrinferni et al., 2021ApJ...908..102P).
Note (4): White dwarf spectral type as listed in the Montreal White Dwarf
  Database (Dufour et al., 2017ASPC..509....3D).
Note (5): The appartenence of white dwarfs to spectroscopic samples or to common
  proper motion pairs.
--------------------------------------------------------------------------------

Byte-by-byte Description of file: table7.dat
--------------------------------------------------------------------------------
   Bytes Format Units     Label     Explanations
--------------------------------------------------------------------------------
   1-  4  I4    ---       System    [1/3151] Star system identifier
   6- 12  A7    ---       Sample    Sample of appartenence (1)
  14- 19  F6.3  kpc       X         Galactocentric Cartesian X coordinate
  21- 26  F6.3  kpc       Y         Galactocentric Cartesian Y coordinate
  28- 33  F6.3  kpc       Z         Galactocentric Cartesian Z coordinate
  35- 41  F7.2  km/s      U         Galactic Cartesian velocity component
  43- 47  F5.2  km/s    e_U         Error on U
  49- 55  F7.2  km/s      V         Galactic Cartesian velocity component
  57- 61  F5.2  km/s    e_V         Error on V
  63- 69  F7.2  km/s      W         Galactic Cartesian velocity component
  71- 75  F5.2  km/s    e_W         Error on W
  77- 81  F5.3  ---       ecc       Galactic orbital eccentricity
  83- 88  F6.3  ---     E_ecc       Upper error on ecc
  90- 95  F6.3  ---     e_ecc       [] Lower error on ecc
  97-102  F6.1 kpc.km/s   Lz        Z component of the angular momentum of the
                                     Galactic orbit
 104-109  F6.1 kpc.km/s E_Lz        Upper error on Lz
 111-116  F6.1 kpc.km/s e_Lz        [] Lower error on Lz
 118-122  F5.3  kpc       Rperi     Pericenter of Galactic orbit
 124-129  F6.3  kpc     E_Rperi     Upper error on Rperi
 131-136  F6.3  kpc     e_Rperi     [] Lower error on Rperi
 138-143  F6.3  kpc       Rapo      Apocenter of Galactic orbit
 145-150  F6.3  kpc     E_Rapo      Upper error on Rapo
 152-157  F6.3  kpc     e_Rapo      [] Lower error on Rapo
 159-163  F5.3  kpc       Zmax      Maximum Z coordinate of Galactic orbit
 165-170  F6.3  kpc     E_Zmax      Upper error on Zmax
 172-177  F6.3  kpc     e_Zmax      [] Lower error on Zmax
--------------------------------------------------------------------------------
Note (1): The spectroscopic sample where the radial velocities are taken from.
--------------------------------------------------------------------------------

Acknowledgements:
    Roberto Raddi, roberto.raddi(at)upc.edu

History:
    * 27-Jan-2022: Insert into VizieR
    * 29-Jul-2022: Some [Fe/H] values corrected in Table 4;
                    table sent by the author.

================================================================================
(End)     Roberto Raddi [UPC, Spain], Patricia Vannier [CDS]         19-Nov-2021
