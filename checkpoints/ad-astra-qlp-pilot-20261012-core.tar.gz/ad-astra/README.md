# Ad astra

A reproducible amateur-astronomy research workspace for public TESS observations: exploratory transit searches and unusual stellar variability, followed by catalog and literature checks. **No new planet or novel stellar source has been established.**

This workspace was reconstructed after an environment reset. The earlier 88-star analysis survives only in conversation history; see [recovery notes](docs/recovery-notes.md). Current results must be assessed from the current saved artifacts.

Setup, using the existing isolated checkout:

```bash
cd /workspace/ad-astra
bash scripts/setup.sh
.venv/bin/python -m pytest -q
```

Python 3.12 and the direct dependency versions in `requirements-validated.txt` were tested. No persistent service or ADS credential is required. Direct dependencies are pinned; this is not a complete transitive dependency lock.

The reconstructed pipeline reads legacy MIT QLP light curves with explicit timing, quality and identity checks. It verifies supplied FITS checksums against the original bytes and records retrieval provenance and SHA-256 hashes. Some QLP products supply no FITS checksum: local hashes track the downloaded content but do not replace a publisher checksum.

The completed pilot analyzed 24 stars, 48 light curves, and 48 sign-reversed controls. None of its transit priorities justified promotion. Its strongest repeated variability matches a known nearby RR Lyrae; pixel attribution remains inconclusive. A weaker signal remains unresolved. Read the [research report](docs/research-report.md), [transit vetting](docs/qlp-transit-vetting.md), [neighbor audit](docs/qlp-stellar-metadata.md), and [pixel check](docs/qlp-rrlyrae-pixels.md).

Science retrieval uses only sectors 1 and 2. Later seasons are reserved and must remain unopened: the lost original manifest prevents auditing every historical holdout. Target overlap with the old cohort is unknown. Selection records, frozen configurations, raw public metadata, all failures, known-signal controls, and inverted-flux controls are retained.

See [QLP ingestion](docs/qlp-ingestion.md), [selection](docs/qlp-selection.md), and the [research protocol](docs/research-protocol.md). Run outputs live under `runs/`; downloaded observations and catalog snapshots live under `data/`. Both are ignored by Git and require separate preservation.

The search ranks possibilities; conditional signal-to-noise values and positive-depth event windows do not establish detection significance. Public catalog nonmatches do not establish novelty. Known π Mensae controls recovered 18/18 deeper injected signals but missed the real shallow planet in one of two sectors, so nondetections cannot establish absence.
